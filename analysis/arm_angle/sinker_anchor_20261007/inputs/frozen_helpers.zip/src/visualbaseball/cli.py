from __future__ import annotations

import argparse, json
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path
from threading import local

import pyarrow.parquet as pq

from .collector import _load_naver, cache_payload, prepare_game, process_payload, rebuild_from_raw
from .export_excel import export_latest
from .http_client import VisualBaseballClient
from .storage import Store
from .swing_take import build_swing_take
from .zone_profile import build_zone_profiles
from .blocking import build_blocking
from .pitch_arsenal import PITCH_ARSENAL_SEASONS, build_pitch_arsenal
from .plate_discipline import build_plate_discipline
from .zone_decision import build_zone_decision
from .arm_angle import build_arm_angle_input
from .movement_zones import build_movement_zones
from .curated import normalize_trajectory, pitch_sha256, schema_sha256, source_manifest_path
from .metric_state import mark_built, needs_build
from .dataset_summary import build_summary

# SBJ seasons. 2024+ judge against the ABS planes; 2019-2023 against the umpire's calls (zone_decision.pzone_fields).
SBJ_SEASONS = tuple(range(2019, 2027))


def _is_final(game: dict) -> bool:
    status = str(game.get("status", ""))
    return status.lower() in {"final", "finished", "end"} or (chr(0xC885) + chr(0xB8CC)) in status


def select_target_games(schedule: dict, store: Store, season: int, mode: str = "recent",
                        game_id: str | None = None, today: date | None = None) -> list[dict]:
    """Select recent, eight time-stratified samples, or every completed game."""
    today = today or date.today()
    all_games = []
    for game_date, games in schedule.items():
        for game in games:
            if game_id and game.get("gameId") != game_id:
                continue
            all_games.append((date.fromisoformat(game_date), game))
    completed = [item for item in all_games if _is_final(item[1])]
    if mode == "reconcile":
        return [game for _, game in completed]
    if mode == "sample":
        eligible = [item for item in completed if (today - item[0]).days > 30]
        if len(eligible) <= 8:
            return [game for _, game in eligible]
        indexes = sorted({round(index * (len(eligible) - 1) / 7) for index in range(8)})
        return [eligible[index][1] for index in indexes]
    manifest = store.manifest().get("games", {})
    return [
        game for game_date, game in all_games
        if (game_date <= today and (
            store.should_fetch(game["gameId"], game_date.isoformat(), 7) if _is_final(game)
            else manifest.get(game["gameId"], {}).get("status") in {None, "incomplete", "failed"}
        ))
    ]


def _build_metric(root: Path, season: int, name: str, action) -> None:
    if needs_build(root, season, name):
        action(); mark_built(root, season, name)
        print(f"built {name} {season}", flush=True)
    else:
        print(f"unchanged {name} {season}", flush=True)


def _exports(root: Path, season: int, storage_root: Path) -> None:
    def build(name, action):
        _build_metric(root, season, name, action)

    build("excel", lambda: export_latest(root, season))
    build("arm_angle", lambda: build_arm_angle_input(root, season))
    build("swing_take", lambda: build_swing_take(root, season))
    decision_source = root / "data" / "metrics" / "swing_take" / str(season) / (
        "decision_pitches.parquet" if season == 2026 else f"decision_pitches_{season}.parquet"
    )
    if decision_source.exists():
        build("plate_discipline", lambda: build_plate_discipline(root, season, decision_source))
        if pq.read_metadata(decision_source).num_rows >= 1_000 and season in SBJ_SEASONS:
            build("zone_decision", lambda: build_zone_decision(root, season))
    build("zone_profiles", lambda: build_zone_profiles(root, season))
    build("pitch_arsenal", lambda: build_pitch_arsenal(root, season))
    build("blocking", lambda: build_blocking(root, season))
    build_summary(root)


def _arguments() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--storage-root")
    parser.add_argument("--fixture")
    parser.add_argument("--season", type=int, default=2026)
    parser.add_argument("--game-id")
    parser.add_argument("--rebuild-from-raw", action="store_true")
    parser.add_argument("--only", choices=("zone_decision", "pitch_arsenal", "movement_zones"),
                        help="Rebuild just this metric for --season from curated data, only when its inputs or code changed.")
    parser.add_argument("--exports-only", action="store_true",
                        help="Rebuild exports from the curated data already on disk; no network fetch.")
    parser.add_argument("--refresh-completed", action="store_true")
    parser.add_argument("--collection-mode", choices=("recent", "sample", "reconcile"), default="recent")
    parser.add_argument("--auto-reconcile", action="store_true")
    parser.add_argument(
        "--refresh-workers",
        type=int,
        default=1,
        help="Concurrent Visual Baseball PBP fetches; keep 1 for ordinary daily updates.",
    )
    parser.add_argument(
        "--refresh-naver",
        action="store_true",
        help="Fetch and cache Naver relay flags while rebuilding raw games",
    )
    parser.add_argument("--naver-workers", type=int, default=1)
    return parser


def _build_only(parser: argparse.ArgumentParser, args, root: Path) -> None:
    """--only: rebuild one metric from curated data when its inputs or code changed."""
    if args.only == "movement_zones":
        _build_metric(root, args.season, "movement_zones", lambda: build_movement_zones(root))
    elif args.only == "zone_decision":
        # Completed seasons have no Swing/Take decision table, so this skips the
        # _exports() gate; build_zone_decision reads curated data directly.
        if args.season not in SBJ_SEASONS:
            parser.error("--only zone_decision covers the SBJ seasons 2019-2026")
        _build_metric(root, args.season, "zone_decision", lambda: build_zone_decision(root, args.season))
    elif args.only == "pitch_arsenal":
        # Completed seasons shown on the Pitch Plot page; rebuilt from curated data only.
        if args.season not in PITCH_ARSENAL_SEASONS:
            parser.error("--only pitch_arsenal covers the Pitch Plot seasons 2022-2026")
        _build_metric(root, args.season, "pitch_arsenal", lambda: build_pitch_arsenal(root, args.season))


def _run_offline(args, root: Path, storage_root: Path) -> bool:
    """Paths that never touch the network. Returns False when the network collection should run."""
    if args.exports_only:
        # 파이프라인 코드가 바뀌었을 때 쓰는 경로입니다. 새 경기를 가져오지 않고
        # 이미 있는 curated 데이터에서 산출물만 다시 만듭니다. 수집은 스케줄·수동 실행의 몫입니다.
        _exports(root, args.season, storage_root)
        print(f"rebuilt exports for {args.season} from curated data")
    elif args.rebuild_from_raw:
        games, pitches = rebuild_from_raw(
            storage_root, args.season, args.refresh_naver, args.game_id,
            max(1, args.naver_workers), root
        )
        _exports(root, args.season, storage_root)
        print(f"rebuilt {games} games and {pitches} pitches")
    elif args.fixture:
        payload = json.loads(Path(args.fixture).read_text(encoding="utf-8-sig"))
        ok, message, pitches = process_payload(storage_root, payload, season=args.season, curated_root=root)
        if not ok:
            raise SystemExit(message)
        _exports(root, args.season, storage_root)
        print(f"processed {pitches} pitches")
    else:
        return False
    return True


def _game_fetcher(store: Store, season: int, refresh_naver: bool):
    def fetch_game(game: dict, request_client: VisualBaseballClient) -> tuple[object, dict]:
        game_id = game["gameId"]
        payload = request_client.get_json(f"/api/game/pbp?id={game_id}", f"/game/{game_id}/pbp")
        innings = max((int(half.get("inning") or 0) for half in payload.get("pbpData", [])), default=9)
        naver_enrichment = _load_naver(store, season, game_id, innings, None, refresh_naver)
        if naver_enrichment is None:
            from .naver import NaverSportsClient
            naver_enrichment = _load_naver(
                store, season, game_id, innings, NaverSportsClient(), refresh_naver
            )
        # The retained payload is the canonical parse input; schedule data only selects targets.
        return prepare_game(payload, None, season, naver_enrichment), payload
    return fetch_game


def _fetch_all(games: list[dict], fetch_game, client: VisualBaseballClient, workers: int) -> list[tuple[object, dict]]:
    """Fetch in schedule order; with several workers each thread keeps its own client."""
    fetched: list[tuple[object, dict] | None] = [None] * len(games)
    if workers == 1:
        for index, game in enumerate(games, 1):
            fetched[index - 1] = fetch_game(game, client)
            if index % 25 == 0 or index == len(games):
                print(f"Visual Baseball fetch: {index}/{len(games)} games", flush=True)
        return fetched
    worker_state = local()

    def threaded_fetch(game: dict) -> tuple[object, dict]:
        request_client = getattr(worker_state, "client", None)
        if request_client is None:
            request_client = VisualBaseballClient()
            worker_state.client = request_client
        return fetch_game(game, request_client)

    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(threaded_fetch, game): index
            for index, game in enumerate(games)
        }
        for completed, future in enumerate(as_completed(futures), 1):
            fetched[futures[future]] = future.result()
            if completed % 25 == 0 or completed == len(futures):
                print(f"Visual Baseball fetch: {completed}/{len(futures)} games", flush=True)
    return fetched


def _sample_detects_change(root: Path, season: int, fetched: list[tuple[object, dict]]) -> bool:
    """True when sampled games show a schema/y0 change or at least two changed pitch inputs."""
    changed_pitches = 0
    schema_or_y0_change = False
    for prepared, _ in fetched:
        manifest_path = source_manifest_path(root, season, prepared.game["game_id"])
        previous = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
        current_hash = pitch_sha256(
            prepared.game, prepared.events,
            [normalize_trajectory(row) for row in prepared.pitches],
        )
        changed_pitches += int(bool(previous) and previous.get("pitch_sha256") != current_hash)
        observed_y0 = sorted({float(row["y0"]) for row in prepared.pitches if row.get("y0") is not None})
        schema_or_y0_change |= bool(previous) and (
            previous.get("schema_sha256") != schema_sha256()
            or previous.get("observed_y0") != observed_y0
        )
    return schema_or_y0_change or changed_pitches >= 2


def _store_fetched(store: Store, season: int, fetched: list[tuple[object, dict]]) -> int:
    """Cache raw payloads and replace curated shards in batches of 25; returns changed shards."""
    pending_games, pending_events, pending_pitches, pending_completions = [], [], [], []
    changed_games = 0

    def flush() -> None:
        nonlocal pending_games, pending_events, pending_pitches, pending_completions, changed_games
        changed_games += store.replace_games(pending_games, pending_events, pending_pitches)
        for prepared, raw_path in pending_completions:
            store.mark(prepared.game["game_id"], "completed", raw_path, prepared.message)
        pending_games, pending_events, pending_pitches, pending_completions = [], [], [], []

    for prepared, payload in fetched:
        raw_path = cache_payload(store, season, payload, prepared)
        if raw_path:
            pending_games.append(prepared.game)
            pending_events.extend(prepared.events)
            pending_pitches.extend(prepared.pitches)
            pending_completions.append((prepared, raw_path))
            if len(pending_games) >= 25:
                flush()
    flush()
    return changed_games


def main() -> None:
    parser = _arguments()
    args = parser.parse_args()
    root = Path(args.root).resolve()
    storage_root = Path(args.storage_root).resolve() if args.storage_root else root
    if args.only:
        _build_only(parser, args, root)
        return
    if _run_offline(args, root, storage_root):
        return

    client = VisualBaseballClient()
    store = Store(storage_root, root)
    schedule = client.get_json(f"/api/schedule/season?y={args.season}")["schedule"]
    mode = "reconcile" if args.refresh_completed else args.collection_mode
    target_games = select_target_games(schedule, store, args.season, mode, args.game_id)
    fetch_game = _game_fetcher(store, args.season, args.refresh_naver)
    fetched = _fetch_all(target_games, fetch_game, client, max(1, args.refresh_workers))

    if mode == "sample" and fetched and _sample_detects_change(root, args.season, fetched):
        if args.auto_reconcile:
            sampled_ids = {game["gameId"] for game in target_games}
            remaining = [game for game in select_target_games(schedule, store, args.season, "reconcile", args.game_id)
                         if game["gameId"] not in sampled_ids]
            print(f"sample triggered automatic reconcile of {len(remaining)} games", flush=True)
            for index, game in enumerate(remaining, 1):
                fetched.append(fetch_game(game, client))
                if index % 25 == 0 or index == len(remaining):
                    print(f"Reconcile fetch: {index}/{len(remaining)} games", flush=True)
        else:
            print("WARNING: sample detected schema/y0 or multiple pitch-input changes; rerun with --auto-reconcile", flush=True)

    changed_games = _store_fetched(store, args.season, fetched)
    # Always plan exports: per-metric state handles data, code, and dependency no-ops.
    _exports(root, args.season, storage_root)
    print(f"reconciled {len(target_games)} games; {changed_games} curated shards changed")


if __name__ == "__main__":
    main()
