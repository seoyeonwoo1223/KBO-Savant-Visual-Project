"""RE288-based Swing/Take exports for the Visual Baseball pitch table.

The metric is batter-positive: a positive Decision Run is a decision worth
more than the 2026 KBO average result for the same count and normalized pitch
location.  This module deliberately keeps source-limited pitches out of the
calculation rather than filling their game state by inference.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

import pyarrow as pa
import pyarrow.parquet as pq
from .curated import _number, load_rows, schema_sha256
from .publish import add_catalog_season, write_json, write_shards

SEASON = 2026
PLAYER_METADATA = {
    "박준순": {"romanized_name": "Park Junsoon", "team": "두산 베어스", "bats": "Right"},
    "홍창기": {"romanized_name": "Hong Changki", "team": "LG 트윈스", "bats": "Left"},
}
PLATE_HALF_WIDTH_FT = 10 / 12  # ABS strike-zone half width used by Visual Baseball.
GRID_STEP = 0.25
MIN_LOCATION_CELL_PITCHES = 25
MIN_PROFILE_PITCHES = 300
REGION_ORDER = ("Heart", "Shadow", "Chase", "Waste")
ACTIONS = ("Swing", "Take")


def _source_metadata(rows: list[dict]) -> dict:
    updated_at = max((str(row.get("fetched_at") or "") for row in rows), default="")
    return {
        "dataset": "data/curated/pitches",
        "schema_sha256": schema_sha256(),
        "updated_at": updated_at or None,
    }

def _action(row):
    """Classify the source call once, including terminal HBP as a take."""
    code = str(row.get("pitch_call_code") or "").upper()
    if code in {"S", "F", "X"}:
        return "Swing"
    if code in {"B", "T"} or (row.get("is_pa_terminal") and str(row.get("pa_type") or "").lower() == "hbp"):
        return "Take"
    return None


def _relative_location(row):
    px, pz, top, bottom = (_number(row.get(key)) for key in ("px", "pz", "sz_top", "sz_bottom"))
    if None in (px, pz, top, bottom) or top <= bottom:
        return None
    return px / PLATE_HALF_WIDTH_FT, (pz - (top + bottom) / 2) / ((top - bottom) / 2)


def _region(x, z):
    distance = max(abs(x), abs(z))
    if distance <= 2 / 3:
        return "Heart"
    if distance <= 4 / 3:
        return "Shadow"
    if distance <= 2:
        return "Chase"
    return "Waste"


def _state(row, when):
    outs = row.get(f"outs_{when}")
    bases = row.get(f"base_state_code_{when}")
    balls = row.get(f"balls_{when}")
    strikes = row.get(f"strikes_{when}")
    if not all(isinstance(value, int) for value in (outs, bases, balls, strikes)):
        return None
    if not (0 <= outs <= 3 and 0 <= bases <= 7 and 0 <= balls <= 3 and 0 <= strikes <= 2):
        return None
    return bases, outs, balls, strikes


def _eligible(row):
    if row.get("parse_status") != "ok" or _action(row) is None or _relative_location(row) is None:
        return False
    before, after = _state(row, "before"), _state(row, "after")
    return bool(before and after and before[1] < 3)


def _cell(x, z):
    return round(x / GRID_STEP), round(z / GRID_STEP)


def _re288(rows):
    """Estimate each state by realised runs to the end of its half-inning."""
    targets = defaultdict(list)
    by_half = defaultdict(list)
    for row in rows:
        by_half[(row["game_id"], row["inning"], row["inning_half"])].append(row)
    for half_rows in by_half.values():
        future_runs = 0.0
        for row in sorted(half_rows, key=lambda item: item["event_seq"], reverse=True):
            future_runs += float(row.get("runs_on_pitch") or 0)
            row["_runs_to_end"] = future_runs
            targets[_state(row, "before")].append(future_runs)
    return {state: mean(values) for state, values in targets.items()}, {state: len(values) for state, values in targets.items()}


def _location_baseline(rows):
    """Count × relative-location-cell mean Raw RV; cells under 25 use neighbours."""
    cells = defaultdict(list)
    for row in rows:
        x, z = row["_relative_location"]
        balls, strikes = row["balls_before"], row["strikes_before"]
        cells[(balls, strikes, *_cell(x, z))].append(row["raw_run_value"])
    result = {}
    for key, values in cells.items():
        balls, strikes, cx, cz = key
        pool = list(values)
        radius = 1
        while len(pool) < MIN_LOCATION_CELL_PITCHES and radius <= 4:
            pool = [value for (b, s, x, z), values in cells.items() if (b, s) == (balls, strikes) and max(abs(x - cx), abs(z - cz)) <= radius for value in values]
            radius += 1
        result[key] = mean(pool)
    return result


def _league_action_rates(rows):
    """Compact league Swing/Take rates for the dotted Savant-style comparator."""
    rates = {}
    for region in REGION_ORDER:
        in_region = [row for row in rows if row["attack_region"] == region]
        swings = sum(row["decision_type"] == "Swing" for row in in_region)
        takes = sum(row["decision_type"] == "Take" for row in in_region)
        total = swings + takes
        rates[region] = {
            "pitches": total,
            "swing_pct": round(100 * swings / total, 3) if total else 0,
            "take_pct": round(100 * takes / total, 3) if total else 0,
        }
    return {"regions": rates}


def _summary(rows, player, season, re_counts, excluded, source_metadata, league):
    groups = {(region, action): [] for region in REGION_ORDER for action in ACTIONS}
    for row in rows:
        groups[(row["attack_region"], row["decision_type"])].append(row)
    def aggregate(items):
        pitches = len(items); decision = sum(item["decision_run"] for item in items)
        return {"pitches": pitches, "decision_run": round(decision, 4), "decision_run_per_100": round(100 * decision / pitches, 4) if pitches else None}
    total = aggregate(rows)
    total.update({
        "swing_pct": round(100 * len([row for row in rows if row["decision_type"] == "Swing"]) / len(rows), 3) if rows else 0,
        "take_pct": round(100 * len([row for row in rows if row["decision_type"] == "Take"]) / len(rows), 3) if rows else 0,
    })
    by_region = {}
    for region in REGION_ORDER:
        combined = groups[(region, "Swing")] + groups[(region, "Take")]
        entry = aggregate(combined)
        swings = groups[(region, "Swing")]
        takes = groups[(region, "Take")]
        entry.update({
            "share_pct": round(100 * len(combined) / len(rows), 3) if rows else 0,
            "swing_pct": round(100 * len(swings) / len(combined), 3) if combined else 0,
            "take_pct": round(100 * len(takes) / len(combined), 3) if combined else 0,
            "swing": aggregate(swings),
            "take": aggregate(takes),
        })
        by_region[region] = entry
    zone_grid = {}
    for row in rows:
        x, z = row["_relative_location"]
        if abs(x) <= 1 and abs(z) <= 1:
            key = f"{min(2, max(0, int((x + 1) * 1.5)))}-{min(2, max(0, int((z + 1) * 1.5)))}"
            zone_grid.setdefault(key, []).append(row)
    return {"schema_version": 2, "metric": "RE288 location-and-count-neutral Decision Run", "season": season, "source": source_metadata, "player": player, "sample": {"eligible_pitches": len(rows), "excluded_pitches": excluded, "minimum_pitches": MIN_PROFILE_PITCHES, "meets_minimum": len(rows) >= MIN_PROFILE_PITCHES}, "coordinate_contract": {"source": "Visual Baseball ABS px/pz (feet)", "x_center": 0, "x_zone_edge_ft": PLATE_HALF_WIDTH_FT, "z_center": "(sz_top + sz_bottom) / 2", "relative_distance": "max(abs(x_relative), abs(z_relative))", "regions": {"Heart": "0–66.7%", "Shadow": "66.7–133.3%", "Chase": "133.3–200%", "Waste": ">200%"}}, "baseline": {"count": "balls_before × strikes_before", "location": f"normalized {GRID_STEP:.2f} × {GRID_STEP:.2f} cells; sparse cells expand to Chebyshev radius 1.00", "minimum_cell_pitches": MIN_LOCATION_CELL_PITCHES}, "re288": {"observed_states": len(re_counts), "state_counts": {"-".join(map(str, state)): count for state, count in sorted(re_counts.items())}}, "league": league, "overall": total, "regions": by_region, "zone_grid": {key: aggregate(value) for key, value in zone_grid.items()}}


def build_decision_pitches(
    root: Path,
    season: int = SEASON,
    output_path: Path | None = None,
) -> tuple[list[dict], list[dict], dict, Counter, dict, dict]:
    """Build a season's RE288 pitch table without requiring profile output."""
    rows = load_rows(root, "pitches", season)
    source_metadata = _source_metadata(rows)
    excluded = Counter(); valid = []
    for row in rows:
        if not _eligible(row):
            excluded["source_or_required_state_missing"] += 1
            continue
        row["_relative_location"] = _relative_location(row)
        valid.append(row)
    re288, counts = _re288(valid)
    processed = root / "data" / "metrics" / "swing_take" / str(season)
    if season == SEASON:
        processed.mkdir(parents=True, exist_ok=True)
        write_json(processed / "re288.json", {
            "season": season,
            "states": [{"base_state_code": state[0], "outs": state[1], "balls": state[2], "strikes": state[3], "run_expectancy": round(value, 6), "pitches": counts[state]} for state, value in sorted(re288.items())],
        }, compact=False)
    valued = []
    for row in valid:
        before, after = _state(row, "before"), _state(row, "after")
        if before not in re288 or (after[1] < 3 and after not in re288):
            excluded["unobserved_re288_state"] += 1; continue
        row["raw_run_value"] = float(row.get("runs_on_pitch") or 0) + (0 if after[1] == 3 else re288[after]) - re288[before]
        valued.append(row)
    baseline = _location_baseline(valued)
    output_rows = []
    for row in valued:
        x, z = row["_relative_location"]; key = (row["balls_before"], row["strikes_before"], *_cell(x, z))
        row.update({"x_relative": x, "z_relative": z, "attack_region": _region(x, z), "decision_type": _action(row), "decision_run": row["raw_run_value"] - baseline[key], "location_count_baseline": baseline[key]})
        output_rows.append({key: value for key, value in row.items() if not key.startswith("_")})
    output_path = output_path or processed / (
        "decision_pitches.parquet" if season == SEASON else f"decision_pitches_{season}.parquet"
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(pa.Table.from_pylist(output_rows), output_path)
    league = _league_action_rates(valued)
    return output_rows, valued, counts, excluded, source_metadata, league


def build_swing_take(root: Path, season: int = SEASON) -> tuple[int, int]:
    """Build profiles from the canonical pitch shards."""
    output_rows, valued, counts, excluded, source_metadata, league = build_decision_pitches(
        root, season
    )
    output = root / "web" / "data" / "swing_take" / str(season)
    index_players = []
    pitch_shards = defaultdict(dict)
    by_batter = defaultdict(list)
    for row in valued:
        name = str(row.get("batter_name") or "").strip()
        if name:
            by_batter[str(row.get("batter_id") or name)].append(row)
    for batter_id, profile_rows in sorted(by_batter.items(), key=lambda item: str(item[1][0].get("batter_name") or "")):
        name = str(profile_rows[0]["batter_name"])
        player = {"id": batter_id, "name": name, "romanized_name": "", "team": "—", "bats": "Unknown"} | PLAYER_METADATA.get(name, {})
        profile_data = _summary(profile_rows, player, season, counts, dict(excluded), source_metadata, league)
        pitch_payload = {
            "player": player,
            "minimum_pitches": MIN_PROFILE_PITCHES,
            "pitches": [
                {
                    "action": row["decision_type"],
                    "region": row["attack_region"],
                    "run_value": round(row["decision_run"], 8),
                    "x": round(row["x_relative"], 6),
                    "z": round(row["z_relative"], 6),
                }
                for row in profile_rows
            ],
        }
        shard = batter_id[0] if batter_id[0].isdigit() else "other"
        pitch_shards[shard][batter_id] = pitch_payload
        index_players.append({key: player[key] for key in ("id", "name", "romanized_name", "team", "bats")} | {"pitches": profile_data["overall"]["pitches"], "meets_minimum": profile_data["sample"]["meets_minimum"]})
    write_shards(output / "players", {
        shard: {"season": season, "source": source_metadata, "league": league, "players": players}
        for shard, players in pitch_shards.items()
    })
    write_json(output / "index.json", {"season": season, "players": index_players}, compact=False)
    add_catalog_season(root / "web" / "data" / "swing_take" / "index.json", season)
    return len(output_rows), len(valued)
