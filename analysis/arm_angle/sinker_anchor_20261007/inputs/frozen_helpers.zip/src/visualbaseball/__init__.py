"""Incremental Visual Baseball collector."""
