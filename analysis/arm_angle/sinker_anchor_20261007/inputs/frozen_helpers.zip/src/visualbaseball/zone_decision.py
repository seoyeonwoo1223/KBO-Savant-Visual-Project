"""Strike-zone judgment and realized Swing/Take Decision Value.

Chronological development and final holdouts evaluate event-decomposed values.
Three date-block cross-fits score every pitch without its own game's outcomes.
RE tables, models, event priors and support counts are fitted on training only.
"""
from __future__ import annotations
from collections import Counter, defaultdict
import argparse
import json
import hashlib
import platform
from importlib.metadata import version
from pathlib import Path
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
from sklearn.metrics import log_loss, brier_score_loss
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import GroupKFold
from scipy.optimize import minimize, LinearConstraint
from . import plate_decision_v1 as old
from .movement_calibration import calibrate
from .batter_stance import load_batter_hands, resolved_batter_stance
from .pitch_types import pitch_code
from .swing_take import PLATE_HALF_WIDTH_FT, _eligible, _relative_location, _state
from .publish import write_json
from .teams import team_history
from .curated import CM_PER_FOOT, _at_plane, load_rows as load_curated_rows, schema_sha256

REGIONS = ('heart', 'shadow_in', 'shadow_out', 'chase', 'waste')
EVENTS = ('Whiff', 'Foul', 'InPlay', 'Ball', 'CalledStrike', 'HBP')
NUMERIC = old.BASE_NUMERIC + old.MOVEMENT_NUMERIC
# za7.5: the DV event and value models read TrackMan-validated movement (movement_calibration) in every season;
# p_swing keeps the park-workbook movement where a workbook exists (analysis/sbj_formula M).
DV_MOVEMENT = ('dv_hb_cm', 'dv_ivb_cm')
DV_NUMERIC = old.BASE_NUMERIC + DV_MOVEMENT
MODEL_VERSION = 'za7.8-neutral-apr'
SCORE_SETTINGS = {'calibration': True, 'support_prior': 50}
CROSSFIT_FOLDS = 3
# za7.3: p_zone averages five seeds so one early-stopping validation split no longer moves player SBJ
# (analysis/sbj_formula C0d).
PZONE_SEEDS = tuple(range(old.RANDOM_STATE, old.RANDOM_STATE+5))
ABS_FIRST_SEASON = 2024
# ABS calls left/right at the plate's middle plane; top and bottom must hold at
# both the middle and back planes. px/pz sit at the front plane, where a falling
# pitch's call depends on its drop, so ABS p_zone reads these instead.
PZONE_ABS = ('x_mid_relative', 'top_gap_cm', 'bottom_gap_cm')
PLANE_Y_FT = {'mid': 8.5/12, 'back': 0.0}
# ABS seasons report px on the mid plane and pz on the front plane, both computed from the trajectory. A row whose
# reported point is more than 1 cm off its own trajectory mixes two records, so its location is unknown and it is
# left out of SBJ (analysis/sbj_location/README.md section 1).
FRONT_PLANE_Y_FT, REPORTED_LOCATION_TOLERANCE_CM = 17/12, 1.0
# Only the Swing propensity reads the pitcher's hand; event and value models keep
# old.CATEGORICAL. analysis/zone_decision/pswing_inputs.md holds the comparison.
PSWING_CATEGORICAL = old.CATEGORICAL + ('pitcher_throws',)
CONTRACT = {
 'za_raw': 'ZA (Zone Awareness, formerly SBJ): 100 * mean((S - p_swing) * (2*p_zone - 1)); percentage points; equal to zone_judgment_pct - expected_zone_judgment_pct',
 'zone_judgment_pct': '100 * mean(p_zone if swing else 1 - p_zone); raw judgment accuracy, descriptive only and never ranked',
 'expected_zone_judgment_pct': '100 * mean(p_swing*p_zone + (1-p_swing)*(1-p_zone)); league-policy accuracy on the same pitches',
 'p_swing': 'league Swing propensity from location, count, base/out, velocity, release height, park-adjusted HB/IVB, pitch type, batter stance, pitcher hand and stadium; isotonic-calibrated separately for in-zone and out-of-zone pitches (p_zone >= 0.5)',
 'p_zone': 'take-only CalledStrike vs Ball/HBP model, five-seed average; ABS seasons read x at the middle plane and top/bottom at both the middle and back planes, falling back to front-plane px/pz when the trajectory is invalid; human-umpire seasons read front-plane px/pz, zone bounds and the ball-strike count',
 'raw_dv': 'sum(V_swing - V_take for swings; sign reversed for takes); cumulative runs; event and value models read TrackMan-validated movement (movement_calibration) in every season',
 'dv_per_100': '100 * raw_dv / eligible pitches; runs per 100 pitches',
 'jdv_per_100': 'decision DV (aggression-neutral, analysis/sbj_formula X-B): 100 * mean(2 * (S - p_swing - m) * (V_swing - V_take)), m = the hitter\'s mean(S - p_swing) = swing_aggression / 100; runs per 100 pitches above the league Swing policy shifted by the hitter\'s own aggression, so swinging uniformly more or less scores zero',
 'apr': 'APR (Approach), wRC+-style: 100 * (L + s) / L. L = league pitch-weighted dv_per_100; s = n/(n+k) * (jdv_per_100 - league jdv), re-centred so the pitch-weighted league mean is 100; k = per-pitch noise / true-talent variance among qualified hitters (pitches for reliability 0.5)',
 'apr_percentile': 'midrank percentile of APR against qualified hitters (300+ pitches); every hitter gets one, unqualified hitters are flagged by qualified_300',
 'swing_aggression': '100 * mean(S - p_swing); percentage points, tendency only',
 'zj_per_100': 'ZA input: 100 * mean(2 * (S - p_swing) * (2*p_zone - 1)) = 2 * za_raw; judgment margin above the league Swing policy on the same pitches',
 'za_plus': 'ZA+, wRC+-style and built like APR: 100 * (M + s) / M. M = league pitch-weighted 100 * mean((2S - 1) * (2*p_zone - 1)) (judgment margin); s = n/(n+k) * (zj_per_100 - league zj), re-centred so the pitch-weighted league mean is 100; k estimated from qualified hitters as for APR',
 'za_percentile': 'midrank percentile of ZA+ against qualified hitters (300+ pitches); every hitter gets one, unqualified hitters are flagged by qualified_300',
 'region_contributions': '100 * sum(DV in region/action) / ALL eligible player pitches; additive to dv_per_100',
 'region_jdv_contributions': '<region>_jdv_per_100, <action>_jdv_per_100, <region>_<action>_jdv_per_100: 100 * sum(decision DV in region/action) / ALL eligible player pitches; additive to jdv_per_100 (APR input before centring and shrinkage)',
 'pa': 'plate appearances: PA-ending pitches (is_pa_terminal) in the season curated pitches, as in leaderboard_vb; display only',
 'region_swing_pct': '<region>_swing_pct and <region>_expected_swing_pct: 100 * mean(S) and 100 * mean(p_swing) over the region; null when the hitter saw no pitch there',
}
LIMITATIONS = [
 '리그 평균 실행 능력을 기준으로 추정한 의사결정 가치이며 개인별 최적 판단의 정답이 아닙니다.',
 '관측하지 못한 반대 행동과 누락된 투구 특성에 따른 선택 편향이 남습니다. 실제 타구속도·발사각·해당 투구의 안타/홈런은 판단 점수의 입력이 아닙니다.',
 '시즌 표시값은 날짜 블록 교차적합으로 해당 경기 결과를 제외하지만 다른 블록의 미래 경기를 사용할 수 있습니다. 순수한 사전 예측 성능은 별도 시간 분리 평가에서 확인합니다.',
 '표본 부족 구간은 상위 조건의 결과 분포로 완화합니다. 반대 선택의 정확성과 누락된 실행 능력·번트 의도의 영향까지 검증된 것은 아닙니다.',
]


def file_hash(path):
 with path.open('rb') as stream:
  return hashlib.file_digest(stream, 'sha256').hexdigest()


def reliable_halves(rows, events):
 """Use timed, trusted non-pitch runs; never assign untimed score repairs to a pitch."""
 halves, timeline = defaultdict(list), defaultdict(list)
 bad = defaultdict(set)
 for r in rows:
  halves[(r['game_id'],r['inning'],r['inning_half'])].append(r)
 for e in events:
  key=(e['game_id'],e['inning'],e['inning_half'])
  runs=float(e.get('runs_on_event') or 0)
  score_change=sum(float(e.get(f'{team}_score_after') or 0)-float(e.get(f'{team}_score_before') or 0) for team in ('away','home'))
  if e.get('event_code') in ('OFFICIAL_LINESCORE_RECONCILIATION','SOURCE_SCORE_SNAPSHOT') and score_change:
   bad[key].add('untimed_score_repair')
  if e.get('event_type')!='pitch' and (runs or score_change):
   if e.get('parse_status')=='ok' and runs==score_change and runs>=0:
    timeline[key].append((e['event_seq'],runs,None))
   else:
    bad[key].add('unresolved_nonpitch_runs')
 accepted=[];reasons=Counter();complete=0;known_runs=0.
 for key,items in halves.items():
  items.sort(key=lambda r:r['event_seq'])
  # Score snapshots must agree with the represented pitch/non-pitch runs.
  start,end=items[0],items[-1]
  expected=sum(float(end.get(f'{team}_score_after') or 0)-float(start.get(f'{team}_score_before') or 0) for team in ('away','home'))
  represented=sum(float(r.get('runs_on_pitch') or 0) for r in items)
  represented+=sum(v for seq,v,_ in timeline[key] if start['event_seq']<=seq<=end['event_seq'])
  if all(f'{t}_score_{w}' in r for r,w in ((start,'before'),(end,'after')) for t in ('away','home')) and expected!=represented:
   bad[key].add('score_timeline_mismatch')
  if bad[key]:
   reasons.update(bad[key]);continue
  is_complete=end.get('outs_after')==3
  complete+=int(is_complete)
  remaining=0.
  ordered=timeline[key]+[(r['event_seq'],float(r.get('runs_on_pitch') or 0),r) for r in items]
  for _,runs,r in sorted(ordered,key=lambda item:item[0],reverse=True):
   remaining+=runs
   if r is not None:
    r['_runs_to_end']=remaining;r['_re_complete']=is_complete
  known_runs+=sum(v for _,v,_ in timeline[key])
  accepted.extend(items)
 return accepted,{'halves':len(halves),'excluded_halves':sum(bool(bad[k]) for k in halves),
   'excluded_pitches':len(rows)-len(accepted),'re_complete_halves':complete,
   'reason_counts':{reason:reasons[reason] for reason in sorted(reasons)},'included_timed_nonpitch_runs':known_runs,
   'policy':'Unresolved scoring halves are excluded; incomplete innings do not train RE. No invented scoring timestamps.'}


def decision_value(swing, swing_value, take_value):
 delta=np.asarray(swing_value)-np.asarray(take_value)
 return np.where(np.asarray(swing),delta,-delta)


def zone_awareness(items):
 return mean(items,'judgment',100)


def judgment_plane_location(row):
 """ABS p_zone inputs; an invalid trajectory falls back to px/pz for every plane."""
 mid=back=None
 if row.get('trajectory_valid'):
  mid,back=_at_plane(row,PLANE_Y_FT['mid']),_at_plane(row,PLANE_Y_FT['back'])
 fallback=mid is None or back is None
 if fallback:
  x=float(row['px'])*CM_PER_FOOT; heights=(float(row['pz'])*CM_PER_FOOT,)*2
 else:
  x=mid[0]; heights=(mid[1],back[1])
 # The ball must clear the top at its higher plane and the bottom at its lower one.
 return {'x_mid_relative':x/CM_PER_FOOT/PLATE_HALF_WIDTH_FT,'top_gap_cm':max(heights)-float(row['sz_top'])*CM_PER_FOOT,
  'bottom_gap_cm':min(heights)-float(row['sz_bottom'])*CM_PER_FOOT,'plane_fallback':fallback}


def reported_location_disagrees(row):
 if not row.get('trajectory_valid'):return False
 mid,front=_at_plane(row,PLANE_Y_FT['mid']),_at_plane(row,FRONT_PLANE_Y_FT)
 if mid is None or front is None:return False
 return abs(float(row['px'])*CM_PER_FOOT-mid[0])>REPORTED_LOCATION_TOLERANCE_CM or abs(float(row['pz'])*CM_PER_FOOT-front[1])>REPORTED_LOCATION_TOLERANCE_CM


# za7.4: umpires widened the zone at 0 strikes and shrank it at 2, so pre-ABS p_zone also reads the count.
# Without it boundary takes were mis-calibrated by -11 to -13 pp at 2 strikes (analysis/sbj_formula C1).
# ABS ignores the count; adding it there did not improve calls (C1-ABS control).
PZONE_UMPIRE = old.PZONE_NUMERIC + ('balls_before', 'strikes_before')


def pzone_fields(season):
 return PZONE_ABS if int(season)>=ABS_FIRST_SEASON else PZONE_UMPIRE


def load_pitcher_hands(root):
 source=root/'data/curated/players/player_bio.parquet'
 if not source.exists():return {}
 return {str(r['player_id']):str(r.get('throws') or '') for r in pq.read_table(source,columns=['player_id','throws']).to_pylist()}


def pitcher_throws(row,hands):
 # Season-level hand from player_bio; the pitch's own release side only when it is missing.
 hand=hands.get(str(row.get('pitcher_id') or '').strip(),'')
 if hand in ('R','L'):return hand
 x=old._safe_float(row.get('release_x_50'))
 return ('L' if x>0 else 'R') if np.isfinite(x) and abs(x)>=0.1 else ''


def region(row):
 d = max(abs(row['x_relative']), abs(row['z_relative']))
 return 'heart' if d <= 2/3 else 'shadow_in' if d <= 1 else 'shadow_out' if d <= 4/3 else 'chase' if d <= 2 else 'waste'


def outcome(row):
 # Classify by this pitch's call, never a nonterminal pitch's eventual PA result.
 code = str(row.get('pitch_call_code') or '').upper()
 if row.get('is_pa_terminal') and (str(row.get('pa_type') or '').lower() == 'hbp' or row.get('pa_result') == '사구'):
  return 'HBP'
 return {'S':'Whiff', 'F':'Foul', 'X':'InPlay', 'B':'Ball', 'T':'CalledStrike'}.get(code)


def park_workbook(root, season):
 return root/'data/park_adjustments'/f'{season}_VB_Park_Adjustment_v1.0.xlsx'


def calibrated_movement(rows, columns=old.MOVEMENT_NUMERIC):
 """movement_calibration's TrackMan-validated stadium-day correction, written to `columns`."""
 corrected=calibrate(rows,[pitch_code(r) for r in rows]); available=0
 for r,(hb,ivb) in zip(rows,corrected):
  ok=hb is not None and ivb is not None; available+=ok
  r[columns[0]],r[columns[1]]=(hb,ivb) if ok else (np.nan,np.nan)
 return {'movement_available':available,'movement_adjusted':available,'adjustment_coverage_pct':100.0 if available else 0.0,
  'formula':'no park adjustment workbook for this season: movement_calibration stadium-day and plate-location correction (TrackMan-validated 2019-2024)'}


def load_rows(root, season):
 rows=load_curated_rows(root,'pitches',season)
 events=load_curated_rows(root,'events',season)
 hashes={'schema_sha256':schema_sha256()}
 rows,quality=reliable_halves(rows,events)
 hands = load_batter_hands(root)
 pitcher_hands = load_pitcher_hands(root)
 valid, excluded = [], Counter()
 for r in rows:
  if not _eligible(r) or not r.get('batter_id') or not r.get('batter_name') or outcome(r) is None:
   excluded['invalid_state_location_action_or_identity'] += 1
   continue
  if pzone_fields(season)==PZONE_ABS and reported_location_disagrees(r):
   excluded['reported_location_off_trajectory'] += 1
   continue
  r['x_relative'], r['z_relative'] = _relative_location(r)
  r['decision_type'] = 'Swing' if outcome(r) in EVENTS[:3] else 'Take'
  r['batter_stance'] = resolved_batter_stance(r, hands)
  r['pitcher_throws'] = pitcher_throws(r, pitcher_hands)
  r['event'] = outcome(r)
  r['region'] = region(r)
  if pzone_fields(season)==PZONE_ABS: r.update(judgment_plane_location(r))
  valid.append(r)
 # 2019-2021 have no park workbook: p_swing then reads the TrackMan-validated movement_calibration values.
 movement = old._movement_adjust(valid, root, season) if park_workbook(root,season).exists() else calibrated_movement(valid)
 dv_movement = calibrated_movement(valid, DV_MOVEMENT)
 # Retain pre-pitch features, transitions, identity and training target only.
 keep = set(NUMERIC + DV_MOVEMENT + old.PZONE_NUMERIC + PZONE_ABS + PSWING_CATEGORICAL + ('plane_fallback','game_id','game_date','season','batter_id','batter_name','batter_team','inning_half','event','region','decision_type','_runs_to_end','_re_complete','runs_on_pitch'))
 keep.update(f'{k}_{w}' for k in ('base_state_code','outs','balls','strikes') for w in ('before','after'))
 valid = [{k:v for k,v in r.items() if k in keep} for r in valid]
 for p in (root/'data/curated/players/player_bio.parquet',park_workbook(root,season)):
  if p.exists():hashes[p.name]=file_hash(p)
 return sorted(valid, key=lambda r:r['game_id']), {'source':f'data/curated/pitches/season={season}','input_mode':'curated','curated_version':None,'sha256':hashes,'quality':quality,'excluded':dict(excluded), 'movement':movement, 'dv_movement':dv_movement, 'pzone_input':pzone_input(valid,season), 'unknown_stance':sum(not r['batter_stance'] for r in valid),'unknown_pitcher_hand':sum(not r['pitcher_throws'] for r in valid),'latest_game':max(r['game_id'] for r in valid)}


def pzone_input(rows,season):
 fields=pzone_fields(season); fallback=sum(bool(r.get('plane_fallback')) for r in rows)
 return {'fields':list(fields),'plane_fallback_pitches':fallback if fields==PZONE_ABS else None,
  'plane_fallback_pct':(100*fallback/len(rows) if rows else 0.0) if fields==PZONE_ABS else None}


def walk_state(s):
 bases,outs,_,_=s
 # Only forced runners advance; a bases-loaded walk scores exactly one run.
 after=bases|1
 if bases&1:after|=2
 if bases&3==3:after|=4
 return (after,outs,0,0),int(bases==7)


class RunExpectancy:
 def __init__(self, rows):
  full, base, outs = defaultdict(list), defaultdict(list), defaultdict(list)
  for r in rows:
   if not r.get('_re_complete',True):continue
   s = _state(r, 'before'); v = r['_runs_to_end']
   full[s].append(v); base[s[:2]].append(v); outs[s[1]].append(v)
  self.outs = {k:float(np.mean(v)) for k,v in outs.items()}
  self.base = {k:(sum(v)+50*self.outs[k[1]])/(len(v)+50) for k,v in base.items()}
  self.full = {k:(sum(v)+50*self.base[k[:2]])/(len(v)+50) for k,v in full.items()}
  if not full:raise ValueError('No complete, reliable innings for run expectancy')
  # Weighted least-squares projection of the entire RE table, not clipping RVs.
  # Ball, strike, strikeout and forced-walk transitions constrain one shared table.
  states=[(b,o,ball,strike) for b in range(8) for o in range(3) for ball in range(4) for strike in range(3)]
  index={s:i for i,s in enumerate(states)}
  prior=np.array([self.value(s) for s in states]);weights=np.array([len(full[s])+50 for s in states],dtype=float)
  weights/=weights.max();constraints=[];bounds=[]
  def edge(a,b,limit=0):
   row=np.zeros(len(states));row[index[a]]=1
   if b[1]<3:row[index[b]]-=1
   constraints.append(row);bounds.append(limit)
  for s in states:
   b,o,ball,strike=s
   if ball<3:edge(s,(b,o,ball+1,strike))
   if strike<2:edge((b,o,ball,strike+1),s)
   if o<2:edge((b,o+1,0,0),s)
   after,runs=walk_state(s);edge(s,after,runs)
  matrix=np.array(constraints);upper=np.array(bounds)
  fitted=minimize(lambda x:float(np.sum(weights*(x-prior)**2)/2),prior,
   jac=lambda x:weights*(x-prior),method='SLSQP',bounds=[(0,None)]*len(states),
   constraints=[LinearConstraint(matrix,-np.inf,upper)],options={'ftol':1e-10,'maxiter':500})
  if not fitted.success or np.max(matrix@fitted.x-upper)>1e-7:
   raise RuntimeError(f'Constrained RE failed: {fitted.message}')
  self.full=dict(zip(states,fitted.x))
  self.diagnostics={'states':len(states),'constraints':len(bounds),'max_constraint_violation':float(max(0,np.max(matrix@fitted.x-upper))),
   'weighted_adjustment_rmse':float(np.sqrt(np.average((fitted.x-prior)**2,weights=weights)))}
 def value(self, s):
  if s[1] >= 3: return 0.
  return self.full.get(s, self.base.get(s[:2], self.outs.get(s[1], 0.)))
 def target(self, rows):
  return np.array([float(r.get('runs_on_pitch') or 0)+self.value(_state(r,'after'))-self.value(_state(r,'before')) for r in rows])

 def event_value(self,s,event):
  b,o,balls,strikes=s;runs=0
  if event in ('Ball','HBP') and (balls==3 or event=='HBP'):after,runs=walk_state(s)
  elif event=='Ball':after=(b,o,balls+1,strikes)
  elif event=='Foul' and strikes==2:return 0.
  elif event in ('Whiff','CalledStrike') and strikes==2:after=(b,o+1,0,0)
  elif event in ('Whiff','CalledStrike','Foul'):after=(b,o,balls,strikes+1)
  else:raise ValueError(f'Unsupported deterministic event: {event}')
  return float(runs+self.value(after)-self.value(s))


def encode(train, test, categorical=old.CATEGORICAL, numeric=None):
 # Unknown categories are missing, never mapped to another known category.
 numeric = NUMERIC if numeric is None else numeric
 cols_a, cols_b = [], []
 for f in numeric:
  cols_a.append([old._safe_float(r.get(f)) for r in train]); cols_b.append([old._safe_float(r.get(f)) for r in test])
 for f in categorical:
  mapping = {v:i for i,v in enumerate(sorted({str(r.get(f) or '') for r in train}))}
  cols_a.append([mapping[str(r.get(f) or '')] for r in train]); cols_b.append([mapping.get(str(r.get(f) or ''),np.nan) for r in test])
 return np.column_stack(cols_a), np.column_stack(cols_b)


def support_key(r):
 return (round(r['x_relative']*2),round(r['z_relative']*2),r['balls_before'],r['strikes_before'])


def detailed_support_key(r):
 def band(key,width):
  value=old._safe_float(r.get(key))
  return int(np.floor(value/width)) if np.isfinite(value) else None
 return (*support_key(r),r.get('pitch_type'),r.get('batter_stance'),
         band('velocity_kmh',10),band(DV_MOVEMENT[0],10),band(DV_MOVEMENT[1],10))


def probability_prior(train,test,actions,events,action,indices):
 """Training-only hierarchy: count/region/type/stance -> count/region -> action."""
 def coarse(r):return (r['balls_before'],r['strikes_before'],r['region'])
 def fine(r):return (*coarse(r),r.get('pitch_type'),r.get('batter_stance'))
 global_counts=np.ones(len(indices));parent=defaultdict(lambda:np.zeros(len(indices)));local=defaultdict(lambda:np.zeros(len(indices)))
 for i in np.flatnonzero(actions==action):
  j=list(indices).index(events[i]);global_counts[j]+=1;parent[coarse(train[i])][j]+=1;local[fine(train[i])][j]+=1
 global_p=global_counts/global_counts.sum()
 result=[]
 for r in test:
  counts=parent[coarse(r)];p=(counts+50*global_p)/(counts.sum()+50)
  counts=local[fine(r)];result.append((counts+50*p)/(counts.sum()+50))
 return np.array(result)


def pswing_classifier():
 # No early stopping: its random validation split made p_swing, and through it player SBJ, depend on the seed.
 return old._classifier(len(NUMERIC)).set_params(categorical_features=list(range(len(NUMERIC),len(NUMERIC)+len(PSWING_CATEGORICAL))),early_stopping=False)


def fit_model(model, features, target):
 # All-missing training columns carry no information. A constant lets histogram
 # binning ignore them, including in action-specific and calibration subsets.
 missing=np.isnan(features).all(axis=0)
 if missing.any():
  features=features.copy();features[:,missing]=0
 return model.fit(features,target)


def fit_predict(train, test, candidate=True, calibration=True, support_prior=50, pzone_features=None, test_pzone=None):
 a,b = encode(train,test,numeric=DV_NUMERIC)
 re = RunExpectancy(train); target = re.target(train)
 actions = np.array([r['decision_type']=='Swing' for r in train],dtype=int)
 events = np.array([EVENTS.index(r['event']) for r in train])
 sa,sb = encode(train,test,PSWING_CATEGORICAL)
 propensity = fit_model(pswing_classifier(),sa,actions)
 raw_p = propensity.predict_proba(sb)[:,list(propensity.classes_).index(1)]
 p=raw_p.copy()
 calibration_applied=False
 if calibration:
  groups=np.array([r['game_id'] for r in train]);folds=min(3,len(set(groups)))
  if folds<2:raise ValueError('Calibration requires at least two training games')
  oof=np.empty(len(train));train_in=np.zeros(len(train),dtype=bool)
  for fit,held in GroupKFold(folds).split(sa,actions,groups):
   model=fit_model(pswing_classifier(),sa[fit],actions[fit])
   oof[held]=model.predict_proba(sa[held])[:,list(model.classes_).index(1)]
   if pzone_features is not None:
    train_in[held]=predict_pzone([train[i] for i in fit],[train[i] for i in held],pzone_features)>=.5
  # Always calibrate (za7.3). The former 80/20 date gate flipped between refits and moved player SBJ by
  # about 0.3 pp whenever it did (analysis/sbj_formula C0c/C0d).
  if len(set(actions))==2:
   calibrator=IsotonicRegression(out_of_bounds='clip',y_min=1e-6,y_max=1-1e-6).fit(oof,actions)
   p=calibrator.predict(raw_p);calibration_applied=True
   # za7.4: calibrate in-zone and out-of-zone pitches separately. Raw p_swing is under-confident only across
   # the zone edge, so one isotonic map over-corrected by zone side and left ABS-season league SBJ at -0.35
   # (analysis/sbj_formula K-B). Zone side is p_zone >= 0.5, out of fold for training rows.
   if pzone_features is not None:
    test_in=(predict_pzone(train,test,pzone_features) if test_pzone is None else np.asarray(test_pzone))>=.5
    for side in (True,False):
     m=train_in==side
     if len(set(actions[m]))==2:
      t=test_in==side
      p[t]=IsotonicRegression(out_of_bounds='clip',y_min=1e-6,y_max=1-1e-6).fit(oof[m],actions[m]).predict(raw_p[t])
 probs = np.zeros((len(test),6)); direct=np.zeros((len(test),2)); staged=direct.copy();unsmoothed=direct.copy()
 counts = Counter((support_key(r),r['decision_type']) for r in train)
 support = np.array([[counts[(support_key(r),action)] for action in ('Take','Swing')] for r in test])
 fine_counts=Counter((detailed_support_key(r),r['decision_type']) for r in train)
 detailed=np.array([[fine_counts[(detailed_support_key(r),action)] for action in ('Take','Swing')] for r in test])
 for act, indices in ((0,range(3,6)),(1,range(3))):
  mask = actions==act
  direct[:,act] = fit_model(old._regressor(len(DV_NUMERIC)),a[mask],target[mask]).predict(b)
  clf = fit_model(old._classifier(len(DV_NUMERIC)),a[mask],events[mask])
  pred = clf.predict_proba(b)
  for i,label in enumerate(clf.classes_): probs[:,int(label)]=pred[:,i]
  raw_probs=probs[:,list(indices)].copy()
  if act==1 and support_prior:
   weight=detailed[:,act]/(detailed[:,act]+support_prior)
   prior=probability_prior(train,test,actions,events,act,indices)
   probs[:,list(indices)]=weight[:,None]*raw_probs+(1-weight[:,None])*prior
  if not candidate: continue
  # Event RV priors back off event x count x base/out -> event x count -> event.
  for ev in indices:
   em = events==ev
   if ev!=2:
    values=np.array([re.event_value(_state(r,'before'),EVENTS[ev]) for r in test])
    staged[:,act]+=probs[:,ev]*values
    unsmoothed[:,act]+=raw_probs[:,list(indices).index(ev)]*values
    continue
   global_mean = float(np.mean(target[em])) if em.any() else float(np.mean(target[mask]))
   by_count, by_state = defaultdict(list), defaultdict(list)
   for j in np.flatnonzero(em):
    r=train[j]; by_count[(r['balls_before'],r['strikes_before'])].append(target[j]); by_state[_state(r,'before')].append(target[j])
   cm={k:(sum(v)+50*global_mean)/(len(v)+50) for k,v in by_count.items()}
   sm={k:(sum(v)+50*cm[k[2:]])/(len(v)+50) for k,v in by_state.items()}
   prior=np.array([sm.get(_state(r,'before'),cm.get(_state(r,'before')[2:],global_mean)) for r in test])
   values=prior
   if ev==2 and em.sum()>=160:
    model=fit_model(old._regressor(len(DV_NUMERIC)),a[em],target[em])
    local=Counter(support_key(train[j]) for j in np.flatnonzero(em))
    n=np.array([local[support_key(r)] for r in test]); weight=n/(n+50.)
    values=weight*model.predict(b)+(1-weight)*prior
   staged[:,act]+=probs[:,ev]*values
   unsmoothed[:,act]+=raw_probs[:,list(indices).index(ev)]*values
 return {'p':p,'raw_p':raw_p,'direct':direct,'staged':staged,'unsmoothed':unsmoothed,'probs':probs,'support':support,
         'detailed_support':detailed,'target':re.target(test),'re_diagnostics':re.diagnostics,'calibration_applied':calibration_applied}


def evaluation_metrics(test,pred):
 action=np.array([r['decision_type']=='Swing' for r in test],dtype=int); idx=np.arange(len(test))
 metrics={}
 for name in ('direct','staged','unsmoothed'):
  errors=(pred[name][idx,action]-pred['target'])**2
  metrics[name]={'mse':float(errors.mean()),'swing_mse':float(errors[action==1].mean()),'take_mse':float(errors[action==0].mean())}
 event_metrics={}
 labels=np.array([EVENTS.index(r['event']) for r in test])
 for name,act,inds in (('swing',1,list(range(3))),('take',0,list(range(3,6)))):
  mask=action==act
  event_metrics[name+'_log_loss']=float(log_loss(labels[mask],pred['probs'][mask][:,inds],labels=inds))
 calibration=[]
 for low in np.arange(0,1,.1):
  mask=(pred['p']>=low)&(pred['p']<low+.1)
  if mask.any():calibration.append({'low':r6(low),'n':int(mask.sum()),'predicted':float(pred['p'][mask].mean()),'observed':float(action[mask].mean())})
 return {'pitches':len(test),'swing_log_loss':float(log_loss(action,pred['p'])),'swing_brier':float(brier_score_loss(action,pred['p'])),
  'raw_swing_log_loss':float(log_loss(action,pred['raw_p'])),'raw_swing_brier':float(brier_score_loss(action,pred['raw_p'])),
  'action_value':metrics,'event_probability':event_metrics,'calibration_bins':calibration,'re':pred['re_diagnostics'],'calibration_applied':pred['calibration_applied']}


def temporal_evaluation(rows, pzone_features=None):
 dates=sorted({r['game_id'][:8] for r in rows})
 if len(dates)<10:raise ValueError('At least ten dates are required for temporal validation')
 dev_date,test_date=dates[int(len(dates)*.6)],dates[int(len(dates)*.8)]
 train=[r for r in rows if r['game_id'][:8]<dev_date]
 dev=[r for r in rows if dev_date<=r['game_id'][:8]<test_date]
 test=[r for r in rows if r['game_id'][:8]>=test_date]
 print('  Development',dev_date,len(train),len(dev),flush=True)
 predicted=fit_predict(train,dev,pzone_features=pzone_features)
 development=evaluation_metrics(dev,predicted)
 # Same algorithm as season scoring. p_swing calibration is fitted on training-game
 # OOF probabilities only, never with a scored/development/final-test outcome.
 settings=dict(SCORE_SETTINGS)
 print('  Final untouched test',test_date,len(test),settings,flush=True)
 predicted=fit_predict(train+dev,test,pzone_features=pzone_features,**settings)
 final=evaluation_metrics(test,predicted)
 return {'selected':'staged','settings':settings,'development_start':dev_date,'split_date':test_date,
  'train_pitches':len(train)+len(dev),'test_pitches':len(test),'development':development,'final_test':final,
  **{k:final[k] for k in ('swing_log_loss','swing_brier','action_value','event_probability')},
  'selection_rule':'60/20/20 dates: development diagnostics, then final evaluation with frozen algorithm. Each fit calibrates p_swing with isotonic regression on training-game OOF probabilities only. Final 20% never selects settings. Direct and unpooled RVs are diagnostic baselines.',
  'counterfactual_validation':'Observed-action errors and conditional intervals do not identify unobserved opposite-action outcomes.'}


def predict_pzone(train, test, fields):
 """old.predict_pzone averaged over PZONE_SEEDS: the take-only CalledStrike vs Ball/HBP model."""
 take=[r for r in train if r['decision_type']=='Take']
 target=np.array([str(r.get('pitch_call_code') or '').upper()=='T' or r.get('event')=='CalledStrike' for r in take],dtype=int)
 x,xt=old._encode_numeric(take,fields),old._encode_numeric(test,fields)
 probability=np.zeros(len(test))
 for seed in PZONE_SEEDS:
  model=old._classifier().set_params(random_state=seed).fit(x,target)
  probability+=model.predict_proba(xt)[:,list(model.classes_).index(1)]
 return np.clip(probability/len(PZONE_SEEDS),1e-6,1-1e-6)


def r6(x): return round(float(x),6)
def mean(items,key,scale=1): return r6(scale*np.mean([r[key] for r in items])) if items else None


def score_crossfit(rows, selected, settings=SCORE_SETTINGS, pzone_features=old.PZONE_NUMERIC):
 """Score every pitch with a model that excludes its date block."""
 dates=np.array(sorted({r['game_id'][:8] for r in rows})); result=[]; fold_meta=[]
 for fold,block in enumerate(np.array_split(dates,CROSSFIT_FOLDS)):
  held=set(block); train=[r for r in rows if r['game_id'][:8] not in held]; test=[r for r in rows if r['game_id'][:8] in held]
  print('  Scoring block',fold+1,len(test),flush=True)
  pzone=predict_pzone(train,test,pzone_features)
  pred=fit_predict(train,test,pzone_features=pzone_features,test_pzone=pzone,**settings)
  action=np.array([r['decision_type']=='Swing' for r in test],dtype=int)
  values=pred[selected]; dv=decision_value(action,values[:,1],values[:,0])
  for i,r in enumerate(test):
   r.update({'swing':int(action[i]),'p_swing':float(pred['p'][i]),'raw_p_swing':float(pred['raw_p'][i]),'p_zone':float(pzone[i]),'judgment':float((action[i]-pred['p'][i])*(2*pzone[i]-1)),'v_swing':float(values[i,1]),'v_take':float(values[i,0]),'delta_v':float(values[i,1]-values[i,0]),'dv':float(dv[i]),'opposite_support':int(pred['detailed_support'][i,1-action[i]]),'coarse_opposite_support':int(pred['support'][i,1-action[i]]),'fold':fold})
   for j,e in enumerate(EVENTS): r[f'p_{e}']=float(pred['probs'][i,j])
  result.extend(test); fold_meta.append({'start':str(block[0]),'end':str(block[-1]),'pitches':len(test),'re':pred['re_diagnostics'],'calibration_applied':pred['calibration_applied']})
 return result,fold_meta


def profile_summary(items):
 n=len(items); first=items[0]
 total=sum(r['dv'] for r in items)
 s={'season':first['season'],'batter_id':str(first['batter_id']),'batter_name':first['batter_name'],'team':team_history(items),'pitches_seen':n,'qualified_300':n>=300,'za_raw':zone_awareness(items),'dv_per_100':r6(100*total/n),'raw_dv':r6(total),'swing_aggression':r6(100*np.mean([r['swing']-r['p_swing'] for r in items])),'za_percentile':None,'low_opposite_support_pitches':sum(r['opposite_support']<30 for r in items)}
 # Decision DV (APR input): the chosen action's value above the league Swing policy on the same pitches, with the
 # policy shifted by the hitter's own aggression so APR scores where the hitter swung, not how often (gates.md X, B).
 excess=np.array([r['swing']-r['p_swing'] for r in items])
 jdv=2*(excess-excess.mean())*np.array([r['delta_v'] for r in items]); mean_jdv=float(jdv.mean())
 by_game=defaultdict(float)
 for r,v in zip(items,jdv): by_game[r['game_id']]+=v-mean_jdv
 s['jdv_per_100']=r6(100*mean_jdv); s['jdv_se']=r6(100*np.sqrt(sum(v*v for v in by_game.values()))/n)
 # ZA+ input: the same construction with the call margin (2*p_zone - 1) in place of the run value.
 zj=np.array([2*r['judgment'] for r in items]); mean_zj=float(zj.mean())
 by_game=defaultdict(float)
 for r,v in zip(items,zj): by_game[r['game_id']]+=v-mean_zj
 s['zj_per_100']=r6(100*mean_zj); s['zj_se']=r6(100*np.sqrt(sum(v*v for v in by_game.values()))/n)
 s['low_opposite_support_pct']=r6(100*s['low_opposite_support_pitches']/n)
 games=defaultdict(list)
 for r in items:games[r['game_id']].append(r['dv'])
 s['games_seen']=len(games)
 for action in ('swing','take'):
  selected=[r for r in items if r['swing']==(action=='swing')]
  s[action+'_pitches']=len(selected)
  s[action+'_decision_value_per_100']=r6(100*sum(r['dv'] for r in selected)/n)
  s[action+'_jdv_per_100']=r6(100*sum(v for r,v in zip(items,jdv) if r['swing']==(action=='swing'))/n)
 for reg in REGIONS:
  selected=[r for r in items if r['region']==reg]
  s[reg+'_pitches']=len(selected); s[reg+'_raw_dv']=r6(sum(r['dv'] for r in selected))
  s[reg+'_decision_value_per_100']=r6(100*sum(r['dv'] for r in selected)/n)
  for action in ('swing','take'):
   value=sum(r['dv'] for r in selected if r['swing']==(action=='swing'))
   s[f'{reg}_{action}_decision_value_per_100']=r6(100*value/n)
  # Zone Profile view: where APR's input was earned or lost, and how often the hitter swung there vs the league policy.
  in_reg=[(r,v) for r,v in zip(items,jdv) if r['region']==reg]
  s[reg+'_jdv_per_100']=r6(100*sum(v for _,v in in_reg)/n)
  for action in ('swing','take'):
   s[f'{reg}_{action}_jdv_per_100']=r6(100*sum(v for r,v in in_reg if r['swing']==(action=='swing'))/n)
  s[reg+'_swing_pct']=r6(100*np.mean([r['swing'] for r,_ in in_reg])) if in_reg else None
  s[reg+'_expected_swing_pct']=r6(100*np.mean([r['p_swing'] for r,_ in in_reg])) if in_reg else None
 return s


def cell_summary(items):
 return {'n':len(items),'low_opposite_support_pct':r6(100*np.mean([r['opposite_support']<30 for r in items])),'raw_dv':r6(sum(r['dv'] for r in items)),'dv100':mean(items,'dv',100),'za_raw':zone_awareness(items),'delta':mean(items,'delta_v'),'swing_pct':mean(items,'swing',100),'expected_swing_pct':mean(items,'p_swing',100),'p_zone_pct':mean(items,'p_zone',100),'zone_judgment_pct':r6(100*np.mean([r['p_zone'] if r['swing'] else 1-r['p_zone'] for r in items])),'expected_zone_judgment_pct':r6(100*np.mean([r['p_swing']*r['p_zone']+(1-r['p_swing'])*(1-r['p_zone']) for r in items])),'expected_swing_rv':mean(items,'v_swing'),'expected_take_rv':mean(items,'v_take'),**{f'p_{e}':mean(items,f'p_{e}',100) for e in EVENTS}}


def _plus_index(players, value_key, se_key, level, league_mean, out_key, pct_key):
 """wRC+-style index shared by APR and ZA+. Centre the per-100 input on the league, shrink toward it by pitches seen
 (n/(n+k), k estimated from qualified hitters), re-centre so the pitch-weighted league mean is exactly 100, then scale
 by the league level. Percentiles rank every hitter against qualified hitters only (analysis/sbj_formula W-b)."""
 n=np.array([p['pitches_seen'] for p in players],dtype=float)
 centred=np.array([p[value_key] for p in players],dtype=float)-league_mean
 se=np.array([p[se_key] for p in players],dtype=float); q=np.array([p['qualified_300'] for p in players])
 k=np.inf
 if q.sum()>2:
  sigma2=float(np.median(se[q]**2*n[q])); tau2=float(np.var(centred[q],ddof=1)-np.mean(se[q]**2))
  if tau2>0: k=sigma2/tau2
 shrunk=n/(n+k)*centred if np.isfinite(k) else np.zeros(len(players))
 shrunk-=float((shrunk*n).sum()/n.sum())
 index=100*(level+shrunk)/level
 reference=np.sort(index[q])
 for p,value in zip(players,index):
  p[out_key]=r6(value)
  if len(reference):
   lo,hi=np.searchsorted(reference,value,'left'),np.searchsorted(reference,value,'right')
   p[pct_key]=r6(100*(lo+.5*(hi-lo))/len(reference))
  else: p[pct_key]=None
 return r6(k) if np.isfinite(k) else None


def add_apr(players, league_dv_per_100, league_jdv_per_100):
 """APR: wRC+-style decision value on league DV/100."""
 k=_plus_index(players,'jdv_per_100','jdv_se',league_dv_per_100,league_jdv_per_100,'apr','apr_percentile')
 return {'league_dv_per_100':r6(league_dv_per_100),'league_jdv_per_100':r6(league_jdv_per_100),'shrinkage_k_pitches':k}


def add_za_plus(players, league_margin_per_100, league_zj_per_100):
 """ZA+: the APR construction on the judgment margin (2S - 1)(2*p_zone - 1) instead of run value."""
 k=_plus_index(players,'zj_per_100','zj_se',league_margin_per_100,league_zj_per_100,'za_plus','za_percentile')
 return {'league_margin_per_100':r6(league_margin_per_100),'league_zj_per_100':r6(league_zj_per_100),'shrinkage_k_pitches':k}


def write_web(root,season,pitches,report,output_root=None):
 output_root=output_root or root
 dest=output_root/'web/data/zone_awareness'/str(season); dest.mkdir(parents=True,exist_ok=True)
 by_batter=defaultdict(list)
 for r in pitches: by_batter[str(r['batter_id'])].append(r)
 players=[profile_summary(items) for items in by_batter.values()]
 # PA counts every PA-ending pitch in the season (leaderboard_vb's definition), not only the pitches eligible for judgment.
 plate_appearances=Counter(str(r['batter_id']) for r in load_curated_rows(root,'pitches',season,columns=['batter_id','is_pa_terminal']) if r['is_pa_terminal'])
 for p in players: p['pa']=plate_appearances.get(p['batter_id'],0)
 # League decision DV: the pitch-weighted mean of each hitter's input, so the formula stays in profile_summary().
 apr_meta=add_apr(players,100*float(np.mean([r['dv'] for r in pitches])),sum(p['jdv_per_100']*p['pitches_seen'] for p in players)/len(pitches))
 report['apr']=apr_meta
 report['za_plus']=add_za_plus(players,100*float(np.mean([(2*r['swing']-1)*(2*r['p_zone']-1) for r in pitches])),100*float(np.mean([2*r['judgment'] for r in pitches])))
 def dump(path,payload): write_json(path,payload,allow_nan=False)
 dump(dest/'leaderboard.json',{'schema_version':6,'model_version':MODEL_VERSION,'season':season,'minimum_pitches':300,'qualified_batters':sum(p['qualified_300'] for p in players),'players':players,'apr':report['apr'],'za_plus':report['za_plus'],'metric_contract':CONTRACT,'selected_value_model':report['validation']['selected'],'data_quality':report['source']['quality'],'pzone_input':report['source'].get('pzone_input'),'settings':report['validation']['settings']})
 dump(dest/'teams.json',{'season':season,'teams':{p['batter_id']:p['team'] for p in players}})
 shards=defaultdict(dict)
 for p in players:
  bid=p['batter_id']; items=by_batter[bid]; cells=defaultdict(list)
  for r in items:
   x,z=r['x_relative'],r['z_relative']
   if abs(x)<=2.5 and abs(z)<=2.5: cells[(round(x/.5)*.5,round(z/.5)*.5)].append(r)
  shards[bid[:2] if bid[0].isdigit() else 'other'][bid]={'summary':p,'overall':cell_summary(items),'grid':[{'x':x,'z':z,**cell_summary(rs)} for (x,z),rs in sorted(cells.items())]}
 pd=dest/'players';pd.mkdir(exist_ok=True)
 for path in pd.glob('*.json'): path.unlink()
 for shard,entries in shards.items(): dump(pd/f'{shard}.json',{'schema_version':5,'season':season,'players':entries})
 catalog=output_root/'web/data/zone_awareness/index.json'
 previous=json.loads(catalog.read_text(encoding='utf-8')) if catalog.exists() else {'seasons':[]}
 previous.update({'schema_version':5,'seasons':sorted(set(previous['seasons'])|{season},reverse=True)})
 previous['default_season']=max(previous['seasons']);dump(catalog,previous)
 old._write_csv(output_root/'exports'/f'zone_decision_players_{season}.csv',players)
 return players


def build_zone_decision(root,season=2026):
 print('ZA season',season,flush=True)
 rows,source=load_rows(root,season)
 output_root=root
 validation=temporal_evaluation(rows,pzone_fields(season))
 selected=validation['selected'];print('  Selected:',selected,flush=True)
 # Metric changes stay local to zone_awareness(), decision_value(), and
 # profile_summary(); this function only orchestrates model output.
 result,fold_meta=score_crossfit(rows,selected,SCORE_SETTINGS,pzone_fields(season))
 # One report: observed fit, period reproducibility and opposite-action support.
 # Until za7.3 this correlated DV only, under a name that read as SBJ; both metrics are now reported by name.
 stability={}
 for metric,key in (('sbj','judgment'),('dv','dv')):
  periods=defaultdict(lambda:defaultdict(list))
  for r in result: periods[r['fold']][str(r['batter_id'])].append(r[key])
  stability[metric]=[]
  for a,b in ((0,1),(1,2),(0,2)):
   ids=[k for k,v in periods[a].items() if len(v)>=150 and len(periods[b].get(k,[]))>=150]
   x=[np.mean(periods[a][k]) for k in ids];y=[np.mean(periods[b][k]) for k in ids]
   corr=float(np.corrcoef(x,y)[0,1]) if len(ids)>2 and np.std(x)>0 and np.std(y)>0 else None
   stability[metric].append({'blocks':[a+1,b+1],'batters_150_pitches_each':len(ids),'pearson_r':corr,'interpretation':'descriptive repeatability; cross-fit training overlaps, not independent prospective validation'})
 support={reg:{'pitches':sum(r['region']==reg for r in result),'opposite_action_under_30':sum(r['region']==reg and r['opposite_support']<30 for r in result)} for reg in REGIONS}
 report={'schema_version':5,'model_version':MODEL_VERSION,'season':season,'source':source,'pitches':len(result),'validation':validation,'period_reproducibility':stability,'opposite_action_support':support,
  'support_definition':'Opposite-action counts: normalized 0.5 location cell x count x pitch type x stance x 10 km/h velocity x 10 cm HB/IVB bins. Diagnostic neighborhood, not proof of causal overlap.',
  'score_settings':{**SCORE_SETTINGS,'policy':'Fixed before outcome inspection; game-block exclusions apply to calibration, RE, models and priors.'},
  'crossfit_blocks':fold_meta,'metric_contract':CONTRACT,'shrinkage':'Constrained shared RE; exact ordinary event transitions; sparse Swing probabilities blend to training-only count/region/type/stance priors with n/(n+50). InPlay RV retains state shrinkage.',
  'reproducibility':{'python':platform.python_version(),'packages':{p:version(p) for p in ('numpy','pandas','pyarrow','scikit-learn','scipy','openpyxl')},'source_sha256':{p.name:file_hash(p) for p in (Path(__file__),Path(old.__file__),Path(__file__).with_name('swing_take.py'),Path(__file__).with_name('pitch_types.py'),Path(__file__).with_name('batter_stance.py'))}},
  'limitations':LIMITATIONS}
 players=write_web(root,season,result,report,output_root)
 report['batters']=len(players)
 path=root/'data/metrics/zone_awareness'/str(season)/'report.json';path.parent.mkdir(parents=True,exist_ok=True)
 write_json(path,report,compact=False,allow_nan=False)
 # Compact pitch evidence is reproducible; not committed as a large binary.
 evidence_cache=root/'data/metrics/zone_awareness'/str(season)
 evidence_cache.mkdir(parents=True,exist_ok=True)
 pq.write_table(pa.Table.from_pylist([{k:v for k,v in r.items() if k not in ('adjusted_hb_cm','adjusted_ivb_cm')+DV_MOVEMENT} for r in result]),evidence_cache/'pitches.parquet')
 return report

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--root',default='.');parser.add_argument('--seasons',nargs='+',type=int,default=[2024,2025,2026]);args=parser.parse_args()
 for year in args.seasons: build_zone_decision(Path(args.root).resolve(),year)
