"""경량 인계 묶음에서 보존 입력·계수·잔차 재적합을 확인한다."""
import json
import numpy as np
import pandas as pd

from visualbaseball.estimated_arm_angle import _predict
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from run_conditional_eaa_20261006 import ROOT, OUT, sha
from pitch_joint_eaa_features import assemble_mlb, assemble_kbo, subset
from orthogonal_residual_eaa_models import fit_all, predict_all, portable, OPTIONS

PREFIX = 'eaa_orthogonal_residual_20261006'
EXPECTED_V3 = '484c6de37dc835f7551e69dbaa8550fe54bf6a086ec3483898140eee907ae84b'


class FrozenAnchor:
    def __init__(self, model):
        self.model = model

    def predict(self, inputs):
        return np.array([_predict(self.model['angle'], x) for x in inputs])


def main():
    v3_path = ROOT/'data/models/estimated_arm_angle_v3.json'
    assert sha(v3_path)==EXPECTED_V3
    baseline = json.loads(v3_path.read_text())
    snapshot = json.loads((OUT/(PREFIX+'_candidate_models.json')).read_text())
    d, stats, _ = assemble_mlb()
    kbo, ks, _ = assemble_kbo()
    models = {'baseline': FrozenAnchor(baseline), 'corrections': snapshot['models']}
    expected = pd.read_csv(OUT/(PREFIX+'_KBO2026_predictions.csv'), dtype={'pitcher_id': str})
    np.testing.assert_array_equal(kbo.pitcher, expected.pitcher_id)
    clean = kbo.drop(columns=['arm_angle'], errors='ignore')
    actual, _ = predict_all(models, clean, ks)
    prediction_difference = max(float(abs(actual[name]-expected[name]).max()) for name in OPTIONS)
    for name in OPTIONS:
        np.testing.assert_allclose(actual[name], expected[name], atol=1e-8, rtol=0)
    tr = np.flatnonzero(d.fixed_training_row)
    refitted = fit_all(d.iloc[tr], subset(stats, tr))
    encoded = portable(refitted)
    coefficient_difference = max(float(abs(np.asarray(encoded[f]['coef'])-snapshot['models'][f]['coef']).max())
                                 for f in encoded)
    assert coefficient_difference<1e-8
    fitted_prediction, _ = predict_all(refitted, clean, ks)
    for name in OPTIONS:
        np.testing.assert_allclose(fitted_prediction[name], expected[name], atol=1e-8, rtol=0)
    print(json.dumps({'passed': True, 'MLB_seasons': len(d), 'MLB_players': int(d.pitcher.nunique()),
                      'fixed_training_seasons': len(tr), 'KBO2026_players': len(kbo),
                      'prediction_max_difference_deg': prediction_difference,
                      'refit_coefficient_max_difference': coefficient_difference,
                      'raw_pitch_source_verification_performed': False,
                      'full_original_data_required_for_original_source_audits': True,
                      'production_model_unchanged': True}, ensure_ascii=False, indent=2))


if __name__=='__main__':
    main()
