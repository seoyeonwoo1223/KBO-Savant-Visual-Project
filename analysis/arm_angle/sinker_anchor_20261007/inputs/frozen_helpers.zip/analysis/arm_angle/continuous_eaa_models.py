"""2026 연구 후보: 표본 수 연속 수축과 IVB 조건부 기하 모델 혼합."""
import numpy as np
from scipy.special import expit
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES, MOVEMENT
from multi_pitch_eaa_features import (
    GROUPS, FULL_EXTRA, DELTA_COLUMNS, expert_frame, training_weights, exposure_weights,
)
from multi_pitch_eaa_models import ridge_fit, SEED

OPTIONS = ('baseline', 'smooth_multi8', 'smooth_multi5', 'geom_mix5_025',
           'geom_mix5_050', 'smooth_mix5_025', 'smooth_mix5_050')
NUMERIC_EXTRA = [f'type_{g}_{c}' for g in GROUPS[1:] for c in DELTA_COLUMNS+MOVEMENT]


def count_confidence(count):
    """측정 정확도가 아닌 학습·결합용 사전 고정 표본 수 가중치."""
    count = np.asarray(count, float)
    u = np.clip((np.where(np.isfinite(count), count, 0.)-30.)/30., 0., 1.)
    return u*u*(3.-2.*u)


def continuous_consensus(values, counts):
    """연속 가중 pseudo-Huber 중심: 가중 중앙값의 분기점도 피한다."""
    values, counts = np.asarray(values, float), np.asarray(counts, float)
    observed = np.isfinite(values)&np.isfinite(counts)&(counts>30)
    weights = np.where(observed, count_confidence(counts)*np.sqrt(np.minimum(np.maximum(counts, 0), 200)), 0.)
    active = weights.sum(axis=1)>0
    safe = np.where(observed, values, 0.)
    lower = np.where(active, np.min(np.where(observed, values, np.inf), axis=1), 0.)
    upper = np.where(active, np.max(np.where(observed, values, -np.inf), axis=1), 0.)
    for _ in range(48):
        middle = (lower+upper)/2
        residual = middle[:, None]-safe
        gradient = (weights*residual/np.sqrt(1+(residual/4.)**2)).sum(axis=1)
        lower = np.where(gradient<0, middle, lower)
        upper = np.where(gradient>=0, middle, upper)
    return np.where(active, (lower+upper)/2, np.nan)


def smooth_extra(d, medians):
    """학습 중앙값으로 연속 수축. 결측값을 관측 0으로 처리하지 않는다."""
    raw = d[FULL_EXTRA].to_numpy(float)
    result = raw.copy(); uncertainty = []
    for i, name in enumerate(FULL_EXTRA):
        if name.endswith('_available'):
            kind = name.split('_')[1]
            frame = expert_frame(d, kind).to_numpy(float)
            result[:, i] = count_confidence(d[f'type_{kind}_count'])*np.isfinite(frame).all(axis=1)
        elif name in NUMERIC_EXTRA:
            kind = name.split('_')[1]
            r = count_confidence(d[f'type_{kind}_count'])*np.isfinite(raw[:, i])
            observed = np.where(np.isfinite(raw[:, i]), raw[:, i], medians[i])
            result[:, i] = medians[i]+r*(observed-medians[i])
            uncertainty.append(1-r)
        else:
            result[:, i] = np.where(np.isfinite(raw[:, i]), raw[:, i], medians[i])
    return np.column_stack([result, np.column_stack(uncertainty)])


def multi_fit(d):
    raw = d[FULL_EXTRA].to_numpy(float)
    medians = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in raw.T])
    poly = PolynomialFeatures(2, include_bias=False)
    base = poly.fit_transform(d[MODEL_FEATURES].to_numpy(float))
    design = np.column_stack([base, smooth_extra(d, medians)])
    model = make_pipeline(StandardScaler(), Ridge(alpha=100))
    weights = training_weights(d)
    model.fit(design, d.arm_angle.to_numpy(float), standardscaler__sample_weight=weights,
              ridge__sample_weight=weights)
    return {'poly': poly, 'medians': medians, 'model': model}


def multi_predict(model, d):
    design = np.column_stack([model['poly'].transform(d[MODEL_FEATURES].to_numpy(float)),
                              smooth_extra(d, model['medians'])])
    return model['model'].predict(design)


def fit_continuous_experts(d):
    models = {'FF': ridge_fit(d, MODEL_FEATURES)}
    for kind in GROUPS[1:]:
        frame = expert_frame(d, kind)
        r = count_confidence(d[f'type_{kind}_count'])
        valid = np.isfinite(frame).all(axis=1).to_numpy()&(r>0)
        subset = d.loc[valid].copy(); subset[MODEL_FEATURES] = frame.loc[valid]
        if subset.pitcher.nunique()<25:
            models[kind] = None; continue
        model = make_pipeline(SimpleImputer(strategy='median', keep_empty_features=True),
                              PolynomialFeatures(2, include_bias=False), StandardScaler(), Ridge(alpha=100))
        weights = training_weights(subset)*r[valid]; weights /= weights.mean()
        models[kind] = model.fit(subset[MODEL_FEATURES].to_numpy(float), subset.arm_angle.to_numpy(float),
                                standardscaler__sample_weight=weights, ridge__sample_weight=weights)
    return models


def apply_continuous_experts(models, d):
    matrix = np.full((len(d), len(GROUPS)), np.nan)
    for i, kind in enumerate(GROUPS):
        if models[kind] is None: continue
        frame = expert_frame(d, kind)
        valid = np.isfinite(frame).all(axis=1).to_numpy()
        if kind!='FF': valid &= count_confidence(d[f'type_{kind}_count'])>0
        if valid.any(): matrix[valid, i] = models[kind].predict(frame.loc[valid].to_numpy(float))
    return matrix


def fit_all(d):
    d = d.reset_index(drop=True)
    deficits = {5: np.full(len(d), np.nan), 8: np.full(len(d), np.nan)}
    for train, val in GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=d.pitcher):
        assert set(d.iloc[train].pitcher).isdisjoint(d.iloc[val].pitcher)
        for count in deficits:
            aux = ridge_fit(d.iloc[train], MODEL_FEATURES[:count],
                            target=d.iloc[train].ff_ivb_in.to_numpy(float), auxiliary=True)
            deficits[count][val] = d.iloc[val].ff_ivb_in.to_numpy()-aux.predict(d.iloc[val][MODEL_FEATURES[:count]].to_numpy(float))
    thresholds = {n: float(np.quantile(a, .25)) for n, a in deficits.items()}
    scales = {n: float(max(1., .5*np.subtract(*np.quantile(a, [.75, .25])))) for n, a in deficits.items()}
    aux = {n: ridge_fit(d, MODEL_FEATURES[:n], target=d.ff_ivb_in.to_numpy(), auxiliary=True) for n in deficits}
    return {'experts': fit_continuous_experts(d), 'multi': multi_fit(d),
            'geometry': ridge_fit(d, MODEL_FEATURES[:8]), 'aux': aux,
            'thresholds': thresholds, 'scales': scales,
            'gate_thresholds_player_crossfit': True}


def predict_all(models, d):
    matrix = apply_continuous_experts(models['experts'], d)
    base = matrix[:, 0]; multi = multi_predict(models['multi'], d)
    geometry = models['geometry'].predict(d[MODEL_FEATURES[:8]].to_numpy(float))
    counts = d[[f'type_{g}_count' for g in GROUPS[1:]]].to_numpy(float)
    r = count_confidence(counts)*np.isfinite(matrix[:, 1:])
    confidence = np.sort(r, axis=1)[:, -2]
    alt = continuous_consensus(matrix[:, 1:], counts)
    alt = np.where(np.isfinite(alt), alt, base)
    protection = expit((base-30)/3)*expit((65-base)/3)
    deficits = {n: d.ff_ivb_in.to_numpy()-m.predict(d[MODEL_FEATURES[:n]].to_numpy(float)) for n, m in models['aux'].items()}
    gates = {n: expit((models['thresholds'][n]-a)/models['scales'][n]) for n, a in deficits.items()}
    proposal = multi+np.clip(alt-multi, 0., 10.)
    corrections = {n: gates[n]*protection*confidence*np.clip(proposal-base, 0., 10.) for n in gates}
    result = {'baseline': base, 'smooth_multi8': base+corrections[8], 'smooth_multi5': base+corrections[5]}
    for limit, label in [(.25, '025'), (.50, '050')]:
        weight = limit*gates[5]*protection
        result['geom_mix5_'+label] = base+weight*np.clip(geometry-base, 0., 10.)
        start = result['smooth_multi5']
        # 순차 혼합: 이미 올린 다구종 중심값에 기하 모델이 지지하는 추가분만 반영.
        result['smooth_mix5_'+label] = start+weight*np.minimum(np.clip(geometry-start, 0., 10.),
                                                              np.maximum(0., 10.-(start-base)))
    details = {'expert_predictions': matrix, 'IVB_deficit_in': deficits[5],
        'IVB_deficit8_in': deficits[8], 'gate': gates[5], 'gate8': gates[8],
        'nonFF_experts': (r>0).sum(axis=1), 'count_confidence': confidence,
        'protection_weight': protection, 'multi_angle_deg': multi,
        'nonFF_angle_deg': alt, 'geometry_angle_deg': geometry, 'type_confidence': r}
    assert set(result)==set(OPTIONS) and all(np.isfinite(x).all() for x in result.values())
    return result, details
