"""잔차 후보 선택 고정 뒤 재사용 기간과 실제 입력 연속성을 점검한다."""
import json
import pickle
import numpy as np
import pandas as pd

from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from multi_pitch_eaa_features import multi_inputs, ALIASES, training_weights
from run_conditional_eaa_20261006 import ROOT, OUT, FOCUS, sha, save, gain
from run_eaa_low_ivb_20261006 import masks
from pitch_joint_eaa_features import (
    CACHE as SOURCE_CACHE, MLB_FIELDS, assemble_mlb, assemble_kbo,
    adapt_mlb, moments, subset,
)
from orthogonal_residual_eaa_models import (
    OPTIONS, FAMILIES, predict_all, new_matrix, base_matrix, apply_projection,
)
from run_eaa_orthogonal_residual_20261006 import CACHE, PREFIX


def predict_query(models, q):
    frame = multi_inputs(q)
    frame['pitcher'] = frame.index.astype(str)
    frame['season'] = int(q.season.iloc[0])
    order = pd.MultiIndex.from_frame(frame[['pitcher', 'season']])
    stats, _ = moments(q, order=order)
    return predict_all(models, frame, stats)[0]


def period_table(q, observed, models, period, reference_ids, training_ids):
    inputs = multi_inputs(q)
    valid = inputs.n.ge(100)&inputs.n_ff.ge(100)&np.isfinite(inputs[MODEL_FEATURES]).all(axis=1)
    frame = inputs.loc[valid].copy()
    frame['pitcher'] = frame.index.astype(str)
    frame['season'] = 2025
    order = pd.MultiIndex.from_frame(frame[['pitcher', 'season']])
    keep = q.pitcher_id.isin(frame.pitcher)&q.numeric_valid
    stats, _ = moments(q.loc[keep].reset_index(drop=True), order=order)
    predictions, _ = predict_all(models, frame, stats)
    labels = pd.DataFrame({'pitcher': q.pitcher_id.to_numpy(), 'angle': observed})
    labels = labels.loc[q.numeric_valid.to_numpy()].groupby('pitcher').angle.agg(['mean', 'count', 'size'])
    table = frame[['pitcher', 'season', 'n', 'n_ff', 'ff_ivb_in', 'ff_speed55', 'left_hand']].copy()
    table['arm_angle'] = labels['mean']
    table['observed_angle_count'] = labels['count']
    table['observed_angle_coverage'] = labels['count']/labels['size']
    table['seen_in_reference'] = table.pitcher.isin(reference_ids)
    table['seen_in_fixed_training'] = table.pitcher.isin(training_ids)
    for name, values in predictions.items():
        table[name] = values
    table['period'] = period
    return table.loc[table.observed_angle_coverage.ge(.95)].reset_index(drop=True)


def period_metrics(table, report):
    groups = masks(table)
    groups['unseen_reference'] = ~table.seen_in_reference
    groups['unseen_fixed_training'] = ~table.seen_in_fixed_training
    metrics, gains, coverage = {}, {}, {}
    for group, mask in groups.items():
        q = table.loc[mask]
        metrics[group] = {'players': int(q.pitcher.nunique()), 'models': {}}
        coverage[group] = {}
        gains[group] = {}
        for name in OPTIONS:
            e = q[name]-q.arm_angle
            metrics[group]['models'][name] = {
                'MAE': float(e.abs().mean()) if len(q) else None,
                'bias': float(e.mean()) if len(q) else None}
            offset = report['intervals'][name]
            covered = q.arm_angle.between(q[name]+offset['lower_residual_deg'], q[name]+offset['upper_residual_deg'])
            coverage[group][name] = {'players': len(q), 'covered': int(covered.sum()),
                                    'coverage': float(covered.mean()) if len(q) else None}
            if len(q) and name!='baseline':
                gains[group][name] = gain(table, table.baseline.to_numpy(), table[name].to_numpy(), np.asarray(mask))
    return {'metrics': metrics, 'paired_player_MAE_gains': gains, 'interval_coverage': coverage}


def reused_periods(models, selected, report, lock, d):
    tables, periods, manifests = [], {}, []
    inputs = [ROOT/'.cache/arm_angle/low_ivb_20261006/type_targets/external2025/manifest.json',
              SOURCE_CACHE/'external2025/manifest.json']
    for mpath in inputs:
        metadata = json.loads(mpath.read_text())
        parts, labels = [], []
        for source in metadata['sources']:
            path = ROOT/source['path']
            assert sha(path)==source['sha256'] and source['rows']<25000
            if not source['rows']:
                continue
            # 관측 각도는 입력 경로에서 제외한다. 이미 사용했던 자료임을 명시한다.
            parts.append(pd.read_csv(path, usecols=MLB_FIELDS, dtype={'pitcher': str}))
            labels.append(pd.read_csv(path, usecols=['game_pk', 'at_bat_number', 'pitch_number', 'arm_angle']))
        raw, lab = pd.concat(parts, ignore_index=True), pd.concat(labels, ignore_index=True)
        assert len(raw)==metadata['raw_rows'] and raw.game_year.eq(2025).all()
        assert raw.game_type.eq('R').all() and not raw.duplicated(['game_pk', 'at_bat_number', 'pitch_number']).any()
        keys = ['game_pk', 'at_bat_number', 'pitch_number']
        assert lab[keys].equals(raw[keys])
        bio = pd.DataFrame([{'pitcher': pid, 'height_cm': b['height_cm'], 'pitch_hand': b['hand']}
                            for pid, b in metadata['bios'].items()])
        q = adapt_mlb(raw, bio)
        assert q[keys].equals(raw[keys])
        observed = lab.arm_angle.where(lab.arm_angle.between(-90, 90)).to_numpy()
        windows = [(s, raw.game_date.str.startswith(s)) for s in sorted(raw.game_date.str[:7].unique())]
        if len(windows)>1:
            windows.append(('2025-08_to_09', pd.Series(True, index=raw.index)))
        for period, mask in windows:
            table = period_table(q.loc[mask].reset_index(drop=True), observed[mask], models, period,
                                 set(d.pitcher), set(d.loc[d.fixed_training_row, 'pitcher']))
            table['name'] = table.pitcher.map(lambda p: metadata['bios'][p]['name'])
            tables.append(table)
            periods[period] = period_metrics(table, report)
            print('재사용 기간 확인', period, len(table), flush=True)
        manifests.append({'path': str(mpath.relative_to(ROOT)), 'sha256': sha(mpath),
                          'sources': metadata['sources']})
    assert sha(OUT/(PREFIX+'_model_report.json'))==lock
    pd.concat(tables, ignore_index=True).to_csv(OUT/(PREFIX+'_reused2025_predictions.csv'), index=False)
    result = {'periods': periods, 'source_manifests': manifests,
              'evaluation_is_reused_not_new_independent_confirmation': True,
              'selected_before_evaluation': selected, 'selected_after_evaluation': selected,
              'external_labels_used_for_training_or_reselection': False,
              'locked_model_report_sha256': lock, 'KBO_accuracy_verified': False}
    save(OUT/(PREFIX+'_reused2025_report.json'), result)
    return result


def stability(models):
    q = pd.read_parquet(SOURCE_CACHE/'kbo_pitches.parquet')
    scenario, samples = [], []
    for pid in ['56318', '54362', '68341', '67143', '52701']:
        original = q.loc[q.pitcher_id.eq(pid)].reset_index(drop=True)
        kinds = original.pitch_type_code.replace(ALIASES)
        counts = kinds.loc[~kinds.eq('FF')].value_counts()
        kind = counts.index[0]
        assert counts.iloc[0]>=60
        chosen, other = original.loc[kinds.eq(kind)], original.loc[~kinds.eq(kind)]
        for repeat in range(20):
            permutation = np.random.default_rng(20261006+repeat).permutation(len(chosen))
            for count in [29, 30, 31]:
                part = pd.concat([other, chosen.iloc[permutation[:count]]], ignore_index=True)
                pred = predict_query(models, part)
                samples.append({'pitcher_id': pid, 'name': FOCUS[pid], 'kind': kind,
                                'repeat': repeat, 'type_count': count,
                                **{n: float(p[0]) for n, p in pred.items()}})
    for pid in FOCUS:
        original = q.loc[q.pitcher_id.eq(pid)].reset_index(drop=True)
        ff = original.pitch_type_code.eq('FF')
        for delta in np.linspace(-4, 4, 33):
            part = original.copy()
            hb = original.loc[ff, 'movement_size_m']*original.loc[ff, 'movement_axis_arm_sin']
            ivb = original.loc[ff, 'movement_size_m']*original.loc[ff, 'movement_axis_up_cos']+delta*.0254
            size = np.hypot(hb, ivb)
            part.loc[ff, 'movement_size_m'] = size
            part.loc[ff, 'movement_axis_arm_sin'] = hb/size
            part.loc[ff, 'movement_axis_up_cos'] = ivb/size
            pred = predict_query(models, part)
            scenario.append({'pitcher_id': pid, 'name': FOCUS[pid], 'IVB_delta_in': float(delta),
                             **{n: float(p[0]) for n, p in pred.items()},
                             'observed_arm_angle_or_Y2Y': False})
    sample, ivb = pd.DataFrame(samples), pd.DataFrame(scenario)
    sample.to_csv(OUT/(PREFIX+'_actual_resampling.csv'), index=False)
    ivb.to_csv(OUT/(PREFIX+'_IVB_continuity.csv'), index=False)
    jumps, ivbjumps = {}, {}
    for name in OPTIONS:
        wide = sample.pivot(index=['pitcher_id', 'repeat'], columns='type_count', values=name)
        delta = abs(np.diff(wide[[29, 30, 31]].to_numpy(), axis=1)).ravel()
        jumps[name] = {'adjacent_steps': len(delta), 'max_deg': float(delta.max()),
                       'p95_deg': float(np.quantile(delta, .95))}
        ivbjumps[name] = float(ivb.groupby('pitcher_id')[name].apply(lambda s: abs(np.diff(s)).max()).max())
    return {'actual_nested_resampling': jumps, 'IVB_max0p25inch_step_deg': ivbjumps,
            'physical_angle_change_verified': False}


def projection_audit(models, d, stats, kbo, ks):
    training = d.fixed_training_row.to_numpy()
    populations = [('training', d.loc[training], subset(stats, np.flatnonzero(training))),
                   ('fixed2024', d.loc[d.eval2024_independent_train_and_calibration_player],
                    subset(stats, np.flatnonzero(d.eval2024_independent_train_and_calibration_player))),
                   ('KBO2026', kbo, ks)]
    rows, diagnostic = [], {}
    for family, model in models['corrections'].items():
        info = {}
        for label, frame, values in populations:
            z = new_matrix(frame, values, model['medians'], family)
            residual = apply_projection(model['projection'], base_matrix(frame), z)
            max_coord = abs(residual).max(axis=1)
            raw = residual@model['coef']
            gap = residual@model['OOF_refit_gap_diagnostic_coef']
            corrected = 5*np.tanh(raw/5)
            w = training_weights(frame) if label=='training' else np.ones(len(frame))
            info[label] = {'rows': len(frame), 'features_retained': residual.shape[1],
                'max_abs_standardized_coordinate_p50_p95_max': np.quantile(max_coord, [.5, .95, 1.]).tolist(),
                'raw_correction_weighted_mean': float(np.average(raw, weights=w)),
                'bounded_correction_weighted_mean': float(np.average(corrected, weights=w)),
                'raw_correction_RMS': float(np.sqrt(np.mean(raw**2))),
                'OOF_refit_gap_component_RMS': float(np.sqrt(np.mean(gap**2))),
                'gap_component_is_a_training_diagnostic_not_measured_KBO_error': True}
            for pid, norm, delta, component in zip(frame.pitcher, max_coord, raw, gap):
                rows.append({'population': label, 'family': family, 'pitcher_id': pid,
                             'max_abs_standardized_coordinate': norm, 'raw_correction_deg': delta,
                             'OOF_refit_gap_component_deg': component})
        diagnostic[family] = info
    pd.DataFrame(rows).to_csv(OUT/(PREFIX+'_projection_diagnostic.csv'), index=False)
    return diagnostic


def main():
    report_path = OUT/(PREFIX+'_model_report.json')
    report = json.loads(report_path.read_text())
    lock = sha(report_path)
    assert report['sha256']['models']==sha(ROOT/'analysis/arm_angle/orthogonal_residual_eaa_models.py')
    with (CACHE/'fixed_models.pkl').open('rb') as f:
        models = pickle.load(f)
    d, stats, _ = assemble_mlb()
    kbo, ks, _ = assemble_kbo()
    selected = report['selected_train_only']
    reused = reused_periods(models, selected, report, lock, d)
    stable = stability(models)
    projection = projection_audit(models, d, stats, kbo, ks)
    table = pd.read_csv(OUT/(PREFIX+'_mlb_predictions.csv'), dtype={'pitcher': str})
    candidate_gains = {name: {group: gain(table, table.baseline.to_numpy(), table[name].to_numpy(), mask.to_numpy())
        for group, mask in masks(table).items() if group in ['all', 'middle35_60', 'high60', 'matched_low_IVB']}
        for name in OPTIONS if name!='baseline'}
    assert sha(report_path)==lock
    assert report['sha256']['frozen_v3']==sha(ROOT/'data/models/estimated_arm_angle_v3.json')
    audit = {'locked_model_report_sha256': lock, 'selected_before_and_after_reuse': selected,
             'candidate_player_paired_gains_diagnostic_not_posthoc_selection': candidate_gains,
             'stability': stable, 'projection': projection,
             'evaluation_is_reused_not_new_independent_confirmation': True,
             'production_changed': False, 'operational_interval_narrowed': False,
             'operational_promotion_approved': False,
             'hold_reasons': ['사전 고정한 낮은 IVB 절대 편향 0.30도 개선 조건 미달',
                              '기존 평가 기간 재사용으로 새 독립 확증은 확보하지 않음'],
             'KBO_accuracy_verified': False}
    save(OUT/(PREFIX+'_completion_audit.json'), audit)
    print('직교 잔차 감사 완료', selected, '운영 유지', flush=True)


if __name__=='__main__':
    main()
