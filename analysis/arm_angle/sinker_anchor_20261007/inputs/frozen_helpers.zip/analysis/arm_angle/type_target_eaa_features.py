"""같은 유효 투구의 구종별 관측 각도를 학습용 별도 컬럼으로 연결한다."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES, KINEMATICS, MOVEMENT, pitch_features, G, FT_M
from direct_numeric_features import mlb_adapter
from multi_pitch_eaa_features import GROUPS, ALIASES
from run_conditional_eaa_20261006 import ROOT, OUT, sha, save

CACHE = ROOT/'.cache/arm_angle/low_ivb_20261006/type_targets'
PREFIX = 'eaa_type_targets_20261006'


def type_frame(d, kind):
    """두 학습 가족 모두 구종 자체의 위치·궤적·무브먼트를 사용한다."""
    result = d[MODEL_FEATURES].copy()
    for c in ['z55_over_height', 'side55_over_height']: result[c] = d[f'type_{kind}_{c}']
    for c in KINEMATICS+MOVEMENT: result['ff_'+c] = d[f'type_{kind}_{c}']
    return result


def assemble():
    CACHE.mkdir(exist_ok=True)
    basepath = CACHE.parent/'mlb_multi.parquet'
    original = pd.read_parquet(basepath)
    source = json.loads((CACHE.parent/'mlb_manifest.json').read_text())
    bio = pd.read_csv(OUT/'direct_mlb_inputs.csv', usecols=['pitcher', 'season', 'height_cm', 'pitch_hand'], dtype={'pitcher': str})
    expected = {'base_input_sha256': sha(basepath), 'sources': source['sources'],
                'code_sha256': sha(Path(__file__)), 'bio_sha256': sha(OUT/'direct_mlb_inputs.csv')}
    path = CACHE/'mlb.parquet'; manifest = CACHE/'manifest.json'
    if path.exists():
        saved = json.loads(manifest.read_text()); assert saved['inputs']==expected
        return pd.read_parquet(path), saved
    fields = ['pitcher', 'game_date', 'game_type', 'game_year', 'game_pk', 'at_bat_number', 'pitch_number', 'pitch_type',
              'p_throws', 'release_pos_x', 'release_pos_y', 'release_pos_z', 'vx0', 'vy0', 'vz0', 'ax', 'ay', 'az', 'arm_angle']
    parts = []; coverage = []
    for year in range(2020, 2025):
        paths = [ROOT/p for p in source['sources'] if p.endswith(f'_{year}.parquet') or p.endswith(f'-{year}.parquet')]
        for p in paths: assert sha(p)==source['sources'][str(p.relative_to(ROOT))]
        raw = pd.concat([pd.read_parquet(p, columns=fields) for p in paths], ignore_index=True)
        assert not raw.duplicated(['game_pk', 'at_bat_number', 'pitch_number']).any()
        assert raw.game_type.eq('R').all() and raw.game_year.eq(year).all()
        raw.pitcher = raw.pitcher.astype(str)
        raw = raw.merge(bio.loc[bio.season.eq(year)], on='pitcher', validate='many_to_one')
        assert raw.p_throws.eq(raw.pitch_hand).all()
        inference = raw.drop(columns='arm_angle').copy()
        inference['pitcher_id'] = inference.pitcher; inference['pitch_type_code'] = inference.pitch_type
        q = pitch_features(mlb_adapter(inference))
        q.numeric_valid &= q.ay.between(5, 55)&np.hypot(q.ax, q.az+G/FT_M).le(45)
        q['observed_angle'] = raw.arm_angle.where(raw.arm_angle.between(-90, 90))
        q = q.loc[q.numeric_valid].copy(); q['kind'] = q.pitch_type_code.replace(ALIASES)
        d = original.loc[original.season.eq(year), ['pitcher', 'season']].set_index('pitcher')
        d['valid_pitch_observed_mean'] = q.groupby('pitcher_id').observed_angle.mean()
        for kind in GROUPS:
            grouped = q.loc[q.kind.eq(kind)].groupby('pitcher_id').observed_angle
            n = grouped.size().reindex(d.index).fillna(0)
            observed = grouped.count().reindex(d.index).fillna(0)
            d[f'label_{kind}'] = grouped.mean().reindex(d.index)
            d[f'label_{kind}_count'] = observed
            d[f'label_{kind}_coverage'] = observed/n.replace(0, np.nan)
        parts.append(d.reset_index())
        coverage.append({'season': year, 'valid_pitches': len(q), 'observed_angles': int(q.observed_angle.notna().sum())})
        print('구종별 정답 집계', year, len(d), flush=True)
    labels = pd.concat(parts, ignore_index=True)
    d = original.merge(labels, on=['pitcher', 'season'], validate='one_to_one')
    assert d[['pitcher', 'season']].equals(original[['pitcher', 'season']])
    np.testing.assert_allclose(d[MODEL_FEATURES], original[MODEL_FEATURES], atol=0, rtol=0)
    training_counts = {}
    for kind in GROUPS:
        valid = d[f'label_{kind}_count'].ge(30)&d[f'label_{kind}_coverage'].ge(.95)&d[f'type_{kind}_count'].gt(30)
        valid &= np.isfinite(type_frame(d, kind)).all(axis=1)
        training_counts[kind] = {'seasons': int(valid.sum()), 'players': int(d.loc[valid].pitcher.nunique())}
    d.to_parquet(path, index=False)
    saved = {'inputs': expected, 'coverage': coverage, 'eligible_type_training': training_counts,
             'type_label_is_mean_of_observed_valid_pitches': True, 'imputed_missing_angle_labels': False}
    save(manifest, saved)
    return d, saved


if __name__=='__main__':
    _, manifest = assemble(); print(json.dumps(manifest['eligible_type_training'], ensure_ascii=False))
