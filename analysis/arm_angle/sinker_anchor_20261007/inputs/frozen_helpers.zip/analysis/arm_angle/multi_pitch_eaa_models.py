"""다구종 전문가·IVB 균형·교차적합 잔차 모델의 연구 전용 학습."""
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import GroupKFold
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from multi_pitch_eaa_features import (
    GROUPS, GEOM_EXTRA, FULL_EXTRA, expert_frame, exposure_weights,
    training_weights, weighted_consensus,
)

SEED = 20261006
OPTIONS = ('baseline', 'balanced_IVB', 'multi_geometry', 'multi_movement',
    'boosted_baseline', 'boosted_multi', 'boosted_balanced_multi',
    'expert_mean', 'expert_median', 'expert_huber', 'gated_expert_huber',
    'crossfit_expert_residual', 'gated_expert_residual')
AUX_COLUMNS = MODEL_FEATURES[:8]
META_COLUMNS = ['base_angle', 'alt_angle', 'alt_delta', 'ivb_deficit', 'alt_count',
    'ff_ivb_in', 'ff_hb_arm_in', 'ff_speed55', 'type_FF_height_delta', 'type_FF_side_delta',
    'side55_over_height', 'z55_over_height']


def ridge_fit(d, columns, target=None, balanced=False, extras=False, auxiliary=False):
    if extras:
        transformer = ColumnTransformer([
            ('base', PolynomialFeatures(2, include_bias=False), list(range(len(MODEL_FEATURES)))),
            ('extra', SimpleImputer(strategy='median', add_indicator=True, keep_empty_features=True),
             list(range(len(MODEL_FEATURES), len(columns))))])
    else:
        transformer = make_pipeline(SimpleImputer(strategy='median', keep_empty_features=True),
                                     PolynomialFeatures(2, include_bias=False))
    model = make_pipeline(transformer, StandardScaler(), Ridge(alpha=100))
    weights = exposure_weights(d) if auxiliary else training_weights(d, balanced)
    return model.fit(d[columns].to_numpy(float), d.arm_angle.to_numpy() if target is None else target,
        standardscaler__sample_weight=weights, ridge__sample_weight=weights)


def boost_fit(d, columns, balanced=False):
    model = HistGradientBoostingRegressor(max_iter=160, learning_rate=.04, max_leaf_nodes=15,
        min_samples_leaf=30, l2_regularization=10, early_stopping=False, random_state=SEED)
    return model.fit(d[columns].to_numpy(float), d.arm_angle.to_numpy(),
                     sample_weight=training_weights(d, balanced))


def fit_experts(d):
    models = {'FF': ridge_fit(d, MODEL_FEATURES)}
    for kind in GROUPS[1:]:
        frame = expert_frame(d, kind)
        valid = np.isfinite(frame).all(axis=1)
        valid &= d[f'type_{kind}_available'].eq(1)
        subset = d.loc[valid].copy()
        subset[MODEL_FEATURES] = frame.loc[valid]
        models[kind] = ridge_fit(subset, MODEL_FEATURES) if subset.pitcher.nunique()>=25 else None
    ivb = ridge_fit(d, AUX_COLUMNS, target=d.ff_ivb_in.to_numpy(), auxiliary=True)
    return models, ivb


def apply_experts(experts, d):
    models, ivb = experts
    matrix = np.full((len(d), len(GROUPS)), np.nan)
    for i, kind in enumerate(GROUPS):
        if models[kind] is None: continue
        frame = expert_frame(d, kind)
        valid = np.isfinite(frame).all(axis=1)
        if kind != 'FF': valid &= d[f'type_{kind}_available'].eq(1)
        if valid.any(): matrix[valid, i] = models[kind].predict(frame.loc[valid].to_numpy(float))
    deficit = d.ff_ivb_in.to_numpy()-ivb.predict(d[AUX_COLUMNS].to_numpy(float))
    return matrix, deficit


def transformed(d, matrix, deficit, threshold, scale):
    counts = d[[f'type_{g}_count' for g in GROUPS]].to_numpy(float)
    alt = weighted_consensus(matrix[:, 1:], counts[:, 1:], 'huber')
    base = matrix[:, 0]
    alt = np.where(np.isfinite(alt), alt, base)
    alt_count = np.isfinite(matrix[:, 1:]).sum(axis=1)
    gate = expit((threshold-deficit)/scale)*np.minimum(1., alt_count/2)
    gate = np.where(alt_count>=2, gate, 0.)
    meta = d.copy()
    meta['base_angle'] = base; meta['alt_angle'] = alt
    meta['alt_delta'] = alt-base; meta['ivb_deficit'] = deficit
    meta['alt_count'] = alt_count
    return meta, gate


def bundle_fit(d):
    d = d.reset_index(drop=True)
    matrix = np.full((len(d), len(GROUPS)), np.nan)
    deficit = np.full(len(d), np.nan)
    for train, val in GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=d.pitcher):
        assert set(d.iloc[train].pitcher).isdisjoint(d.iloc[val].pitcher)
        matrix[val], deficit[val] = apply_experts(fit_experts(d.iloc[train]), d.iloc[val])
    assert np.isfinite(matrix[:, 0]).all() and np.isfinite(deficit).all()
    threshold = float(np.quantile(deficit, .25))
    scale = float(max(1., .5*np.subtract(*np.quantile(deficit, [.75, .25]))))
    meta, _ = transformed(d, matrix, deficit, threshold, scale)
    residual = ridge_fit(meta, META_COLUMNS, target=d.arm_angle.to_numpy()-matrix[:, 0])
    return {'experts': fit_experts(d), 'residual': residual,
            'threshold': threshold, 'scale': scale,
            'all_meta_training_predictions_player_crossfit': True}


def bundle_predict(bundle, d):
    matrix, deficit = apply_experts(bundle['experts'], d)
    meta, gate = transformed(d, matrix, deficit, bundle['threshold'], bundle['scale'])
    counts = d[[f'type_{g}_count' for g in GROUPS]].to_numpy(float)
    base = matrix[:, 0]
    correction_raw = bundle['residual'].predict(meta[META_COLUMNS].to_numpy(float))
    correction = np.clip(correction_raw, -10., 10.)
    predictions = {'baseline': base}
    for method in ['mean', 'median', 'huber']:
        predictions['expert_'+method] = weighted_consensus(matrix, counts, method)
    predictions['gated_expert_huber'] = base+gate*(meta.alt_angle.to_numpy()-base)
    predictions['crossfit_expert_residual'] = base+correction
    predictions['gated_expert_residual'] = base+gate*correction
    details = {'expert_predictions': matrix, 'IVB_deficit_in': deficit, 'gate': gate,
        'nonFF_experts': meta.alt_count.to_numpy(), 'raw_residual_correction': correction_raw}
    return predictions, details


def fit_all(d):
    models = {'bundle': bundle_fit(d)}
    for name, columns, balanced, boosted in [
        ('balanced_IVB', MODEL_FEATURES, True, False),
        ('multi_geometry', MODEL_FEATURES+GEOM_EXTRA, False, False),
        ('multi_movement', MODEL_FEATURES+FULL_EXTRA, False, False),
        ('boosted_baseline', MODEL_FEATURES, False, True),
        ('boosted_multi', MODEL_FEATURES+FULL_EXTRA, False, True),
        ('boosted_balanced_multi', MODEL_FEATURES+FULL_EXTRA, True, True)]:
        model = boost_fit(d, columns, balanced) if boosted else ridge_fit(
            d, columns, balanced=balanced, extras=name.startswith('multi_'))
        models[name] = (model, columns)
    return models


def predict_all(models, d):
    predictions, details = bundle_predict(models['bundle'], d)
    for name, value in models.items():
        if name == 'bundle': continue
        model, columns = value
        predictions[name] = model.predict(d[columns].to_numpy(float))
    assert set(predictions)==set(OPTIONS)
    assert all(np.isfinite(x).all() for x in predictions.values())
    return predictions, details
