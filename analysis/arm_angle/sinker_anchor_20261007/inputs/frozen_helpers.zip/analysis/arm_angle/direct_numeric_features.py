"""Shared SI numerical features from a constant-acceleration trajectory.

Research only. Neither the force direction nor its spin-axis representation is
an optical spin measurement. Both leagues use the same declared planes.
"""
import numpy as np
import pandas as pd

from visualbaseball.spin_axis_ode import FT_M, G, PLATE_FRONT_Y_M, time_to_plane

GEOMETRY = ['height_m', 'left_hand', 'z55_over_height', 'side55_over_height']
KINEMATICS = GEOMETRY + ['speed55', 'armside_vx_over_minus_vy', 'vz_over_minus_vy', 'flight55_to_plate']
FORCE = KINEMATICS + ['axis_arm_sin', 'axis_up_cos', 'transverse_accel', 'drag_accel']
MIX = ['ff_share', 'breaking_share', 'offspeed_share', 'cutter_share', 'side55_sd_over_height', 'z55_sd_over_height']
FEATURES = FORCE + ['speed_mid', 'movement50_hb_arm_m', 'movement50_ivb_m']
AXIS_VARIANTS = ['force_axis_50', 'force_axis_55', 'force_axis_mid55', 'force_axis_plate', 'force_axis_release']


def circular_gap(a, b):
    return (np.asarray(a)-np.asarray(b)+180) % 360-180


def circular_mean(values):
    a = np.radians(np.asarray(values, float))
    return float(np.degrees(np.arctan2(np.nanmean(np.sin(a)), np.nanmean(np.cos(a)))) % 360)


def mlb_adapter(raw):
    """Statcast velocity/acceleration are at 50ft; positions are at release.

    Reconstruct the 50ft position from the supplied release point without
    approximating the extension plane. No label or shoulder value is used.
    """
    d = raw.copy()
    t = time_to_plane(50*FT_M, d.vy0.to_numpy()*FT_M,
                      d.ay.to_numpy()*FT_M, d.release_pos_y.to_numpy()*FT_M)
    d['x0'] = d.release_pos_x-d.vx0*t-.5*d.ax*t*t
    d['z0'] = d.release_pos_z-d.vz0*t-.5*d.az*t*t
    d['y0'] = 50.
    d['release_y_m'] = d.release_pos_y*FT_M
    d['pitcher_hand'] = d.p_throws.map({'R': 'Right', 'L': 'Left'})
    return d


def derive(raw):
    """Return every input row with numerical outputs and an explicit mask."""
    d = raw.copy()
    p = d[['x0', 'y0', 'z0']].to_numpy(float)*FT_M
    v = d[['vx0', 'vy0', 'vz0']].to_numpy(float)*FT_M
    a = d[['ax', 'ay', 'az']].to_numpy(float)*FT_M
    h = d.height_cm.to_numpy(float)/100
    hand = d.pitcher_hand.map({'Right': 1., 'Left': -1.}).to_numpy(float)
    t50 = time_to_plane(p[:, 1], v[:, 1], a[:, 1], 50*FT_M)
    t55 = time_to_plane(p[:, 1], v[:, 1], a[:, 1], 55*FT_M)
    end = time_to_plane(p[:, 1], v[:, 1], a[:, 1], PLATE_FRONT_Y_M)
    mid = (t55+end)/2
    v55 = v+a*t55[:, None]
    pos55 = p+v*t55[:, None]+.5*a*t55[:, None]**2
    aero = a+[0, 0, G]
    planes = {'50': t50, '55': t55, 'mid55': mid, 'plate': end}
    if 'release_y_m' in d:
        planes['release'] = time_to_plane(p[:, 1], v[:, 1], a[:, 1], d.release_y_m.to_numpy(float))
    force_mid = None
    with np.errstate(invalid='ignore', divide='ignore'):
        for name, t in planes.items():
            vel = v+a*t[:, None]
            unit = vel/np.linalg.norm(vel, axis=1)[:, None]
            parallel = (aero*unit).sum(axis=1)
            force = aero-parallel[:, None]*unit
            size = np.linalg.norm(force, axis=1)
            axis = np.cross(unit, force/size[:, None])
            xz = np.linalg.norm(axis[:, [0, 2]], axis=1)
            phi = np.degrees(np.arctan2(-axis[:, 2], axis[:, 0])) % 360
            d['force_axis_'+name] = np.where((size > .01) & (xz > 1e-8), phi, np.nan)
            if name == 'mid55':
                d['axis_arm_sin'] = hand*(-axis[:, 2]/xz)
                d['axis_up_cos'] = -axis[:, 0]/xz
                d['transverse_accel'] = size
                d['drag_accel'] = -parallel
                d['speed_mid'] = np.linalg.norm(vel, axis=1)
                force_mid = force
        d['height_m'] = h
        d['left_hand'] = (hand < 0).astype(float)
        d['z55_over_height'] = pos55[:, 2]/h
        d['side55_over_height'] = -hand*pos55[:, 0]/h
        d['speed55'] = np.linalg.norm(v55, axis=1)
        d['armside_vx_over_minus_vy'] = hand*v55[:, 0]/(-v55[:, 1])
        d['vz_over_minus_vy'] = v55[:, 2]/(-v55[:, 1])
        d['flight55_to_plate'] = end-t55
        # Explicit acceleration-derived shadow approximation over 50ft->front.
        # This is a common transform, not a claim of vendor pfx equivalence.
        d['movement50_hb_arm_m'] = -hand*.5*force_mid[:, 0]*(end-t50)**2
        d['movement50_ivb_m'] = .5*force_mid[:, 2]*(end-t50)**2
    finite = np.isfinite(d[FEATURES]).all(axis=1)
    valid = (finite & d.height_cm.between(140, 220) & d.y0.isin([50., 55.])
             & d.pitcher_hand.isin(['Right', 'Left']) & (v55[:, 1] < 0)
             & (np.abs(pos55[:, 0]) <= 2) & (pos55[:, 2] >= .05) & (pos55[:, 2] <= 2.7)
             & d.speed55.between(15, 55) & d.transverse_accel.between(.01, 40)
             & d.flight55_to_plate.between(.2, .8) & (np.abs(t55) < .15))
    if 'trajectory_valid' in d:
        valid &= d.trajectory_valid.fillna(False)
    d['direct_valid'] = valid
    return d


def aggregate(d, keys, ff_column):
    """All-pitch geometry/mix and FF force inputs retain separate counts."""
    q = d.loc[d.direct_valid].copy()
    g = q.groupby(keys, dropna=False)
    out = g[KINEMATICS].mean()
    out['n_all_features'] = g.size()
    out['side55_sd_over_height'] = g.side55_over_height.std(ddof=1)
    out['z55_sd_over_height'] = g.z55_over_height.std(ddof=1)
    codes = q[ff_column].astype(str)
    flags = {'ff_share': codes.eq('FF') | codes.eq('4-Seam Fastball'),
             'breaking_share': codes.isin(['SL', 'ST', 'CU', 'KC', 'SV', 'Slider', 'Curveball', 'Sweeper', 'Knuckle Curve']),
             'offspeed_share': codes.isin(['CH', 'FS', 'FO', 'Changeup', 'Splitter', 'Forkball']),
             'cutter_share': codes.isin(['FC', 'Cutter'])}
    for name, flag in flags.items():
        out[name] = flag.groupby([q[k] for k in keys], dropna=False).mean()
    ff = q.loc[flags['ff_share']]
    fg = ff.groupby(keys, dropna=False)
    for name in [c for c in FEATURES if c not in GEOMETRY]:
        out['ff_'+name] = fg[name].mean()
    out['n_ff_features'] = fg.size()
    for name in AXIS_VARIANTS:
        if name in ff:
            out[name] = fg[name].agg(circular_mean)
    if 'arm_angle' in q:
        labels = q.arm_angle.where(q.arm_angle.between(-90, 90))
        out['all_feature_pitch_AA'] = labels.groupby([q[k] for k in keys]).mean()
        fl = ff.arm_angle.where(ff.arm_angle.between(-90, 90))
        out['ff_feature_pitch_AA'] = fl.groupby([ff[k] for k in keys]).mean()
        out['n_all_feature_AA'] = labels.groupby([q[k] for k in keys]).count()
        out['n_ff_feature_AA'] = fl.groupby([ff[k] for k in keys]).count()
    return out.reset_index()


def feature_columns(family):
    if family == 'geometry55':
        return GEOMETRY
    if family == 'kinematics55':
        return KINEMATICS
    base = GEOMETRY+['ff_'+c for c in FORCE if c not in GEOMETRY]
    if family == 'force55':
        return base
    if family == 'force_mix':
        return base+MIX
    if family == 'force_shadow':
        return base+['ff_movement50_hb_arm_m', 'ff_movement50_ivb_m']
    if family == 'optical_vector_diagnostic':
        return KINEMATICS+['vector_x', 'vector_gyro_mirrored', 'vector_z_mirrored', 'spin_rate', 'active_spin']
    if family == 'optical_scalar_diagnostic':
        return KINEMATICS+['optical_arm_sin', 'optical_up_cos', 'spin_rate', 'active_spin']
    raise ValueError(family)
