"""다구종 eAA 연구의 공통 입력과 강건 결합. 관측 팔각도는 입력에 쓰지 않는다."""
import numpy as np
import pandas as pd
from visualbaseball.arm_angle_aggregation import trimmed_mean
from visualbaseball.numeric_arm_angle_features import GEOMETRY, KINEMATICS, MOVEMENT, MODEL_FEATURES, season_features

GROUPS = ('FF', 'SI', 'FC', 'SL', 'CU', 'CH', 'FS')
ALIASES = {'FT': 'SI', 'ST': 'SL', 'KC': 'CU', 'CS': 'CU', 'FO': 'FS'}
MIN_TYPE = 30
TYPE_COLUMNS = ['z55_over_height', 'side55_over_height']+KINEMATICS+MOVEMENT
DELTA_COLUMNS = ['height_delta', 'side_delta', 'speed_delta', 'lateral_delta', 'vertical_delta', 'flight_delta']
GEOM_EXTRA = ['type_FF_height_delta', 'type_FF_side_delta', 'ff_share']
for group in GROUPS[1:]:
    GEOM_EXTRA += [f'type_{group}_{c}' for c in DELTA_COLUMNS+['share', 'available']]
FULL_EXTRA = GEOM_EXTRA+[f'type_{g}_{c}' for g in GROUPS[1:] for c in MOVEMENT]


def multi_inputs(frame):
    q = frame.loc[frame.numeric_valid].copy()
    base = season_features(q, 'trimmed10')
    q['type_group'] = q.pitch_type_code.replace(ALIASES)
    # 같은50ft→플레이트 기준의 투구별 IVB/HB를 집계한다.
    q['ivb_in'] = q.movement_size_m*q.movement_axis_up_cos/.0254
    q['hb_arm_in'] = q.movement_size_m*q.movement_axis_arm_sin/.0254
    extra = {}
    for kind in GROUPS:
        prefix = f'type_{kind}_'
        pitches = q.loc[q.type_group.eq(kind)]
        group = pitches.groupby('pitcher_id')
        counts = group.size().reindex(base.index).fillna(0).astype(int)
        available = counts.ge(MIN_TYPE)
        extra[prefix+'count'] = counts
        extra[prefix+'available'] = available.astype(float)
        extra[prefix+'share'] = counts/base.n
        values = group[TYPE_COLUMNS+['ivb_in', 'hb_arm_in']].agg(trimmed_mean).reindex(base.index)
        if kind != 'FF': values.loc[~available] = np.nan
        for col in values:
            extra[prefix+col] = values[col]
        references = ['z55_over_height', 'side55_over_height']+['ff_'+c for c in KINEMATICS]
        for name, col, reference in zip(DELTA_COLUMNS, TYPE_COLUMNS[:6], references):
            extra[prefix+name] = values[col]-base[reference]
    extra['ff_share'] = base.n_ff/base.n
    # 전문가30구 기준과 별도로 평가용 FF 집계는 운영 표본 그대로 보존한다.
    ff = q.loc[q.pitch_type_code.eq('FF')].groupby('pitcher_id')
    extra['ff_ivb_in'] = ff.ivb_in.agg(trimmed_mean)
    extra['ff_hb_arm_in'] = ff.hb_arm_in.agg(trimmed_mean)
    return pd.concat([base, pd.DataFrame(extra, index=base.index)], axis=1)


def expert_frame(frame, kind):
    result = frame[MODEL_FEATURES].copy()
    if kind != 'FF':
        for c in TYPE_COLUMNS[:2]: result[c] = frame[f'type_{kind}_{c}']
        for c in KINEMATICS+MOVEMENT: result['ff_'+c] = frame[f'type_{kind}_{c}']
    return result


def exposure_weights(frame):
    w = 1/frame.pitcher.map(frame.pitcher.value_counts()).to_numpy(float)
    return w/w.mean()


def training_weights(frame, balanced=False):
    weights = exposure_weights(frame)*np.where(frame.arm_angle.to_numpy()>=60, 4., 1.)
    if balanced:
        keys = [np.floor(frame.arm_angle.to_numpy()/5), np.floor(frame.ff_speed55.to_numpy()/2)]
        cells = pd.DataFrame({'angle': keys[0], 'speed': keys[1], 'ivb': frame.ff_ivb_in.to_numpy(),
                              'weight': weights, 'position': np.arange(len(frame))})
        multiplier = np.ones(len(frame))
        for _, cell in cells.groupby(['angle', 'speed']):
            if len(cell)<16: continue
            quartile = np.minimum((cell.ivb.rank(pct=True)*4).astype(int), 3)
            if quartile.nunique()!=4 or quartile.value_counts().min()<2: continue
            mass = cell.weight.groupby(quartile).sum()
            factor = (cell.weight.sum()/4)/quartile.map(mass).to_numpy()
            multiplier[cell.position] = np.clip(factor, 1/3, 3.)
        weights *= multiplier
    return weights/weights.mean()


def weighted_consensus(values, counts, method='huber'):
    values, counts = np.asarray(values, float), np.asarray(counts, float)
    observed = np.isfinite(values)&np.isfinite(counts)&(counts>0)
    weights = np.where(observed, np.sqrt(np.minimum(counts, 200)), 0.)
    safe = np.where(observed, values, 0.)
    total = weights.sum(axis=1)
    order = np.argsort(np.where(observed, values, np.inf), axis=1)
    cumulative = np.take_along_axis(weights, order, axis=1).cumsum(axis=1)
    mid = (cumulative>=total[:, None]/2).argmax(axis=1)
    median = np.take_along_axis(values, order, axis=1)[np.arange(len(values)), mid]
    if method == 'median': result = median
    elif method == 'mean': result = np.divide((safe*weights).sum(axis=1), total,
                                               out=np.full(len(values), np.nan), where=total>0)
    elif method == 'huber':
        result = median.copy()
        for _ in range(20):
            influence = np.minimum(1., 4./np.maximum(abs(safe-result[:, None]), 1e-9))
            effective = weights*influence
            updated = np.divide((safe*effective).sum(axis=1), effective.sum(axis=1),
                out=np.full(len(values), np.nan), where=total>0)
            change = abs(updated-result)
            result = updated
            if not np.isfinite(change).any() or np.nanmax(change)<1e-8: break
    else: raise ValueError('알 수 없는 결합 방식: '+method)
    return np.where(total>0, result, np.nan)
