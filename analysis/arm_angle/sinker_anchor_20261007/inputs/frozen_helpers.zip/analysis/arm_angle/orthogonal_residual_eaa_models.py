"""포심 시즌 앵커를 고정하고 새 입력의 직교 성분으로만 잔차를 보완한다."""
import numpy as np
from scipy.linalg import solve
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import PolynomialFeatures

from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from multi_pitch_eaa_features import FULL_EXTRA, training_weights
from multi_pitch_eaa_models import ridge_fit, SEED
from continuous_eaa_models import smooth_extra

FAMILIES = ('type', 'moment', 'combined')
STRENGTHS = {'half': .5, 'full': 1.}
OPTIONS = ('baseline',)+tuple(f'{f}_{s}' for f in FAMILIES for s in STRENGTHS)
ALPHA, CAP, TOL = 300., 5., 1e-7
POLY = PolynomialFeatures(2, include_bias=False).fit(np.zeros((1, len(MODEL_FEATURES))))


def base_matrix(frame):
    return POLY.transform(frame[MODEL_FEATURES].to_numpy(float))


def extra_medians(frame):
    raw = frame[FULL_EXTRA].to_numpy(float)
    return np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in raw.T])


def new_matrix(frame, stats, medians, family):
    """관측 각도 관련 충분통계는 읽지 않는다."""
    if family == 'type':
        return smooth_extra(frame, medians)
    if family == 'moment':
        return np.asarray(stats['x_mean'], float)
    if family == 'combined':
        return np.column_stack([smooth_extra(frame, medians), stats['x_mean']])
    raise ValueError(f'알 수 없는 입력군: {family}')


def fit_projection(x, z, weights):
    """학습 입력에 대한 정확한 가중 투영. 라벨·평가 입력을 사용하지 않는다."""
    w = np.asarray(weights, float)
    xm = np.average(x, axis=0, weights=w)
    xs = np.sqrt(np.average((x-xm)**2, axis=0, weights=w))
    xs = np.where(xs > 1e-12, xs, 1.)
    zm = np.average(z, axis=0, weights=w)
    zs = np.sqrt(np.average((z-zm)**2, axis=0, weights=w))
    zs = np.where(zs > 1e-12, zs, 1.)
    design = np.column_stack([np.ones(len(x)), (x-xm)/xs])
    standardized = (z-zm)/zs
    root = np.sqrt(w)[:, None]
    gamma, _, rank, singular = np.linalg.lstsq(root*design, root*standardized, rcond=1e-10)
    residual = standardized-design@gamma
    scale = np.sqrt(np.average(residual**2, axis=0, weights=w))
    keep = scale > TOL
    model = {'x_mean': xm, 'x_scale': xs, 'z_mean': zm, 'z_scale': zs,
             'projection': gamma, 'residual_scale': scale[keep], 'keep': keep,
             'rank': int(rank), 'singular_min': float(singular[-1]),
             'training_orthogonality_max': float(abs(design.T@(w[:, None]*residual)/w.sum()).max()),
             'training_residual_mean_max': float(abs(np.average(residual, axis=0, weights=w)).max())}
    return model, residual[:, keep]/scale[keep]


def apply_projection(model, x, z):
    design = np.column_stack([np.ones(len(x)), (x-model['x_mean'])/model['x_scale']])
    residual = (z-model['z_mean'])/model['z_scale']-design@model['projection']
    return residual[:, model['keep']]/model['residual_scale']


def fit_correction(frame, stats, target_residual, weights, medians, family, oof_minus_refit):
    z = new_matrix(frame, stats, medians, family)
    projection, residual = fit_projection(base_matrix(frame), z, weights)
    gram = residual.T@(weights[:, None]*residual)+ALPHA*np.eye(residual.shape[1])
    rhs = residual.T@(weights*np.asarray(target_residual))
    coef = solve(gram, rhs, assume_a='pos')
    # 선택에는 쓰지 않는 감사: OOF→재적합 차이의 전달 성분을 보존한다.
    gap_coef = solve(gram, residual.T@(weights*oof_minus_refit), assume_a='pos')
    return {'family': family, 'projection': projection, 'coef': coef, 'medians': medians,
            'alpha': ALPHA, 'residual_intercept': 0., 'cap': CAP,
            'OOF_refit_gap_diagnostic_coef': gap_coef}


def raw_correction(model, frame, stats):
    z = new_matrix(frame, stats, model['medians'], model['family'])
    matrix = apply_projection(model['projection'], base_matrix(frame), z)
    return matrix@model['coef']


def fit_all(frame, stats):
    d = frame.reset_index(drop=True)
    oof = np.full(len(d), np.nan)
    groups = d.pitcher.astype(str)
    assignments = []
    for tr, va in GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=groups):
        assert set(groups.iloc[tr]).isdisjoint(groups.iloc[va])
        model = ridge_fit(d.iloc[tr], MODEL_FEATURES)
        oof[va] = model.predict(d.iloc[va][MODEL_FEATURES].to_numpy(float))
        assignments.append({'train_players': sorted(set(groups.iloc[tr])),
                            'validation_players': sorted(set(groups.iloc[va]))})
    assert np.isfinite(oof).all()
    base = ridge_fit(d, MODEL_FEATURES)
    weights, medians = training_weights(d), extra_medians(d)
    target = d.arm_angle.to_numpy()-oof
    refit = base.predict(d[MODEL_FEATURES].to_numpy(float))
    corrections = {f: fit_correction(d, stats, target, weights, medians, f, oof-refit) for f in FAMILIES}
    return {'baseline': base, 'corrections': corrections,
            'residual_targets_player_crossfit': True, 'OOF_splits': assignments,
            'OOF_minus_refit_weighted_mean': float(np.average(oof-refit, weights=weights)),
            'OOF_minus_refit_weighted_RMS': float(np.sqrt(np.average((oof-refit)**2, weights=weights)))}


def predict_all(models, frame, stats):
    base = models['baseline'].predict(frame[MODEL_FEATURES].to_numpy(float))
    predictions, details = {'baseline': base}, {}
    for family, model in models['corrections'].items():
        raw = raw_correction(model, frame, stats)
        delta = CAP*np.tanh(raw/CAP)
        details[family] = raw
        for suffix, strength in STRENGTHS.items():
            predictions[f'{family}_{suffix}'] = base+strength*delta
    assert set(predictions)==set(OPTIONS)
    assert all(np.isfinite(p).all() for p in predictions.values())
    return predictions, details


def portable(models):
    """고정 학습의 보정 계수만 저장. 포심 앵커는 기존 v3와 따로 대조한다."""
    def convert(value):
        if isinstance(value, np.ndarray):
            return value.tolist()
        if isinstance(value, dict):
            return {k: convert(v) for k, v in value.items()}
        return value
    return convert(models['corrections'])
