"""고정 투수 분리에서 직교 입력 잔차의 강도와 입력군을 선택한다."""
from pathlib import Path
import json
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from visualbaseball.estimated_arm_angle import _predict
from multi_pitch_eaa_models import SEED
from run_conditional_eaa_20261006 import ROOT, OUT, sha, save, gain
from run_eaa_low_ivb_20261006 import summary, masks
from run_eaa_type_targets_20261006 import select_scores
from pitch_joint_eaa_features import assemble_mlb, assemble_kbo, subset, BASIS_NAMES
CACHE = ROOT/'.cache/arm_angle/orthogonal_residual_20261006'
PREFIX = 'eaa_orthogonal_residual_20261006'
from orthogonal_residual_eaa_models import OPTIONS, FAMILIES, fit_all, predict_all, portable


def choose(d, stats, label):
    predictions = {n: np.full(len(d), np.nan) for n in OPTIONS}
    for fold, (train, val) in enumerate(GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=d.pitcher)):
        assert set(d.iloc[train].pitcher).isdisjoint(d.iloc[val].pitcher)
        models = fit_all(d.iloc[train], subset(stats, train))
        p, _ = predict_all(models, d.iloc[val], subset(stats, val))
        for name in OPTIONS:
            predictions[name][val] = p[name]
        print(label, '직교 잔차 inner', fold, flush=True)
    scores = {n: {'summary': summary(d, p)} for n, p in predictions.items()}
    return select_scores(scores), scores


def intervals(cal, cal_pred, test, test_pred):
    result = {}
    for name in OPTIONS:
        residual = np.sort(cal.arm_angle.to_numpy()-cal_pred[name])
        n = len(residual)
        lo = residual[max(1, int(np.floor((n+1)*.05)))-1]
        hi = residual[min(n, int(np.ceil((n+1)*.95)))-1]
        error = test.arm_angle.to_numpy()-test_pred[name]
        covered = (error>=lo)&(error<=hi)
        result[name] = {'lower_residual_deg': float(lo), 'upper_residual_deg': float(hi),
                        'width_deg': float(hi-lo), 'fixed2024': {}}
        for group, mask in masks(test).items():
            a = mask.to_numpy()
            result[name]['fixed2024'][group] = {
                'players': int(a.sum()), 'covered': int(covered[a].sum()),
                'coverage': float(covered[a].mean()) if a.any() else None}
    return result


def main():
    CACHE.mkdir(parents=True, exist_ok=True)
    d, stats, manifest = assemble_mlb()
    kbo, ks, kmanifest = assemble_kbo()
    table = d[['pitcher', 'season', 'arm_angle', 'outer_fold', 'ff_ivb_in',
               'ff_speed55', 'left_hand', 'n', 'n_ff']].copy()
    for name in OPTIONS+('nested_selected',):
        table[name] = np.nan
    choices = []
    for fold in sorted(d.outer_fold.unique()):
        tr = np.flatnonzero(d.outer_fold.ne(fold))
        va = np.flatnonzero(d.outer_fold.eq(fold))
        assert set(d.iloc[tr].pitcher).isdisjoint(d.iloc[va].pitcher)
        selected, scores = choose(d.iloc[tr].reset_index(drop=True), subset(stats, tr), f'outer{fold}')
        models = fit_all(d.iloc[tr], subset(stats, tr))
        pred, _ = predict_all(models, d.iloc[va], subset(stats, va))
        for name in OPTIONS:
            table.loc[va, name] = pred[name]
        table.loc[va, 'nested_selected'] = pred[selected]
        choices.append({'fold': int(fold), 'selected': selected, 'training_selection': scores})
        print('직교 잔차 outer 확정', fold, selected, flush=True)
    train = np.flatnonzero(d.fixed_training_row)
    cal = np.flatnonzero(d.selected_single_period_calibration_row)
    test = np.flatnonzero(d.eval2024_independent_train_and_calibration_player)
    assert set(d.iloc[train].pitcher).isdisjoint(set(d.iloc[cal].pitcher)|set(d.iloc[test].pitcher))
    assert set(d.iloc[cal].pitcher).isdisjoint(d.iloc[test].pitcher)
    selected, scores = choose(d.iloc[train].reset_index(drop=True), subset(stats, train), '고정 학습')
    models = fit_all(d.iloc[train], subset(stats, train))
    pred, _ = predict_all(models, d.iloc[test], subset(stats, test))
    cp, _ = predict_all(models, d.iloc[cal], subset(stats, cal))
    baseline = json.loads((ROOT/'data/models/estimated_arm_angle_v3.json').read_text())
    bp = models['baseline'].predict(d[MODEL_FEATURES].to_numpy(float))
    expected = [_predict(baseline['angle'], x) for x in d[MODEL_FEATURES].to_numpy(float)]
    np.testing.assert_allclose(bp, expected, atol=1e-8, rtol=0)
    oof = {name: summary(d, table[name]) for name in OPTIONS+('nested_selected',)}
    fixed = {name: summary(d.iloc[test], p) for name, p in pred.items()}
    gains = {g: gain(d, table.baseline.to_numpy(), table.nested_selected.to_numpy(), m.to_numpy())
             for g, m in masks(d).items() if g in ['all', 'middle35_60', 'high60', 'matched_low_IVB']}
    low, bl = oof['nested_selected']['matched_low_IVB'], oof['baseline']['matched_low_IVB']
    fl, fb = fixed[selected]['matched_low_IVB'], fixed['baseline']['matched_low_IVB']
    checks = {'nonbaseline_selected': selected!='baseline',
              'nested_lowIVB_bias_gain0p30': abs(low['bias'])<=abs(bl['bias'])-.30,
              'nested_lowIVB_MAE_CI_lower_gt0': gains['matched_low_IVB']['bootstrap95'][0]>0,
              'nested_all_noninferiority': gains['all']['bootstrap95'][0]>=-.10,
              'nested_high_noninferiority': gains['high60']['bootstrap95'][0]>=-.25,
              'fixed2024_lowIVB_MAE_improves': fl['player_MAE']<fb['player_MAE'],
              'fixed2024_lowIVB_bias_improves': abs(fl['bias'])<abs(fb['bias']),
              'fixed2024_all_margin': fixed[selected]['all']['MAE']<=fixed['baseline']['all']['MAE']+.15,
              'fixed2024_high_margin': fixed[selected]['high60']['MAE']<=fixed['baseline']['high60']['MAE']+.25}
    it = intervals(d.iloc[cal], cp, d.iloc[test], pred)
    kpred, raw = predict_all(models, kbo, ks)
    kt = kbo[['pitcher', 'season', 'n', 'n_ff', 'ff_ivb_in']].copy().rename(columns={'pitcher': 'pitcher_id'})
    for name, values in kpred.items():
        kt[name] = values
    for f in FAMILIES:
        kt[f+'_raw_correction'] = raw[f]
    kt['selected'] = selected
    kt['selected_angle_deg'] = kt[selected]
    kt['delta_deg'] = kt[selected]-kt.baseline
    names = pd.read_csv(ROOT/'data/tracking/player_heights.csv', dtype={'player_id': str}).set_index('player_id').player_name
    kt['name'] = kt.pitcher_id.map(names)
    cases = json.loads((OUT/'eaa_continuous_20261006_selection.json').read_text())['selected']
    kt['selected_case'] = kt.pitcher_id.isin(cases)
    kt['KBO_accuracy_verified'] = False
    report = {'scope': 'KBO2026 단일 eAA; MLB 교차적합 포심 앵커+입력 직교 잔차 연구',
              'options_predeclared': OPTIONS, 'selected_train_only': selected,
              'inner_selection': scores, 'outer_choices': choices, 'OOF': oof, 'projection_diagnostics': {f: {k: models['corrections'][f]['projection'][k] for k in ['rank', 'training_orthogonality_max', 'training_residual_mean_max']} for f in FAMILIES}, 'OOF_refit_gap': {k: models[k] for k in ['OOF_minus_refit_weighted_mean', 'OOF_minus_refit_weighted_RMS']},
              'independent2024': fixed, 'paired_player_gains': gains,
              'promotion_checks_MLB': checks, 'promotion_eligible_MLB': bool(all(checks.values())),
              'intervals': it, 'MLB_inputs': manifest, 'KBO_inputs': kmanifest,
              'MLB_seasons': len(d), 'MLB_players': int(d.pitcher.nunique()),
              'fixed_training_seasons': len(train), 'fixed_training_players': int(d.iloc[train].pitcher.nunique()),
              'calibration_players': len(cal), 'independent2024_players': len(test),
              'label_coverage95_seasons': int((stats['observed_n']/stats['n']>=.95).sum()),
              'high_coverage_OOF': {n: summary(d.loc[stats['observed_n']/stats['n']>=.95],
                      table.loc[stats['observed_n']/stats['n']>=.95, n]) for n in OPTIONS},
              'external_evaluation_is_reused': True, 'external_labels_used_for_selection': False, 'production_changed': False,
              'sha256': {'frozen_v3': sha(ROOT/'data/models/estimated_arm_angle_v3.json'),
                  'features': sha(Path(__file__).with_name('pitch_joint_eaa_features.py')),
                  'models': sha(Path(__file__).with_name('orthogonal_residual_eaa_models.py')),
                  'script': sha(Path(__file__)), 'predeclared_plan': sha(Path(__file__).with_name('eaa-2026-orthogonal-residual-plan.md'))}}
    table.to_csv(OUT/(PREFIX+'_mlb_predictions.csv'), index=False)
    test_table = d.iloc[test][['pitcher', 'season', 'arm_angle', 'ff_ivb_in', 'ff_speed55', 'left_hand']].copy()
    for name, values in pred.items():
        test_table[name] = values
    test_table.to_csv(OUT/(PREFIX+'_independent2024_predictions.csv'), index=False)
    kt.to_csv(OUT/(PREFIX+'_KBO2026_predictions.csv'), index=False)
    kt.loc[kt.selected_case].to_csv(OUT/(PREFIX+'_KBO2026_focus.csv'), index=False)
    save(OUT/(PREFIX+'_model_report.json'), report)
    with (CACHE/'fixed_models.pkl').open('wb') as f:
        pickle.dump(models, f)
    save(OUT/(PREFIX+'_candidate_models.json'), {'selected': selected, 'basis_names': BASIS_NAMES, 'baseline_v3_SHA': sha(ROOT/'data/models/estimated_arm_angle_v3.json'),
        'models': portable(models), 'production_approved': False,
        'model_report_sha256': sha(OUT/(PREFIX+'_model_report.json'))})
    print('직교 잔차 고정 선택', selected, 'MLB 승격', report['promotion_eligible_MLB'], flush=True)
    print(kt.loc[kt.selected_case, ['name', 'baseline', 'type_full', 'moment_full',
                                  'combined_full', 'selected_angle_deg']].to_string(index=False))


if __name__=='__main__':
    main()
