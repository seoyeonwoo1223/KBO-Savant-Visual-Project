"""구종별 정답 대조와 학습 교차적합 신뢰도의 연구 전용 모델."""
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GroupKFold
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from multi_pitch_eaa_features import GROUPS, training_weights, exposure_weights
from continuous_eaa_models import (
    count_confidence, fit_all as old_fit, predict_all as old_predict,
    fit_continuous_experts, apply_continuous_experts,
)
from multi_pitch_eaa_models import SEED
from type_target_eaa_features import type_frame

OPTIONS = ('baseline', 'smooth_season2', 'reliable_season1', 'type_mean_season_targets',
           'type_mean_type_targets', 'gated_type_mean_type_targets', 'reliable_type1')


def fit_types(d):
    models = {'season': {}, 'type': {}}
    for kind in GROUPS:
        x = type_frame(d, kind)
        r = count_confidence(d[f'type_{kind}_count'])
        valid = np.isfinite(x).all(axis=1).to_numpy()&(r>0)
        valid &= d[f'label_{kind}_count'].ge(30).to_numpy()&d[f'label_{kind}_coverage'].ge(.95).to_numpy()
        q = d.loc[valid]
        if q.pitcher.nunique()<25:
            for family in models: models[family][kind] = None
            continue
        weights = training_weights(q)*r[valid]; weights /= weights.mean()
        for family, target in [('season', q.arm_angle.to_numpy()), ('type', q[f'label_{kind}'].to_numpy())]:
            model = make_pipeline(SimpleImputer(strategy='median', keep_empty_features=True),
                PolynomialFeatures(2, include_bias=False), StandardScaler(), Ridge(alpha=100))
            models[family][kind] = model.fit(x.loc[valid].to_numpy(float), target,
                standardscaler__sample_weight=weights, ridge__sample_weight=weights)
    return models


def type_predictions(models, d):
    matrices = {f: np.full((len(d), len(GROUPS)), np.nan) for f in models}
    for kind_index, kind in enumerate(GROUPS):
        x = type_frame(d, kind)
        valid = np.isfinite(x).all(axis=1).to_numpy()&(count_confidence(d[f'type_{kind}_count'])>0)
        for family in models:
            model = models[family][kind]
            if model is not None and valid.any(): matrices[family][valid, kind_index] = model.predict(x.loc[valid].to_numpy(float))
    return matrices


def robust_center(values, weights):
    observed = np.isfinite(values)&np.isfinite(weights)&(weights>0)
    weights = np.where(observed, weights, 0.); safe = np.where(observed, values, 0.)
    active = weights.sum(axis=1)>0
    lo = np.where(active, np.where(observed, values, np.inf).min(axis=1), 0.)
    hi = np.where(active, np.where(observed, values, -np.inf).max(axis=1), 0.)
    for _ in range(48):
        mid = (lo+hi)/2; residual = mid[:, None]-safe
        gradient = (weights*residual/np.sqrt(1+(residual/4.)**2)).sum(axis=1)
        lo = np.where(gradient<0, mid, lo); hi = np.where(gradient>=0, mid, hi)
    return np.where(active, (lo+hi)/2, np.nan)


def quality(d, matrix, labels):
    mae = []
    for i, kind in enumerate(GROUPS):
        target = d.arm_angle.to_numpy() if labels=='season' else d[f'label_{kind}'].to_numpy()
        valid = np.isfinite(matrix[:, i])&np.isfinite(target)
        if labels=='type': valid &= d[f'label_{kind}_count'].ge(30)&d[f'label_{kind}_coverage'].ge(.95)
        if not np.asarray(valid).any(): mae.append(np.nan); continue
        weights = exposure_weights(d.loc[valid])
        mae.append(float(np.average(abs(matrix[valid, i]-target[valid]), weights=weights)))
    mae = np.asarray(mae)
    ratio = np.where(np.isfinite(mae), np.minimum(1., (mae[0]/np.maximum(mae, .25))**2), 0.)
    return ratio, mae


def fit_all(d):
    d = d.reset_index(drop=True)
    season_oof = np.full((len(d), len(GROUPS)), np.nan)
    type_oof = np.full_like(season_oof, np.nan)
    for train, val in GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=d.pitcher):
        assert set(d.iloc[train].pitcher).isdisjoint(d.iloc[val].pitcher)
        season_oof[val] = apply_continuous_experts(fit_continuous_experts(d.iloc[train]), d.iloc[val])
        type_oof[val] = type_predictions(fit_types(d.iloc[train]), d.iloc[val])['type']
    sq, sm = quality(d, season_oof, 'season'); tq, tm = quality(d, type_oof, 'type')
    offsets = []
    for kind in GROUPS:
        valid = d[f'label_{kind}_count'].ge(30)&d[f'label_{kind}_coverage'].ge(.95)&d[f'type_{kind}_count'].gt(30)
        q = d.loc[valid]
        offsets.append(float(np.average(q[f'label_{kind}']-q.arm_angle, weights=exposure_weights(q))) if len(q) else 0.)
    return {'old': old_fit(d), 'types': fit_types(d), 'season_quality': sq, 'type_quality': tq,
            'season_oof_MAE': sm, 'type_oof_MAE': tm, 'type_to_season_offset': np.array(offsets),
            'quality_player_crossfit': True, 'both_type_families_share_training_rows_and_weights': True}


def outputs(d, old_pred, old_details, type_matrices, models):
    base = old_pred['baseline']; gate = old_details['gate8']; protect = old_details['protection_weight']
    counts = d[[f'type_{g}_count' for g in GROUPS]].to_numpy(float)
    r = count_confidence(counts)
    result = {'baseline': base, 'smooth_season2': old_pred['smooth_multi8']}
    for family in ['season', 'type']:
        angles = type_matrices[family]
        delta = np.where(np.isfinite(angles), angles-base[:, None], 0.)
        mean = base+np.clip(((counts/d.n.to_numpy()[:, None])*r*delta).sum(axis=1), -10., 10.)
        result['type_mean_'+family+'_targets'] = mean
    result['gated_type_mean_type_targets'] = base+gate*protect*np.clip(result['type_mean_type_targets']-base, 0., 10.)
    for family, matrix, label in [('season', old_details['expert_predictions'], 'reliable_season1'),
                                 ('type', type_matrices['type']-models['type_to_season_offset'], 'reliable_type1')]:
        valid = np.isfinite(matrix[:, 1:])
        reliability = r[:, 1:]*valid*models[family+'_quality'][None, 1:]
        weights = reliability*np.sqrt(np.minimum(counts[:, 1:], 200))
        center = robust_center(matrix[:, 1:], weights)
        center = np.where(np.isfinite(center), center, base)
        proposal = center if family=='type' else old_details['multi_angle_deg']+np.clip(center-old_details['multi_angle_deg'], 0., 10.)
        result[label] = base+gate*protect*reliability.max(axis=1)*np.clip(proposal-base, 0., 10.)
    details = {'IVB_deficit_in': old_details['IVB_deficit8_in'], 'gate': gate,
        'nonFF_experts': old_details['nonFF_experts'], 'season_quality': models['season_quality'],
        'type_quality': models['type_quality'], 'type_predictions': type_matrices['type'],
        'season_target_type_predictions': type_matrices['season'], 'count_confidence': r,
        'geometry_angle_deg': old_details['geometry_angle_deg']}
    assert set(result)==set(OPTIONS) and all(np.isfinite(p).all() for p in result.values())
    return result, details


def predict_all(models, d):
    old_pred, old_details = old_predict(models['old'], d)
    matrices = type_predictions(models['types'], d)
    return outputs(d, old_pred, old_details, matrices, models)
