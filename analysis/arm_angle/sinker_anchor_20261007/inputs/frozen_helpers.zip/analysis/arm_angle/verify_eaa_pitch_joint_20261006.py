"""저장 지표·선택·계수와 실제 원본 투구의 충분통계를 별도로 검산한다."""
import json
import pickle
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
import pyarrow as pa
import pyarrow.parquet as pq

from run_conditional_eaa_20261006 import ROOT, OUT, sha, save
from pitch_joint_eaa_features import CACHE, PREFIX, BASE_COLUMNS, POLY, KINDS, MLB_FIELDS, ALIASES, GROUPS
from pitch_joint_eaa_features import load_stats, adapt_mlb, basis, moments, JOINT
from pitch_joint_eaa_models import OPTIONS, fit_moments, predict_pitch_basis


def manual_summary(frame, p):
    y = frame.arm_angle.to_numpy()
    a, v = np.floor(y/5), np.floor(frame.ff_speed55.to_numpy())
    cells = pd.DataFrame({'a': a, 'v': v, 'ivb': frame.ff_ivb_in.to_numpy()})
    grouped = cells.groupby(['a', 'v']).ivb
    low = (y>=35)&(y<60)&grouped.transform('size').ge(4).to_numpy()
    low &= cells.ivb.le(grouped.transform('median')).to_numpy()
    masks = {'all': np.ones(len(frame), bool), 'middle35_60': (y>=35)&(y<60),
             'high60': y>=60, 'low20': y<20, 'matched_low_IVB': low}
    result = {}
    for name, m in masks.items():
        error = np.asarray(p)[m]-y[m]
        ids = frame.pitcher.to_numpy()[m]
        result[name] = {'MAE': float(abs(error).mean()) if m.any() else None,
                        'bias': float(error.mean()) if m.any() else None,
                        'player_MAE': float(pd.Series(abs(error)).groupby(ids).mean().mean()) if m.any() else None,
                        'players': len(set(ids)), 'seasons': int(m.sum())}
    return result


def close_summary(actual, expected):
    count = 0
    for group, values in actual.items():
        for name, value in values.items():
            other = expected[group][name]
            if value is None:
                assert other is None
            else:
                np.testing.assert_allclose(value, other, atol=1e-10, rtol=0)
            count += 1
    return count


def manual_basis(q):
    a = q[BASE_COLUMNS].to_numpy(float)
    polynomial = np.prod(a[:, None, :]**POLY.powers_[None, :, :], axis=2)
    kind = q.pitch_type_code.replace(ALIASES)
    kind = kind.where(kind.isin(GROUPS), 'OTHER')
    typed = np.column_stack([kind.eq(k).to_numpy(float) for k in KINDS])
    hb = q.movement_size_m*q.movement_axis_arm_sin
    ivb = q.movement_size_m*q.movement_axis_up_cos
    values = np.column_stack([q.z55_over_height, q.side55_over_height, q.speed55, ivb, hb])
    pair = np.zeros((len(q), 6))
    key = pd.DataFrame({'pid': q.pitcher_id.to_numpy(), 'game': q.game_key.to_numpy(), 'kind': kind.to_numpy()})
    for _, rows in key.groupby(['pid', 'game', 'kind']).groups.items():
        rows = np.asarray(rows)
        z, s, v, vv, hh = (values[rows]-values[rows].mean(axis=0)).T
        confidence = (len(rows)-1)/(len(rows)+4)
        pair[rows, :5] = np.column_stack([z*v, s*v, z*vv, s*hh, z*s])*confidence
        pair[rows, 5] = confidence
    return np.column_stack([polynomial, typed, pair])


def source_check(d, stats):
    year = int(d.loc[d.fixed_training_row, 'season'].max())
    candidates = sorted(d.loc[d.fixed_training_row&d.season.eq(year), 'pitcher'])
    ids = [candidates[0], candidates[len(candidates)//2], candidates[-1]]
    metadata = json.loads((CACHE/'mlb_manifest.json').read_text())
    parts = []
    for name, digest in metadata['inputs']['sources'].items():
        if not (name.endswith(f'_{year}.parquet') or name.endswith(f'-{year}.parquet')):
            continue
        path = ROOT/name
        assert sha(path)==digest
        dtype = pq.ParquetFile(path).schema_arrow.field('pitcher').type
        matches = [int(p) for p in ids] if pa.types.is_integer(dtype) else ids
        parts.append(pd.read_parquet(path, columns=MLB_FIELDS+['arm_angle'], filters=[('pitcher', 'in', matches)]))
    raw = pd.concat(parts, ignore_index=True)
    raw.pitcher = raw.pitcher.astype(str)
    bio = pd.read_csv(OUT/'direct_mlb_inputs.csv', dtype={'pitcher': str}, usecols=['pitcher', 'season', 'height_cm', 'pitch_hand'])
    bio = bio.loc[bio.season.eq(year)].drop(columns='season')
    q = adapt_mlb(raw.drop(columns='arm_angle'), bio)
    valid = q.numeric_valid.to_numpy()
    q = q.loc[valid].reset_index(drop=True)
    y = raw.arm_angle.to_numpy()[valid]
    observed = np.isfinite(y)&(abs(y)<=90)
    x = manual_basis(q)
    np.testing.assert_allclose(x, basis(q), atol=1e-10, rtol=0)
    cells = 0
    for pid in ids:
        position = np.flatnonzero(d.pitcher.eq(pid)&d.season.eq(year))[0]
        rows = q.pitcher_id.eq(pid).to_numpy()
        xx = x[rows&observed]
        yy = y[rows&observed]
        expected = {'n': int(rows.sum()), 'observed_n': len(yy), 'x_mean': x[rows].mean(axis=0),
                    'train_x_mean': xx.mean(axis=0), 'train_xx_mean': xx.T@xx/len(yy),
                    'train_xy_mean': xx.T@yy/len(yy), 'train_y_mean': yy.mean()}
        for key, value in expected.items():
            np.testing.assert_allclose(stats[key][position], value, atol=1e-8, rtol=1e-12)
            cells += 1
    # 실제 원본 투구를 직접 펼친 sklearn 가중 회귀와 충분통계 회귀 대조.
    order = pd.MultiIndex.from_product([ids, [year]], names=['pitcher', 'season'])
    sample_stats, _ = moments(q, y, order)
    season_weights = np.array([1., 2., 1.5])
    p = order.get_indexer(pd.MultiIndex.from_frame(q[['pitcher_id', 'season']]))
    w = season_weights[p]/sample_stats['observed_n'][p]
    scaler = StandardScaler().fit(x[observed], sample_weight=w[observed])
    direct = Ridge(alpha=100).fit(scaler.transform(x[observed]), y[observed], sample_weight=w[observed])
    model = fit_moments(sample_stats, None, season_weights, JOINT, True)
    difference = float(abs(direct.predict(scaler.transform(x))-predict_pitch_basis(model, x)).max())
    assert difference<1e-7
    return {'season': year, 'players': ids, 'valid_pitches': len(q), 'observed_pitches': int(observed.sum()),
            'source_statistic_cells': cells, 'manual_feature_transform_checked': True,
            'direct_sklearn_fit_max_difference_deg': difference}


def main():
    report = json.loads((OUT/(PREFIX+'_model_report.json')).read_text())
    audit = json.loads((OUT/(PREFIX+'_completion_audit.json')).read_text())
    manifest = json.loads((CACHE/'mlb_manifest.json').read_text())
    d = pd.read_parquet(ROOT/'.cache/arm_angle/low_ivb_20261006/type_targets/mlb.parquet')
    stats = load_stats(CACHE/'mlb_moments.npz')
    with (CACHE/'fixed_models.pkl').open('rb') as f:
        models = pickle.load(f)
    assert report['sha256']['features']==sha(Path(__file__).with_name('pitch_joint_eaa_features.py'))
    assert report['sha256']['models']==sha(Path(__file__).with_name('pitch_joint_eaa_models.py'))
    assert report['sha256']['frozen_v3']==sha(ROOT/'data/models/estimated_arm_angle_v3.json')
    assert audit['locked_model_report_sha256']==sha(OUT/(PREFIX+'_model_report.json'))
    assert manifest['moments_sha256']==sha(CACHE/'mlb_moments.npz')
    table = pd.read_csv(OUT/(PREFIX+'_mlb_predictions.csv'), dtype={'pitcher': str})
    np.testing.assert_array_equal(table.pitcher, d.pitcher)
    assert not table[list(OPTIONS)+['nested_selected']].isna().any().any()
    metric_count = 0
    for name in OPTIONS+('nested_selected',):
        metric_count += close_summary(manual_summary(table, table[name]), report['OOF'][name])
    test = pd.read_csv(OUT/(PREFIX+'_independent2024_predictions.csv'), dtype={'pitcher': str})
    train_ids = set(d.loc[d.fixed_training_row, 'pitcher'])
    cal_ids = set(d.loc[d.selected_single_period_calibration_row, 'pitcher'])
    assert train_ids.isdisjoint(cal_ids|set(test.pitcher)) and cal_ids.isdisjoint(test.pitcher)
    for fold in sorted(d.outer_fold.unique()):
        assert set(d.loc[d.outer_fold.eq(fold), 'pitcher']).isdisjoint(d.loc[d.outer_fold.ne(fold), 'pitcher'])
    for name in OPTIONS:
        metric_count += close_summary(manual_summary(test, test[name]), report['independent2024'][name])
    for row in report['outer_choices']+[{'training_selection': report['inner_selection'], 'selected': report['selected_train_only']}]:
        scores = row['training_selection']
        baseline = scores['baseline']['summary']
        available = []
        for name, info in scores.items():
            s = info['summary']; low = s['matched_low_IVB']; bl = baseline['matched_low_IVB']
            score = low['player_MAE']+.25*s['all']['player_MAE']
            np.testing.assert_allclose(score, info['score'], atol=1e-12)
            eligible = name=='baseline' or (abs(low['bias'])<=abs(bl['bias'])-.30
                and low['player_MAE']<=bl['player_MAE']-.05
                and all(s[g]['player_MAE']<=baseline[g]['player_MAE']+m for g, m in
                        [('all', .15), ('middle35_60', .05), ('high60', .25), ('low20', .50)]))
            assert bool(eligible)==info['eligible']
            if eligible:
                available.append((score, name))
        assert min(available)[1]==row['selected']
    kt = pd.read_csv(OUT/(PREFIX+'_KBO2026_predictions.csv'), dtype={'pitcher_id': str})
    ks = load_stats(CACHE/'kbo_moments.npz')
    encoded = json.loads((OUT/(PREFIX+'_candidate_models.json')).read_text())
    for name, m in encoded['models'].items():
        independent = ((ks['x_mean'][:, m['indices']]-m['mean'])/m['scale'])@m['coef']+m['intercept']
        np.testing.assert_allclose(independent, kt[name], atol=1e-8, rtol=0)
        np.testing.assert_array_equal(models[name]['coef'], m['coef'])
    calibration = np.flatnonzero(d.selected_single_period_calibration_row)
    for name in OPTIONS:
        if name=='baseline':
            from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
            pred = models['baseline'].predict(d.iloc[calibration][MODEL_FEATURES].to_numpy(float))
        else:
            m = encoded['models'][name]
            x = stats['x_mean'][calibration][:, m['indices']]
            pred = ((x-m['mean'])/m['scale'])@m['coef']+m['intercept']
        residual = np.sort(d.iloc[calibration].arm_angle.to_numpy()-pred)
        lo = residual[max(1, int(np.floor((len(residual)+1)*.05)))-1]
        hi = residual[min(len(residual), int(np.ceil((len(residual)+1)*.95)))-1]
        recorded = report['intervals'][name]
        np.testing.assert_allclose([lo, hi, hi-lo],
            [recorded['lower_residual_deg'], recorded['upper_residual_deg'], recorded['width_deg']], atol=1e-8, rtol=0)
        metric_count += 3
    fresh = json.loads((OUT/(PREFIX+'_fresh2025_report.json')).read_text())
    ft = pd.read_csv(OUT/(PREFIX+'_fresh2025_predictions.csv'), dtype={'pitcher': str})
    for period, info in fresh['periods'].items():
        q = ft.loc[ft.period.eq(period)]
        for group, mask in [('all', np.ones(len(q), bool)), ('unseen_reference', ~q.seen_in_reference),
                            ('unseen_all_prior_labels', q.unseen_to_all_prior_labels), ('seen_reference', q.seen_in_reference)]:
            sub = q.loc[mask]
            assert len(sub)==info['metrics'][group]['players']
            for name in OPTIONS:
                error = sub[name]-sub.arm_angle
                expected = info['metrics'][group]['models'][name]
                if len(sub):
                    np.testing.assert_allclose([error.abs().mean(), error.mean()], [expected['MAE'], expected['bias']], atol=1e-10)
                    metric_count += 2
                offsets = report['intervals'][name]
                covered = sub.arm_angle.between(sub[name]+offsets['lower_residual_deg'], sub[name]+offsets['upper_residual_deg'])
                assert int(covered.sum())==info['interval_coverage'][group][name]['covered']
    for s in fresh['sources']:
        assert sha(ROOT/s['path'])==s['sha256'] and s['rows']<25000
    source = source_check(d, stats)
    result = {'passed': True, 'verified_metric_values': metric_count, 'KBO_players_recomputed': len(kt),
              'source_checks': source, 'source_daily_files_verified': len(fresh['sources']),
              'selection_constraints_independently_verified': True, 'player_splits_verified': True,
              'operational_model_unchanged': True, 'production_changed': False,
              'sha256': {'verifier': sha(Path(__file__)), 'model_report': sha(OUT/(PREFIX+'_model_report.json'))}}
    save(OUT/(PREFIX+'_verification.json'), result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__=='__main__':
    main()
