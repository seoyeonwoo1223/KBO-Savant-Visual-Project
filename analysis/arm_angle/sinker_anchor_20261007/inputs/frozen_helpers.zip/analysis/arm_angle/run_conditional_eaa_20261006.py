"""Train-only conditional eAA selection, nested player CV, KBO 2026 only."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
from scipy.special import expit
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures,StandardScaler
from sklearn.linear_model import Ridge
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES,pitch_features,G,FT_M,quality_mask
from visualbaseball.curated import load_rows
from visualbaseball.estimated_arm_angle import _heights,_name,_predict
from visualbaseball.eaa_movement_calibration import calibrate_eaa
from conditional_eaa_features import context_inputs,feature_set,CONTEXT,LIFT
from direct_numeric_features import mlb_adapter

ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'analysis/arm_angle/results';CACHE=ROOT/'.cache/arm_angle/conditional_20261006'
SEED=20261006
BASE=('baseline',100.)
OPTIONS=[BASE,('soft_blend',100.)]+[(f,a) for f in ['lift','context','context_lift','context_direction'] for a in [30.,100.,300.]]
FOCUS={'67143':'손주영','52701':'문동주','54362':'전준표','56318':'박준현','68341':'안우진','68220':'곽빈','52060':'박영현','51897':'조병현'}

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(2**20),b''):h.update(chunk)
    return h.hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def label(o):return o[0]+'__'+str(int(o[1]))

def assemble_mlb():
    path=CACHE/'mlb_context.parquet'
    if path.exists():
        manifest=json.loads((CACHE/'mlb_manifest.json').read_text())
        assert manifest['feature_code_sha256']==sha(Path(__file__).with_name('conditional_eaa_features.py')), 'Stale context feature cache'
        assert manifest['common_input_sha256']==sha(OUT/'robust_mlb_inputs.csv'), 'Stale MLB input cache'
        return pd.read_parquet(path)
    reference=pd.read_csv(OUT/'robust_mlb_inputs.csv',dtype={'pitcher':str}).query('aggregation=="trimmed10"').sort_values(['pitcher','season']).reset_index(drop=True)
    bio=pd.read_csv(OUT/'direct_mlb_inputs.csv',usecols=['pitcher','season','height_cm','pitch_hand'],dtype={'pitcher':str})
    fields=['pitcher','game_date','game_type','game_year','game_pk','at_bat_number','pitch_number','pitch_type','p_throws','release_pos_x','release_pos_y','release_pos_z','vx0','vy0','vz0','ax','ay','az']
    parts=[];sources={}
    for year in range(2020,2025):
        paths=[ROOT/f'.cache/arm_angle/candidates/statcast_candidates_{year}.parquet',ROOT/f'.cache/arm_angle/expanded/statcast/details-{year}.parquet']
        raw=pd.concat([pd.read_parquet(p,columns=fields) for p in paths],ignore_index=True)
        assert not raw.duplicated(['game_pk','at_bat_number','pitch_number']).any()
        assert raw.game_type.eq('R').all() and raw.game_year.eq(year).all()
        raw.pitcher=raw.pitcher.astype(str);raw=raw.merge(bio.loc[bio.season.eq(year)],on='pitcher',validate='many_to_one')
        assert raw.p_throws.eq(raw.pitch_hand).all()
        adapted=mlb_adapter(raw);adapted['pitcher_id']=adapted.pitcher;adapted['pitch_type_code']=adapted.pitch_type
        q=pitch_features(adapted);q.numeric_valid&=q.ay.between(5,55)&np.hypot(q.ax,q.az+G/FT_M).le(45.)
        grouped=context_inputs(q).reset_index().rename(columns={'pitcher_id':'pitcher'});grouped['season']=year;parts.append(grouped)
        for p in paths:sources[str(p.relative_to(ROOT))]=sha(p)
        print('Assembled cached MLB',year,flush=True)
    features=pd.concat(parts,ignore_index=True).sort_values(['pitcher','season']).reset_index(drop=True)
    assert features[['pitcher','season']].equals(reference[['pitcher','season']])
    np.testing.assert_allclose(features[MODEL_FEATURES],reference[MODEL_FEATURES],atol=1e-10,rtol=0)
    for c in ['arm_angle','outer_fold','fixed_training_row','selected_single_period_calibration_row','eval2024_independent_train_and_calibration_player']:
        features[c]=reference[c]
    assert np.isfinite(features[MODEL_FEATURES+CONTEXT+[LIFT]]).all().all()
    features.to_parquet(path,index=False)
    save(CACHE/'mlb_manifest.json',{'sources':sources,'feature_code_sha256':sha(Path(__file__).with_name('conditional_eaa_features.py')),'common_input_sha256':sha(OUT/'robust_mlb_inputs.csv'),'rows':len(features)})
    return features

def weights(d):
    w=1/d.pitcher.map(d.pitcher.value_counts()).to_numpy(float);w*=np.where(d.arm_angle>=60,4.,1.);return w/w.mean()
def ridge(d,cols,alpha):
    m=make_pipeline(PolynomialFeatures(2,include_bias=False),StandardScaler(),Ridge(alpha=alpha));w=weights(d)
    return m.fit(d[cols].to_numpy(float),d.arm_angle.to_numpy(float),standardscaler__sample_weight=w,ridge__sample_weight=w)
def fit(d,o):
    family,alpha=o
    if family!='soft_blend':return {'model':ridge(d,feature_set(family),alpha),'cols':feature_set(family)}
    low,q25,q75=np.quantile(d[LIFT],[.35,.25,.75])
    geom=[c for c in MODEL_FEATURES if not c.startswith('ff_movement_')]
    return {'full':ridge(d,MODEL_FEATURES,100.),'geometry':ridge(d,geom,100.),'geom_cols':geom,'threshold':float(low),'scale':float(max(q75-q25,1e-8))}
def predict(m,d):
    if 'model' in m:return m['model'].predict(d[m['cols']].to_numpy(float))
    w=.35+.65*expit(2*(d[LIFT].to_numpy()-m['threshold'])/m['scale'])
    full=m['full'].predict(d[MODEL_FEATURES].to_numpy(float));geom=m['geometry'].predict(d[m['geom_cols']].to_numpy(float))
    return w*full+(1-w)*geom

def middle_masks(d):
    angle=np.floor(d.arm_angle/5);speed=np.floor(d.ff_speed55)
    ivb=d.ff_movement_size_m*d.ff_movement_axis_up_cos
    count=d.groupby([angle,speed]).pitcher.transform('size')
    median=ivb.groupby([angle,speed]).transform('median')
    matched=d.arm_angle.ge(35)&d.arm_angle.lt(60)&count.ge(4)
    return matched&(ivb<=median),matched&(ivb>median)
def summary(d,p):
    err=pd.Series(np.asarray(p)-d.arm_angle.to_numpy(),index=d.index)
    low,high=middle_masks(d)
    masks={'all':pd.Series(True,index=d.index),'middle':d.arm_angle.ge(35)&d.arm_angle.lt(60),'high':d.arm_angle.ge(60),'low20':d.arm_angle.lt(20),'matched_low_IVB':low,'matched_high_IVB':high}
    out={}
    for name,mask in masks.items():
        q=d.loc[mask];e=err.loc[mask]
        out[name]={'seasons':len(q),'players':q.pitcher.nunique(),'MAE':float(e.abs().mean()),'bias':float(e.mean()),'player_MAE':float(e.abs().groupby(q.pitcher).mean().mean())}
    return out

def choose(d):
    scores=[];predictions={};folds=list(GroupKFold(3,shuffle=True,random_state=SEED).split(d,groups=d.pitcher))
    for o in OPTIONS:
        p=np.full(len(d),np.nan)
        for tr,te in folds:
            assert set(d.pitcher.iloc[tr]).isdisjoint(d.pitcher.iloc[te])
            p[te]=predict(fit(d.iloc[tr],o),d.iloc[te])
        s=summary(d,p);score=s['all']['player_MAE']+.25*s['middle']['player_MAE']+.25*s['high']['player_MAE']+.1*abs(s['matched_low_IVB']['bias'])
        scores.append({'option':label(o),'summary':s,'score':score});predictions[label(o)]=p
    base=scores[0]['summary']
    for row in scores:
        s=row['summary'];row['eligible']=row['option']==label(BASE) or (s['all']['player_MAE']<=base['all']['player_MAE']+.03 and s['middle']['player_MAE']<=base['middle']['player_MAE']-.03 and s['high']['player_MAE']<=base['high']['player_MAE']+.10 and s['low20']['player_MAE']<=base['low20']['player_MAE']+.25 and abs(s['matched_low_IVB']['bias'])<=abs(base['matched_low_IVB']['bias']))
    choice=min((r for r in scores if r['eligible']),key=lambda r:r['score'])
    return next(o for o in OPTIONS if label(o)==choice['option']),scores

def gain(d,baseline,candidate,mask):
    q=d.loc[mask];delta=pd.Series(abs(np.asarray(baseline)[mask]-q.arm_angle.to_numpy())-abs(np.asarray(candidate)[mask]-q.arm_angle.to_numpy()),index=q.index).groupby(q.pitcher).mean().to_numpy()
    rng=np.random.default_rng(SEED);boots=np.array([rng.choice(delta,len(delta),replace=True).mean() for _ in range(2000)])
    return {'players':len(delta),'player_MAE_gain':float(delta.mean()),'bootstrap95':np.quantile(boots,[.025,.975]).tolist()}

def evaluate(d):
    nested=np.full(len(d),np.nan);base=np.full(len(d),np.nan);choices=[]
    for fold in sorted(d.outer_fold.unique()):
        tr=d.outer_fold.ne(fold);te=~tr;assert set(d.loc[tr,'pitcher']).isdisjoint(d.loc[te,'pitcher'])
        o,table=choose(d.loc[tr]);nested[te]=predict(fit(d.loc[tr],o),d.loc[te]);base[te]=predict(fit(d.loc[tr],BASE),d.loc[te])
        choices.append({'fold':int(fold),'selected':label(o),'training_scores':table});print('Nested fold',fold,label(o),flush=True)
    train=d.loc[d.fixed_training_row];cal=d.loc[d.selected_single_period_calibration_row];test=d.loc[d.eval2024_independent_train_and_calibration_player]
    assert set(train.pitcher).isdisjoint(set(cal.pitcher)|set(test.pitcher)) and set(cal.pitcher).isdisjoint(test.pitcher)
    o,table=choose(train);m=fit(train,o);bm=fit(train,BASE)
    # All fixed candidate results are reported; no KBO-driven selection.
    comparisons={label(option):summary(test,predict(fit(train,option),test)) for option in OPTIONS}
    gains={name:gain(d,base,nested,mask) for name,mask in [('all',np.ones(len(d),bool)),('middle',(d.arm_angle>=35)&(d.arm_angle<60)),('high',d.arm_angle>=60)]}
    old=json.loads((ROOT/'data/models/estimated_arm_angle_v3.json').read_text())
    saved=np.array([_predict(old['angle'],x) for x in d[MODEL_FEATURES].to_numpy(float)])
    np.testing.assert_allclose(predict(bm,d),saved,atol=1e-8,rtol=0)
    eligible=(o!=BASE and gains['middle']['bootstrap95'][0]>0 and gains['all']['bootstrap95'][0]>=-.05 and gains['high']['bootstrap95'][0]>=-.20 and comparisons[label(o)]['all']['MAE']<=comparisons[label(BASE)]['all']['MAE']+.05 and comparisons[label(o)]['middle']['MAE']<comparisons[label(BASE)]['middle']['MAE'] and comparisons[label(o)]['high']['MAE']<=comparisons[label(BASE)]['high']['MAE']+.20)
    report={'options':[label(x) for x in OPTIONS],'selected_train_only':label(o),'inner_scores':table,'outer_choices':choices,'nested_baseline':summary(d,base),'nested_conditional':summary(d,nested),'paired_player_gains':gains,'fixed_2024_candidates':comparisons,'promotion_criteria':{'middle_gain_CI_lower_above':0,'all_noninferiority_CI_margin':.05,'high_noninferiority_CI_margin':.20,'fixed2024_all_margin':.05,'fixed2024_middle_gain_required':True,'fixed2024_high_margin':.20},'promotion_eligible':bool(eligible),'KBO_labels_used':False}
    results=d[['pitcher','season','arm_angle','outer_fold']].copy();results['baseline_oof']=base;results['conditional_nested_oof']=nested
    results.to_csv(OUT/'conditional_eaa_mlb_validation_20261006.csv',index=False)
    save(OUT/'conditional_eaa_model_report_20261006.json',report)
    return o,m,bm,report

def kbo_inputs():
    path=CACHE/'kbo_2026_context.parquet'
    if path.exists():
        manifest=json.loads((CACHE/'kbo_manifest.json').read_text())
        for key,relative in [('canonical_summary_sha256','data/curated/summary.json'),('height_sha256','data/tracking/player_heights.csv'),('bio_sha256','data/curated/players/player_bio.parquet')]:
            assert manifest[key]==sha(ROOT/relative), 'Stale KBO context cache: '+key
        return pd.read_parquet(path)
    raw=[r for r in load_rows(ROOT,'pitches',2026) if r.get('season')==2026 and r.get('pitcher_id')]
    k=pd.DataFrame(raw);k.pitcher_id=k.pitcher_id.astype(str);heights=_heights(ROOT)
    bio=pd.read_parquet(ROOT/'data/curated/players/player_bio.parquet',columns=['player_id','player_name','throws']);bio.player_id=bio.player_id.astype(str);bio=bio.set_index('player_id').to_dict('index')
    k['height_cm']=pd.to_numeric(k.pitcher_id.map(lambda p:heights.get(p,{}).get('height_cm')),errors='coerce')
    k['pitcher_hand']=k.pitcher_id.map(lambda p:{'R':'Right','L':'Left'}.get(bio.get(p,{}).get('throws')))
    identity=k.pitcher_name.map(_name).eq(k.pitcher_id.map(lambda p:_name(heights.get(p,{}).get('player_name'))))&k.pitcher_name.map(_name).eq(k.pitcher_id.map(lambda p:_name(bio.get(p,{}).get('player_name'))))
    numeric=['x0','y0','z0','vx0','vy0','vz0','ax','ay','az','px','pz','sz_top','sz_bottom','horizontal_movement_cm','vertical_movement_cm'];k[numeric]=k[numeric].apply(pd.to_numeric,errors='coerce')
    q=pitch_features(k,calibrate_eaa(raw,k.pitch_type_code.fillna('').tolist(),2026));q.numeric_valid&=quality_mask(k)&identity.to_numpy()
    features=context_inputs(q);features.to_parquet(path)
    save(CACHE/'kbo_manifest.json',{'season':2026,'rows':len(k),'last_game_date':str(k.game_id.str[:8].max()),'canonical_summary_sha256':sha(ROOT/'data/curated/summary.json'),'height_sha256':sha(ROOT/'data/tracking/player_heights.csv'),'bio_sha256':sha(ROOT/'data/curated/players/player_bio.parquet')})
    return features

def cases(o,m,bm,report):
    k=kbo_inputs();result=[]
    for pid,name in FOCUS.items():
        row=k.loc[[pid]];valid=row.n.iloc[0]>=100 and row.n_ff.iloc[0]>=100 and np.isfinite(row[MODEL_FEATURES+CONTEXT+[LIFT]]).all().all()
        r={'pitcher_id':pid,'name':name,'valid':bool(valid),'n':int(row.n.iloc[0]),'n_ff':int(row.n_ff.iloc[0])}
        if valid:
            r['v3']=float(predict(bm,row)[0]);r['candidate']=float(predict(m,row)[0]);r['delta']=r['candidate']-r['v3']
            for col in CONTEXT+[LIFT]:r[col]=float(row[col].iloc[0])
        result.append(r)
    save(OUT/'conditional_eaa_kbo_2026_20261006.json',{'selected':label(o),'cases':result,'promotion_eligible':report['promotion_eligible'],'production_changed':False,'KBO_true_accuracy_validated':False,'note':'Lift/FF context are observed trajectory proxies, not actual rotation efficiency.'})
    pd.DataFrame(result).to_csv(OUT/'conditional_eaa_kbo_2026_20261006.csv',index=False)
    print('Frozen candidate',label(o),'promotion',report['promotion_eligible'],flush=True)
    print([(r['name'],round(r.get('v3',0),2),round(r.get('candidate',0),2)) for r in result],flush=True)

def main():
    CACHE.mkdir(exist_ok=True,parents=True);d=assemble_mlb();o,m,bm,r=evaluate(d);cases(o,m,bm,r)
if __name__=='__main__':main()
