"""직교 잔차 실험의 저장 결과와 학습 수식을 독립 경로로 검산한다."""
import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import GroupKFold
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES, MOVEMENT
from visualbaseball.estimated_arm_angle import _predict
from multi_pitch_eaa_features import FULL_EXTRA, GROUPS, DELTA_COLUMNS, TYPE_COLUMNS, multi_inputs
from run_conditional_eaa_20261006 import ROOT, OUT, sha, save
from pitch_joint_eaa_features import CACHE as INPUT_CACHE, load_stats, MLB_FIELDS, adapt_mlb, moments
from verify_eaa_pitch_joint_20261006 import source_check

CACHE = ROOT/'.cache/arm_angle/orthogonal_residual_20261006'
PREFIX = 'eaa_orthogonal_residual_20261006'
SEED = 20261006
FAMILIES = ('type', 'moment', 'combined')
OPTIONS = ('baseline',)+tuple(f'{f}_{s}' for f in FAMILIES for s in ('half', 'full'))
V3_SHA = '484c6de37dc835f7551e69dbaa8550fe54bf6a086ec3483898140eee907ae84b'
POLY = PolynomialFeatures(2, include_bias=False).fit(np.zeros((1, len(MODEL_FEATURES))))


def manual_masks(frame):
    y = frame.arm_angle.to_numpy()
    cells = pd.DataFrame({'a': np.floor(y/5), 'v': np.floor(frame.ff_speed55.to_numpy()),
                          'ivb': frame.ff_ivb_in.to_numpy()})
    grouped = cells.groupby(['a', 'v']).ivb
    matched = (y>=35)&(y<60)&grouped.transform('size').ge(4).to_numpy()
    low = matched&cells.ivb.le(grouped.transform('median')).to_numpy()
    high = matched&cells.ivb.gt(grouped.transform('median')).to_numpy()
    return {'all': np.ones(len(frame), bool), 'middle35_60': (y>=35)&(y<60),
            'high60': y>=60, 'low20': y<20, 'matched_low_IVB': low,
            'matched_high_IVB': high, 'observed50plus_low_IVB': low&(y>=50),
            'left_matched_low_IVB': low&frame.left_hand.eq(1).to_numpy(),
            'right_matched_low_IVB': low&frame.left_hand.eq(0).to_numpy()}


def manual_summary(frame, prediction):
    result = {}
    for name, mask in manual_masks(frame).items():
        error = np.asarray(prediction)[mask]-frame.arm_angle.to_numpy()[mask]
        ids = frame.pitcher.to_numpy()[mask]
        result[name] = {'MAE': float(abs(error).mean()) if mask.any() else None,
                        'bias': float(error.mean()) if mask.any() else None,
                        'player_MAE': float(pd.Series(abs(error)).groupby(ids).mean().mean()) if mask.any() else None,
                        'players': len(set(ids)), 'seasons': int(mask.sum())}
    return result


def close_summary(actual, expected):
    count = 0
    for group, values in actual.items():
        for key, value in values.items():
            if value is None:
                assert expected[group][key] is None
            else:
                np.testing.assert_allclose(value, expected[group][key], atol=1e-10, rtol=0)
            count += 1
    return count


def manual_weights(frame):
    w = 1/frame.pitcher.map(frame.pitcher.value_counts()).to_numpy(float)
    w *= np.where(frame.arm_angle.to_numpy()>=60, 4., 1.)
    return w/w.mean()


def manual_base_fit(frame):
    x = POLY.transform(frame[MODEL_FEATURES].to_numpy(float))
    weights = manual_weights(frame)
    scale = StandardScaler().fit(x, sample_weight=weights)
    model = Ridge(alpha=100).fit(scale.transform(x), frame.arm_angle.to_numpy(), sample_weight=weights)
    return scale, model


def base_prediction(model, frame):
    scale, ridge = model
    return ridge.predict(scale.transform(POLY.transform(frame[MODEL_FEATURES].to_numpy(float))))


def manual_type_matrix(frame, medians):
    """추가 입력의 결측 처리·표본 수 수축도 별도 구현한다."""
    raw = frame[FULL_EXTRA].to_numpy(float)
    numeric = {f'type_{g}_{c}' for g in GROUPS[1:] for c in DELTA_COLUMNS+MOVEMENT}
    columns, uncertainty = [], []
    for i, name in enumerate(FULL_EXTRA):
        values = raw[:, i]
        kind = name.split('_')[1] if name.startswith('type_') else None
        if name.endswith('_available') or name in numeric:
            count = frame[f'type_{kind}_count'].to_numpy(float)
            u = np.clip((np.where(np.isfinite(count), count, 0.)-30)/30, 0., 1.)
            confidence = u*u*(3-2*u)
        if name.endswith('_available'):
            own = frame[MODEL_FEATURES].to_numpy(float).copy()
            for c in TYPE_COLUMNS[:2]:
                own[:, MODEL_FEATURES.index(c)] = frame[f'type_{kind}_{c}'].to_numpy(float)
            for c in TYPE_COLUMNS[2:]:
                own[:, MODEL_FEATURES.index('ff_'+c)] = frame[f'type_{kind}_{c}'].to_numpy(float)
            columns.append(confidence*np.isfinite(own).all(axis=1))
        elif name in numeric:
            confidence *= np.isfinite(values)
            observed = np.where(np.isfinite(values), values, medians[i])
            columns.append(medians[i]+confidence*(observed-medians[i]))
            uncertainty.append(1-confidence)
        else:
            columns.append(np.where(np.isfinite(values), values, medians[i]))
    return np.column_stack(columns+uncertainty)


def new_inputs(frame, stats, medians, family):
    if family=='type':
        return manual_type_matrix(frame, medians)
    if family=='moment':
        return np.asarray(stats['x_mean'], float)
    if family=='combined':
        return np.column_stack([manual_type_matrix(frame, medians), stats['x_mean']])
    raise AssertionError(family)


def portable_raw(model, frame, stats):
    p = model['projection']
    x = POLY.transform(frame[MODEL_FEATURES].to_numpy(float))
    z = new_inputs(frame, stats, np.asarray(model['medians']), model['family'])
    design = np.column_stack([np.ones(len(x)), (x-np.asarray(p['x_mean']))/p['x_scale']])
    remainder = (z-np.asarray(p['z_mean']))/p['z_scale']-design@np.asarray(p['projection'])
    r = remainder[:, np.asarray(p['keep'], bool)]/np.asarray(p['residual_scale'])
    return r@np.asarray(model['coef'])


def manual_predictions(encoded, baseline, frame, stats):
    result = {'baseline': np.asarray([_predict(baseline['angle'], row) for row in frame[MODEL_FEATURES].to_numpy(float)])}
    for family, model in encoded['models'].items():
        raw = portable_raw(model, frame, stats)
        correction = 5*np.tanh(raw/5)
        result[family+'_half'] = result['baseline']+.5*correction
        result[family+'_full'] = result['baseline']+correction
    return result


def verify_training(frame, stats, encoded, saved):
    """별도 sklearn 가중 OLS와 Ridge로 실제 1,095 학습행을 재적합한다."""
    frame = frame.reset_index(drop=True)
    oof = np.full(len(frame), np.nan)
    folds = []
    for tr, va in GroupKFold(3, shuffle=True, random_state=SEED).split(frame, groups=frame.pitcher):
        assert set(frame.iloc[tr].pitcher).isdisjoint(frame.iloc[va].pitcher)
        model = manual_base_fit(frame.iloc[tr])
        oof[va] = base_prediction(model, frame.iloc[va])
        folds.append({'train_players': sorted(set(frame.iloc[tr].pitcher)),
                      'validation_players': sorted(set(frame.iloc[va].pitcher))})
    assert folds==saved['OOF_splits']
    baseline = manual_base_fit(frame)
    refit = base_prediction(baseline, frame)
    stored = saved['baseline'].predict(frame[MODEL_FEATURES].to_numpy(float))
    np.testing.assert_allclose(refit, stored, atol=1e-8, rtol=0)
    w = manual_weights(frame)
    target, gap = frame.arm_angle.to_numpy()-oof, oof-refit
    raw = frame[FULL_EXTRA].to_numpy(float)
    medians = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in raw.T])
    x = POLY.transform(frame[MODEL_FEATURES].to_numpy(float))
    result = {}
    for family, stored in encoded['models'].items():
        np.testing.assert_array_equal(medians, stored['medians'])
        z = new_inputs(frame, stats, medians, family)
        xm, zm = np.average(x, axis=0, weights=w), np.average(z, axis=0, weights=w)
        xs = np.sqrt(np.average((x-xm)**2, axis=0, weights=w))
        zs = np.sqrt(np.average((z-zm)**2, axis=0, weights=w))
        xs, zs = np.where(xs>1e-12, xs, 1.), np.where(zs>1e-12, zs, 1.)
        design = np.column_stack([np.ones(len(frame)), (x-xm)/xs])
        standardized = (z-zm)/zs
        ols = LinearRegression(fit_intercept=False).fit(design, standardized, sample_weight=w)
        remainder = standardized-ols.predict(design)
        scales = np.sqrt(np.average(remainder**2, axis=0, weights=w))
        keep = scales>1e-7
        np.testing.assert_array_equal(keep, stored['projection']['keep'])
        matrix = remainder[:, keep]/scales[keep]
        projection_delta = float(abs(matrix@matrix.T-
            _portable_training_matrix(stored, frame, stats)@_portable_training_matrix(stored, frame, stats).T).max())
        # OLS solver의 영공간 좌표는 달라도 잔차 행렬·회귀 결과가 같아야 한다.
        np.testing.assert_allclose(matrix, _portable_training_matrix(stored, frame, stats), atol=1e-8, rtol=0)
        ridge = Ridge(alpha=300, fit_intercept=False).fit(matrix, target, sample_weight=w)
        gap_fit = Ridge(alpha=300, fit_intercept=False).fit(matrix, gap, sample_weight=w)
        coefficient_delta = float(abs(ridge.coef_-np.asarray(stored['coef'])).max())
        gap_delta = float(abs(gap_fit.coef_-np.asarray(stored['OOF_refit_gap_diagnostic_coef'])).max())
        np.testing.assert_allclose(ridge.coef_, stored['coef'], atol=1e-8, rtol=0)
        np.testing.assert_allclose(gap_fit.coef_, stored['OOF_refit_gap_diagnostic_coef'], atol=1e-8, rtol=0)
        mean = float(abs(np.average(remainder, axis=0, weights=w)).max())
        orth = float(abs(design.T@(w[:, None]*remainder)/w.sum()).max())
        assert mean<1e-8 and orth<1e-8
        result[family] = {'independent_OLS_rank': int(ols.rank_), 'retained_features': int(keep.sum()),
                          'independent_projection_gram_max_difference': projection_delta,
                          'independent_Ridge_coefficient_max_difference': coefficient_delta,
                          'independent_OOF_refit_gap_coefficient_max_difference': gap_delta,
                          'weighted_orthogonality_max': orth, 'weighted_residual_mean_max': mean}
    return result


def _portable_training_matrix(model, frame, stats):
    p = model['projection']
    x = POLY.transform(frame[MODEL_FEATURES].to_numpy(float))
    z = new_inputs(frame, stats, np.asarray(model['medians']), model['family'])
    design = np.column_stack([np.ones(len(frame)), (x-np.asarray(p['x_mean']))/p['x_scale']])
    remainder = (z-np.asarray(p['z_mean']))/p['z_scale']-design@np.asarray(p['projection'])
    return remainder[:, np.asarray(p['keep'], bool)]/p['residual_scale']


def verify_selection(report):
    rows = report['outer_choices']+[{'training_selection': report['inner_selection'],
                                     'selected': report['selected_train_only']}]
    for row in rows:
        scores = row['training_selection']
        baseline = scores['baseline']['summary']
        eligible = []
        for name, info in scores.items():
            s = info['summary']; low, bl = s['matched_low_IVB'], baseline['matched_low_IVB']
            score = low['player_MAE']+.25*s['all']['player_MAE']
            np.testing.assert_allclose(score, info['score'], atol=1e-12, rtol=0)
            available = name=='baseline' or (abs(low['bias'])<=abs(bl['bias'])-.30
                and low['player_MAE']<=bl['player_MAE']-.05
                and all(s[g]['player_MAE']<=baseline[g]['player_MAE']+m for g, m in
                        [('all', .15), ('middle35_60', .05), ('high60', .25), ('low20', .50)]))
            assert bool(available)==info['eligible']
            if available:
                eligible.append((score, name))
        assert min(eligible)[1]==row['selected']
    return len(rows)


def paired_gain(frame, base, pred, mask):
    delta = abs(np.asarray(base)[mask]-frame.arm_angle.to_numpy()[mask])-abs(np.asarray(pred)[mask]-frame.arm_angle.to_numpy()[mask])
    player_delta = pd.Series(delta).groupby(frame.pitcher.to_numpy()[mask]).mean().to_numpy()
    rng = np.random.default_rng(SEED)
    samples = [rng.choice(player_delta, len(player_delta), replace=True).mean() for _ in range(2000)]
    return {'players': len(player_delta), 'player_MAE_gain': float(player_delta.mean()),
            'bootstrap95': np.quantile(samples, [.025, .975]).tolist()}


def verify_reused(report, encoded, baseline, reference):
    path = OUT/(PREFIX+'_reused2025_report.json')
    reused = json.loads(path.read_text())
    table = pd.read_csv(OUT/(PREFIX+'_reused2025_predictions.csv'), dtype={'pitcher': str})
    assert reused['evaluation_is_reused_not_new_independent_confirmation']
    assert not reused['external_labels_used_for_training_or_reselection']
    assert reused['selected_before_evaluation']==reused['selected_after_evaluation']==report['selected_train_only']
    assert reused['locked_model_report_sha256']==sha(OUT/(PREFIX+'_model_report.json'))
    source_count, input_checks, metrics_checked = 0, [], 0
    for manifest in reused['source_manifests']:
        mpath = ROOT/manifest['path']
        assert sha(mpath)==manifest['sha256']
        metadata = json.loads(mpath.read_text())
        assert metadata['sources']==manifest['sources']
        parts = []
        for source in metadata['sources']:
            source_path = ROOT/source['path']
            assert sha(source_path)==source['sha256'] and source['rows']<25000
            raw = pd.read_csv(source_path, usecols=MLB_FIELDS+['arm_angle'], dtype={'pitcher': str})
            assert len(raw)==source['rows']
            if len(raw):
                parts.append(raw)
            source_count += 1
        raw = pd.concat(parts, ignore_index=True)
        keys = ['game_pk', 'at_bat_number', 'pitch_number']
        assert len(raw)==metadata['raw_rows']
        assert raw.game_year.eq(2025).all() and raw.game_type.eq('R').all()
        assert not raw.duplicated(keys).any()
        bio = pd.DataFrame([{'pitcher': pid, 'height_cm': b['height_cm'], 'pitch_hand': b['hand']}
                            for pid, b in metadata['bios'].items()])
        q = adapt_mlb(raw[MLB_FIELDS], bio)
        assert q[keys].equals(raw[keys])
        windows = [(period, raw.game_date.str.startswith(period).to_numpy())
                   for period in sorted(raw.game_date.str[:7].unique())]
        if len(windows)>1:
            windows.append(('2025-08_to_09', np.ones(len(raw), bool)))
        for period, window in windows:
            query = q.loc[window].reset_index(drop=True)
            y = raw.loc[window, 'arm_angle'].where(raw.loc[window, 'arm_angle'].between(-90, 90)).to_numpy()
            inputs = multi_inputs(query)
            labels = pd.DataFrame({'pitcher': query.pitcher_id.to_numpy(), 'angle': y})
            labels = labels.loc[query.numeric_valid.to_numpy()].groupby('pitcher').angle.agg(['mean', 'count', 'size'])
            valid = inputs.n.ge(100)&inputs.n_ff.ge(100)&np.isfinite(inputs[MODEL_FEATURES]).all(axis=1)
            valid &= (labels['count']/labels['size']).reindex(inputs.index).ge(.95)
            frame = inputs.loc[valid].copy()
            frame['pitcher'], frame['season'] = frame.index.astype(str), 2025
            expected = table.loc[table.period.eq(period)].reset_index(drop=True)
            np.testing.assert_array_equal(frame.pitcher, expected.pitcher)
            for feature in ['n', 'n_ff', 'ff_ivb_in', 'ff_speed55', 'left_hand']:
                np.testing.assert_allclose(frame[feature], expected[feature], atol=1e-10, rtol=0)
            label = labels.reindex(frame.pitcher)
            np.testing.assert_allclose(label['mean'], expected.arm_angle, atol=1e-10, rtol=0)
            np.testing.assert_array_equal(label['count'], expected.observed_angle_count)
            np.testing.assert_allclose(label['count']/label['size'], expected.observed_angle_coverage, atol=1e-12, rtol=0)
            assert expected.observed_angle_coverage.ge(.95).all()
            np.testing.assert_array_equal(expected.seen_in_reference, expected.pitcher.isin(reference.pitcher))
            np.testing.assert_array_equal(expected.seen_in_fixed_training,
                                         expected.pitcher.isin(reference.loc[reference.fixed_training_row, 'pitcher']))
            order = pd.MultiIndex.from_frame(frame[['pitcher', 'season']])
            clean = query.loc[query.numeric_valid&query.pitcher_id.isin(frame.pitcher)].reset_index(drop=True)
            statistics, _ = moments(clean, order=order)
            predictions = manual_predictions(encoded, baseline, frame, statistics)
            difference = 0.
            for name, pred in predictions.items():
                difference = max(difference, float(abs(pred-expected[name]).max()))
                np.testing.assert_allclose(pred, expected[name], atol=1e-8, rtol=0)
            input_checks.append({'period': period, 'players': len(expected),
                                 'labels_and_input_counts_rebuilt_from_daily_sources': True,
                                 'prediction_max_difference_deg': difference})
    for period, info in reused['periods'].items():
        query = table.loc[table.period.eq(period)].reset_index(drop=True)
        assert not query.pitcher.duplicated().any()
        groups = manual_masks(query)
        groups['unseen_reference'] = ~query.seen_in_reference.to_numpy()
        groups['unseen_fixed_training'] = ~query.seen_in_fixed_training.to_numpy()
        for group, mask in groups.items():
            sub = query.loc[mask]
            assert len(sub)==info['metrics'][group]['players']
            for name in OPTIONS:
                error = sub[name]-sub.arm_angle
                expected = info['metrics'][group]['models'][name]
                if len(sub):
                    np.testing.assert_allclose([error.abs().mean(), error.mean()],
                                              [expected['MAE'], expected['bias']], atol=1e-10, rtol=0)
                    metrics_checked += 2
                else:
                    assert expected['MAE'] is None and expected['bias'] is None
                offsets = report['intervals'][name]
                covered = sub.arm_angle.between(sub[name]+offsets['lower_residual_deg'], sub[name]+offsets['upper_residual_deg'])
                recorded = info['interval_coverage'][group][name]
                assert len(sub)==recorded['players'] and int(covered.sum())==recorded['covered']
                if len(sub):
                    np.testing.assert_allclose(covered.mean(), recorded['coverage'], atol=1e-12, rtol=0)
                else:
                    assert recorded['coverage'] is None
                if len(sub) and name!='baseline':
                    current = paired_gain(query, query.baseline, query[name], mask)
                    expected_gain = info['paired_player_MAE_gains'][group][name]
                    assert current['players']==expected_gain['players']
                    np.testing.assert_allclose([current['player_MAE_gain']]+current['bootstrap95'],
                                               [expected_gain['player_MAE_gain']]+expected_gain['bootstrap95'], atol=1e-10, rtol=0)
                    metrics_checked += 4
    return {'source_daily_files_verified': source_count, 'period_input_checks': input_checks,
            'verified_metric_values': metrics_checked,
            'reused_periods_not_new_independent_confirmation': True}


def verify_completion(report, table, encoded, d, stats, kbo, ks):
    path = OUT/(PREFIX+'_completion_audit.json')
    if not path.exists():
        return {'available': False}
    audit = json.loads(path.read_text())
    assert audit['locked_model_report_sha256']==sha(OUT/(PREFIX+'_model_report.json'))
    assert audit['selected_before_and_after_reuse']==report['selected_train_only']
    assert not audit['production_changed'] and not audit['operational_interval_narrowed']
    assert not audit['operational_promotion_approved']
    for name, groups in audit['candidate_player_paired_gains_diagnostic_not_posthoc_selection'].items():
        for group, expected in groups.items():
            current = paired_gain(table, table.baseline, table[name], manual_masks(table)[group])
            assert current['players']==expected['players']
            np.testing.assert_allclose([current['player_MAE_gain']]+current['bootstrap95'],
                                       [expected['player_MAE_gain']]+expected['bootstrap95'], atol=1e-10, rtol=0)
    sample = pd.read_csv(OUT/(PREFIX+'_actual_resampling.csv'), dtype={'pitcher_id': str})
    ivb = pd.read_csv(OUT/(PREFIX+'_IVB_continuity.csv'), dtype={'pitcher_id': str})
    assert len(sample)==300 and len(ivb)==264
    assert sample.groupby(['pitcher_id', 'repeat']).type_count.apply(lambda p: tuple(p)==(29, 30, 31)).all()
    assert ivb.groupby('pitcher_id').size().eq(33).all()
    for name in OPTIONS:
        wide = sample.pivot(index=['pitcher_id', 'repeat'], columns='type_count', values=name)
        changes = abs(np.diff(wide[[29, 30, 31]].to_numpy(), axis=1)).ravel()
        expected = audit['stability']['actual_nested_resampling'][name]
        assert len(changes)==expected['adjacent_steps']
        np.testing.assert_allclose([changes.max(), np.quantile(changes, .95)],
                                   [expected['max_deg'], expected['p95_deg']], atol=1e-10, rtol=0)
        maximum = ivb.groupby('pitcher_id')[name].apply(lambda p: abs(np.diff(p)).max()).max()
        np.testing.assert_allclose(maximum, audit['stability']['IVB_max0p25inch_step_deg'][name], atol=1e-10, rtol=0)
    projection_rows = pd.read_csv(OUT/(PREFIX+'_projection_diagnostic.csv'), dtype={'pitcher_id': str})
    populations = [('training', np.flatnonzero(d.fixed_training_row)),
                   ('fixed2024', np.flatnonzero(d.eval2024_independent_train_and_calibration_player))]
    cases = [(name, d.iloc[p], {k: v[p] for k, v in stats.items()}) for name, p in populations]
    cases.append(('KBO2026', kbo, ks))
    for family, model in encoded['models'].items():
        for label, frame, values in cases:
            matrix = _portable_training_matrix(model, frame, values)
            coordinates = abs(matrix).max(axis=1)
            raw = matrix@np.asarray(model['coef'])
            gap = matrix@np.asarray(model['OOF_refit_gap_diagnostic_coef'])
            weights = manual_weights(frame) if label=='training' else np.ones(len(frame))
            expected = audit['projection'][family][label]
            assert expected['rows']==len(frame) and expected['features_retained']==matrix.shape[1]
            np.testing.assert_allclose(np.quantile(coordinates, [.5, .95, 1.]),
                                       expected['max_abs_standardized_coordinate_p50_p95_max'], atol=1e-8, rtol=0)
            actual = [np.average(raw, weights=weights), np.average(5*np.tanh(raw/5), weights=weights),
                      np.sqrt(np.mean(raw**2)), np.sqrt(np.mean(gap**2))]
            values_expected = [expected[k] for k in ['raw_correction_weighted_mean', 'bounded_correction_weighted_mean',
                                                  'raw_correction_RMS', 'OOF_refit_gap_component_RMS']]
            np.testing.assert_allclose(actual, values_expected, atol=1e-10, rtol=0)
            rows = projection_rows.loc[projection_rows.population.eq(label)&projection_rows.family.eq(family)]
            np.testing.assert_array_equal(rows.pitcher_id, frame.pitcher)
            np.testing.assert_allclose(rows.max_abs_standardized_coordinate, coordinates, atol=1e-8, rtol=0)
            np.testing.assert_allclose(rows.raw_correction_deg, raw, atol=1e-8, rtol=0)
            np.testing.assert_allclose(rows.OOF_refit_gap_component_deg, gap, atol=1e-8, rtol=0)
    return {'available': True, 'candidate_player_bootstrap_verified': True,
            'resampling_rows_verified': len(sample), 'IVB_scenario_rows_verified': len(ivb),
            'projection_population_rows_verified': len(projection_rows)}


def main():
    report_path = OUT/(PREFIX+'_model_report.json')
    report = json.loads(report_path.read_text())
    encoded = json.loads((OUT/(PREFIX+'_candidate_models.json')).read_text())
    baseline = json.loads((ROOT/'data/models/estimated_arm_angle_v3.json').read_text())
    assert sha(ROOT/'data/models/estimated_arm_angle_v3.json')==V3_SHA==report['sha256']['frozen_v3']
    assert encoded['baseline_v3_SHA']==V3_SHA and not encoded['production_approved']
    assert encoded['model_report_sha256']==sha(report_path)
    for name, file in [('features', 'pitch_joint_eaa_features.py'), ('models', 'orthogonal_residual_eaa_models.py'),
                       ('script', 'run_eaa_orthogonal_residual_20261006.py'),
                       ('predeclared_plan', 'eaa-2026-orthogonal-residual-plan.md')]:
        assert report['sha256'][name]==sha(Path(__file__).with_name(file))
    d = pd.read_parquet(ROOT/'.cache/arm_angle/low_ivb_20261006/type_targets/mlb.parquet')
    stats = load_stats(INPUT_CACHE/'mlb_moments.npz')
    manifest = json.loads((INPUT_CACHE/'mlb_manifest.json').read_text())
    assert manifest['moments_sha256']==sha(INPUT_CACHE/'mlb_moments.npz')
    with (CACHE/'fixed_models.pkl').open('rb') as stream:
        saved = pickle.load(stream)
    table = pd.read_csv(OUT/(PREFIX+'_mlb_predictions.csv'), dtype={'pitcher': str})
    np.testing.assert_array_equal(table.pitcher, d.pitcher)
    np.testing.assert_array_equal(table.season, d.season)
    assert not table[list(OPTIONS)+['nested_selected']].isna().any().any()
    test = pd.read_csv(OUT/(PREFIX+'_independent2024_predictions.csv'), dtype={'pitcher': str})
    train = np.flatnonzero(d.fixed_training_row)
    calibration = np.flatnonzero(d.selected_single_period_calibration_row)
    test_pos = np.flatnonzero(d.eval2024_independent_train_and_calibration_player)
    ids = [set(d.iloc[p].pitcher) for p in [train, calibration, test_pos]]
    assert ids[0].isdisjoint(ids[1]|ids[2]) and ids[1].isdisjoint(ids[2])
    assert len(calibration)==len(ids[1])==152 and len(test)==len(ids[2])==196
    assert len(train)==1095 and len(ids[0])==518 and d.iloc[train].season.max()==2023
    np.testing.assert_array_equal(test.pitcher, d.iloc[test_pos].pitcher)
    for fold in sorted(d.outer_fold.unique()):
        assert set(d.loc[d.outer_fold.eq(fold), 'pitcher']).isdisjoint(d.loc[d.outer_fold.ne(fold), 'pitcher'])
        choice = next(row['selected'] for row in report['outer_choices'] if row['fold']==fold)
        np.testing.assert_allclose(table.loc[d.outer_fold.eq(fold), 'nested_selected'],
                                   table.loc[d.outer_fold.eq(fold), choice], atol=1e-12, rtol=0)
    metric_count = 0
    for name in OPTIONS+('nested_selected',):
        metric_count += close_summary(manual_summary(table, table[name]), report['OOF'][name])
    for name in OPTIONS:
        metric_count += close_summary(manual_summary(test, test[name]), report['independent2024'][name])
    high_coverage = stats['observed_n']/stats['n']>=.95
    assert int(high_coverage.sum())==report['label_coverage95_seasons']
    for name in OPTIONS:
        metric_count += close_summary(manual_summary(table.loc[high_coverage], table.loc[high_coverage, name]),
                                       report['high_coverage_OOF'][name])
    selection_count = verify_selection(report)
    masks = manual_masks(table)
    for group, recorded in report['paired_player_gains'].items():
        current = paired_gain(table, table.baseline, table.nested_selected, masks[group])
        assert current['players']==recorded['players']
        np.testing.assert_allclose([current['player_MAE_gain']]+current['bootstrap95'],
                                   [recorded['player_MAE_gain']]+recorded['bootstrap95'], atol=1e-10, rtol=0)
        metric_count += 4
    training = verify_training(d.iloc[train], {k: v[train] for k, v in stats.items()}, encoded, saved)
    kbo = pd.read_parquet(ROOT/'.cache/arm_angle/low_ivb_20261006/kbo_multi.parquet')
    valid = kbo.n.ge(100)&kbo.n_ff.ge(100)&np.isfinite(kbo[MODEL_FEATURES]).all(axis=1)
    kbo = kbo.loc[valid].copy()
    kbo['pitcher'] = kbo.index.astype(str)
    kbo = kbo.reset_index(drop=True)
    ks = load_stats(INPUT_CACHE/'kbo_moments.npz')
    kt = pd.read_csv(OUT/(PREFIX+'_KBO2026_predictions.csv'), dtype={'pitcher_id': str})
    np.testing.assert_array_equal(kt.pitcher_id, kbo.pitcher)
    kp = manual_predictions(encoded, baseline, kbo, ks)
    kbo_difference = 0.
    for name, p in kp.items():
        kbo_difference = max(kbo_difference, float(abs(p-kt[name]).max()))
        np.testing.assert_allclose(p, kt[name], atol=1e-8, rtol=0)
    selected = report['selected_train_only']
    np.testing.assert_allclose(kt.selected_angle_deg, kp[selected], atol=1e-8, rtol=0)
    for f in FAMILIES:
        np.testing.assert_allclose(portable_raw(encoded['models'][f], kbo, ks), kt[f+'_raw_correction'], atol=1e-8, rtol=0)
    cal_pred = manual_predictions(encoded, baseline, d.iloc[calibration], {k: v[calibration] for k, v in stats.items()})
    test_pred = manual_predictions(encoded, baseline, d.iloc[test_pos], {k: v[test_pos] for k, v in stats.items()})
    for name in OPTIONS:
        np.testing.assert_allclose(test_pred[name], test[name], atol=1e-8, rtol=0)
        residual = np.sort(d.iloc[calibration].arm_angle.to_numpy()-cal_pred[name])
        lo = residual[max(1, int(np.floor((len(residual)+1)*.05)))-1]
        hi = residual[min(len(residual), int(np.ceil((len(residual)+1)*.95)))-1]
        recorded = report['intervals'][name]
        np.testing.assert_allclose([lo, hi, hi-lo], [recorded['lower_residual_deg'], recorded['upper_residual_deg'], recorded['width_deg']], atol=1e-8, rtol=0)
        covered = (test.arm_angle.to_numpy()-test_pred[name]>=lo)&(test.arm_angle.to_numpy()-test_pred[name]<=hi)
        for group, mask in manual_masks(test).items():
            info = recorded['fixed2024'][group]
            assert int(mask.sum())==info['players'] and int(covered[mask].sum())==info['covered']
            if mask.any():
                np.testing.assert_allclose(covered[mask].mean(), info['coverage'], atol=1e-12, rtol=0)
        metric_count += 3
    oof, fixed = report['OOF'], report['independent2024']
    low, bl = oof['nested_selected']['matched_low_IVB'], oof['baseline']['matched_low_IVB']
    fl, fb = fixed[selected]['matched_low_IVB'], fixed['baseline']['matched_low_IVB']
    gains = report['paired_player_gains']
    checks = {'nonbaseline_selected': selected!='baseline',
              'nested_lowIVB_bias_gain0p30': abs(low['bias'])<=abs(bl['bias'])-.30,
              'nested_lowIVB_MAE_CI_lower_gt0': gains['matched_low_IVB']['bootstrap95'][0]>0,
              'nested_all_noninferiority': gains['all']['bootstrap95'][0]>=-.10,
              'nested_high_noninferiority': gains['high60']['bootstrap95'][0]>=-.25,
              'fixed2024_lowIVB_MAE_improves': fl['player_MAE']<fb['player_MAE'],
              'fixed2024_lowIVB_bias_improves': abs(fl['bias'])<abs(fb['bias']),
              'fixed2024_all_margin': fixed[selected]['all']['MAE']<=fixed['baseline']['all']['MAE']+.15,
              'fixed2024_high_margin': fixed[selected]['high60']['MAE']<=fixed['baseline']['high60']['MAE']+.25}
    assert checks==report['promotion_checks_MLB']
    assert bool(all(checks.values()))==report['promotion_eligible_MLB']
    source = source_check(d, stats)
    reused = verify_reused(report, encoded, baseline, d)
    completion = verify_completion(report, table, encoded, d, stats, kbo, ks)
    result = {'passed': True, 'verified_metric_values': metric_count,
              'selection_runs_independently_verified': selection_count,
              'player_splits_verified': True, 'training_target_player_crossfit_verified': True,
              'actual_training_seasons': len(train), 'independent_training_equation_checks': training,
              'KBO_players_recomputed': len(kt), 'KBO_prediction_max_difference_deg': kbo_difference,
              'calibration_order_statistics_and_coverage_verified': True,
              'promotion_checks_independently_verified': True, 'source_checks': source,
              'reused2025_independent_checks': reused, 'completion_audit_independent_checks': completion,
              'operational_model_unchanged': True, 'production_changed': False,
              'sha256': {'verifier': sha(Path(__file__)), 'model_report': sha(report_path), 'frozen_v3': V3_SHA}}
    save(OUT/(PREFIX+'_verification.json'), result)
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__=='__main__':
    main()
