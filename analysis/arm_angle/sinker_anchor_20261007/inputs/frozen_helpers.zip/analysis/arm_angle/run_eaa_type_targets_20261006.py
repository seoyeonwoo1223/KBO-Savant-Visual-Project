"""MAE 선택을 먼저 분리 확인하고 구종별 정답 후보를 같은 분리로 평가한다."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from run_conditional_eaa_20261006 import ROOT, OUT, sha, save
import run_eaa_low_ivb_20261006 as common
from multi_pitch_eaa_models import SEED
from type_target_eaa_features import assemble, CACHE, PREFIX
from type_target_eaa_models import OPTIONS, fit_all, predict_all


def select_scores(scores):
    baseline = scores['baseline']['summary']; eligible = []
    for name, row in scores.items():
        s = row['summary']; low, base = s['matched_low_IVB'], baseline['matched_low_IVB']
        accept = name=='baseline' or (abs(low['bias'])<=abs(base['bias'])-.30
            and low['player_MAE']<=base['player_MAE']-.05
            and all(s[g]['player_MAE']<=baseline[g]['player_MAE']+margin
                for g, margin in [('all', .15), ('middle35_60', .05), ('high60', .25), ('low20', .50)]))
        score = low['player_MAE']+.25*s['all']['player_MAE']
        row.update({'eligible': bool(accept), 'score': float(score)})
        if accept: eligible.append((score, name))
    return min(eligible)[1]


def choose_mae(d, label):
    prediction = {name: np.full(len(d), np.nan) for name in OPTIONS}
    for fold, (train, val) in enumerate(GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=d.pitcher)):
        assert set(d.iloc[train].pitcher).isdisjoint(d.iloc[val].pitcher)
        p, _ = predict_all(fit_all(d.iloc[train]), d.iloc[val])
        for name in p: prediction[name][val] = p[name]
        print(label, 'MAE 선택 inner', fold, flush=True)
    scores = {name: {'summary': common.summary(d, p)} for name, p in prediction.items()}
    return select_scores(scores), scores


def rescore_previous(d):
    path = OUT/'eaa_continuous_20261006_model_report.json'; original = json.loads(path.read_text())
    q = pd.read_csv(OUT/'eaa_continuous_20261006_mlb_predictions.csv', dtype={'pitcher': str})
    assert q[['pitcher', 'season']].equals(d[['pitcher', 'season']])
    choices = []
    for row in original['outer_choices']:
        chosen = select_scores(row['training_selection'])
        mask = q.outer_fold.eq(row['fold']); q.loc[mask, 'MAE_selected'] = q.loc[mask, chosen]
        choices.append({'fold': row['fold'], 'old_choice': row['selected'], 'MAE_choice': chosen})
    fixed = select_scores(original['inner_selection'])
    save(OUT/(PREFIX+'_selection_only.json'), {'original_report_sha256': sha(path), 'outer_choices': choices,
        'old_fixed_choice': original['selected_train_only'], 'MAE_fixed_choice': fixed,
        'old_nested': common.summary(d, q.nested_selected), 'MAE_nested': common.summary(d, q.MAE_selected),
        'models_or_inputs_changed': False})
    q[['pitcher', 'season', 'arm_angle', 'outer_fold', 'nested_selected', 'MAE_selected']].to_csv(OUT/(PREFIX+'_selection_only_predictions.csv'), index=False)


def main():
    d, manifest = assemble(); kbo, kmanifest = common.assemble_kbo()
    rescore_previous(d)
    common.CACHE = CACHE; common.PREFIX = PREFIX; common.OPTIONS = OPTIONS
    common.fit_all = fit_all; common.predict_all = predict_all; common.choose = choose_mae
    common.MODEL_CODE = Path(__file__).with_name('type_target_eaa_models.py')
    models, selected, report = common.evaluate(d)
    common.kbo_cases(kbo, models, selected)
    report['type_target_inputs'] = manifest; report['KBO_inputs'] = kmanifest
    report['selection_objective'] = '낮은 IVB 투수별MAE+0.25*전체 투수별MAE; 편향은 제약'
    report['sha256'].update({'type_target_features': sha(Path(__file__).with_name('type_target_eaa_features.py')),
        'type_target_script': sha(Path(__file__)), 'type_target_plan': sha(Path(__file__).with_name('eaa-2026-type-target-plan.md'))})
    report['new_external_labels_opened_before_selection'] = False
    report['production_changed'] = False
    save(OUT/(PREFIX+'_model_report.json'), report)
    print('MAE·구종 정답 고정 선택', selected, 'MLB 승격', report['promotion_eligible_MLB'], flush=True)


if __name__=='__main__': main()
