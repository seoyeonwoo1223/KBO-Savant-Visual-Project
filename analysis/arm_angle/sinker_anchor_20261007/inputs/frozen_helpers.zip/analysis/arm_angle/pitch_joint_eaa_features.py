"""관측 각도를 입력과 분리한 투구별 변환과 시즌 충분통계."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures

from visualbaseball.numeric_arm_angle_features import (
    GEOMETRY, KINEMATICS, MOVEMENT, MODEL_FEATURES, pitch_features,
    quality_mask, G, FT_M,
)
from visualbaseball.curated import load_rows
from visualbaseball.estimated_arm_angle import _heights, _name
from visualbaseball.eaa_movement_calibration import calibrate_eaa
from direct_numeric_features import mlb_adapter
from multi_pitch_eaa_features import GROUPS, ALIASES, multi_inputs
from run_conditional_eaa_20261006 import ROOT, OUT, sha, save

CACHE = ROOT/'.cache/arm_angle/pitch_joint_20261006'
PREFIX = 'eaa_pitch_joint_20261006'
BASE_COLUMNS = GEOMETRY+KINEMATICS+MOVEMENT
POLY = PolynomialFeatures(2, include_bias=False).fit(np.zeros((1, len(BASE_COLUMNS))))
KINDS = GROUPS[1:]+('OTHER',)
PAIR_NAMES = ['game_height_speed', 'game_side_speed', 'game_height_ivb',
              'game_side_hb', 'game_height_side', 'game_pair_support']
BASIS_NAMES = POLY.get_feature_names_out(BASE_COLUMNS).tolist()+['kind_'+g for g in KINDS]+PAIR_NAMES
JOINT = np.arange(len(BASIS_NAMES))
GEOMETRIC = np.r_[np.flatnonzero(~POLY.powers_[:, 8:].any(axis=1)),
                  np.arange(len(POLY.powers_), len(POLY.powers_)+len(KINDS)),
                  len(POLY.powers_)+len(KINDS)+np.array([0, 1, 4, 5])]
MLB_FIELDS = ['pitcher', 'game_date', 'game_type', 'game_year', 'game_pk',
              'at_bat_number', 'pitch_number', 'pitch_type', 'p_throws',
              'release_pos_x', 'release_pos_y', 'release_pos_z',
              'vx0', 'vy0', 'vz0', 'ax', 'ay', 'az']
KBO_FIELDS = ['season', 'game_id', 'pitch_id', 'pitcher_id', 'pitcher_name',
              'pitch_type_code', 'stadium', 'x0', 'y0', 'z0', 'vx0', 'vy0',
              'vz0', 'ax', 'ay', 'az', 'px', 'pz', 'sz_top', 'sz_bottom',
              'horizontal_movement_cm', 'vertical_movement_cm', 'source_y0']


def basis(frame):
    """관측 각도, 선수/경기 ID의 수치값을 예측 변수로 사용하지 않는다."""
    q = frame.copy()
    kinds = q.pitch_type_code.replace(ALIASES)
    kinds = kinds.where(kinds.isin(GROUPS), 'OTHER')
    q['kind'] = kinds
    q['ivb_m'] = q.movement_size_m*q.movement_axis_up_cos
    q['hb_m'] = q.movement_size_m*q.movement_axis_arm_sin
    cols = ['z55_over_height', 'side55_over_height', 'speed55', 'ivb_m', 'hb_m']
    groups = q.groupby(['pitcher_id', 'game_key', 'kind'], sort=False)
    center = q[cols]-groups[cols].transform('mean')
    count = groups.speed55.transform('size').to_numpy(float)
    support = (count-1)/(count+4)
    z, s, v, ivb, hb = center.to_numpy(float).T
    pairs = np.column_stack([z*v, s*v, z*ivb, s*hb, z*s])*support[:, None]
    indicator = np.column_stack([kinds.eq(g).to_numpy(float) for g in KINDS])
    result = np.column_stack([POLY.transform(q[BASE_COLUMNS].to_numpy(float)),
                              indicator, pairs, support])
    assert np.isfinite(result).all()
    return result


def moments(frame, observed=None, order=None):
    """각 시즌 총 가중치를 고정할 수 있는 정확한 투구별 평균 통계."""
    q = frame.loc[frame.numeric_valid].reset_index(drop=True)
    keys = pd.MultiIndex.from_arrays([q.pitcher_id.astype(str), q.season.astype(int)],
                                     names=['pitcher', 'season'])
    if order is None:
        order = keys.unique().sort_values()
    position = order.get_indexer(keys)
    assert (position>=0).all()
    x = basis(q)
    n, p = len(order), x.shape[1]
    result = {'x_mean': np.zeros((n, p)), 'n': np.zeros(n, dtype=int)}
    if observed is not None:
        y = np.asarray(observed, float)
        assert len(y)==len(frame)
        y = y[frame.numeric_valid.to_numpy()]
        result.update({'train_x_mean': np.full((n, p), np.nan),
                       'train_xx_mean': np.full((n, p, p), np.nan),
                       'train_xy_mean': np.full((n, p), np.nan),
                       'train_y_mean': np.full(n, np.nan),
                       'observed_n': np.zeros(n, dtype=int)})
    grouped = pd.Series(np.arange(len(q))).groupby(position, sort=True)
    for i, rows in grouped:
        idx = rows.to_numpy()
        result['x_mean'][i] = x[idx].mean(axis=0)
        result['n'][i] = len(idx)
        if observed is not None:
            valid = np.isfinite(y[idx])&(abs(y[idx])<=90)
            xx, yy = x[idx][valid], y[idx][valid]
            result['observed_n'][i] = len(yy)
            if len(yy):
                result['train_x_mean'][i] = xx.mean(axis=0)
                result['train_xx_mean'][i] = xx.T@xx/len(yy)
                result['train_xy_mean'][i] = xx.T@yy/len(yy)
                result['train_y_mean'][i] = yy.mean()
    assert (result['n']>0).all()
    return result, order


def subset(stats, positions):
    return {key: value[np.asarray(positions)] for key, value in stats.items()}


def combine(parts):
    return {key: np.concatenate([p[key] for p in parts]) for key in parts[0]}


def load_stats(path):
    with np.load(path, allow_pickle=False) as saved:
        return {k: saved[k] for k in saved.files}


def adapt_mlb(raw, bio):
    """호출부에서 관측 각도를 입력에서 제거한 뒤 사용한다."""
    assert 'arm_angle' not in raw, '관측 각도를 먼저 입력에서 제거해야 합니다'
    q = raw.copy()
    q['pitcher'] = q.pitcher.astype(str)
    q = q.merge(bio, on='pitcher', how='left', validate='many_to_one')
    assert (q.pitch_hand.isna()|q.p_throws.eq(q.pitch_hand)
            |(q.pitch_hand.eq('S')&q.p_throws.isin(['R', 'L']))).all()
    q['pitcher_id'] = q.pitcher
    q['pitch_type_code'] = q.pitch_type
    q['game_key'] = q.game_pk.astype(str)
    q['season'] = q.game_year
    q = pitch_features(mlb_adapter(q))
    q.numeric_valid &= q.ay.between(5, 55)&np.hypot(q.ax, q.az+G/FT_M).le(45)
    return q


def assemble_mlb():
    CACHE.mkdir(parents=True, exist_ok=True)
    old = ROOT/'.cache/arm_angle/low_ivb_20261006'
    dpath = old/'type_targets/mlb.parquet'
    d = pd.read_parquet(dpath)
    source = json.loads((old/'mlb_manifest.json').read_text())['sources']
    expected = {'reference_sha256': sha(dpath), 'sources': source,
                'bio_sha256': sha(OUT/'direct_mlb_inputs.csv'),
                'feature_code_sha256': sha(Path(__file__))}
    path, manifest = CACHE/'mlb_moments.npz', CACHE/'mlb_manifest.json'
    if path.exists():
        saved = json.loads(manifest.read_text())
        assert saved['inputs']==expected and saved['moments_sha256']==sha(path)
        return d, load_stats(path), saved
    bio = pd.read_csv(OUT/'direct_mlb_inputs.csv', dtype={'pitcher': str},
                      usecols=['pitcher', 'season', 'height_cm', 'pitch_hand'])
    parts, coverage = [], []
    for year in range(2020, 2025):
        paths = [ROOT/p for p in source if p.endswith(f'_{year}.parquet') or p.endswith(f'-{year}.parquet')]
        assert len(paths)==2
        for p in paths:
            assert sha(p)==source[str(p.relative_to(ROOT))]
        raw = pd.concat([pd.read_parquet(p, columns=MLB_FIELDS+['arm_angle']) for p in paths], ignore_index=True)
        raw.pitcher = raw.pitcher.astype(str)
        assert raw.game_type.eq('R').all() and raw.game_year.eq(year).all()
        assert not raw.duplicated(['game_pk', 'at_bat_number', 'pitch_number']).any()
        bio_year = bio.loc[bio.season.eq(year)].drop(columns='season')
        q = adapt_mlb(raw.drop(columns='arm_angle'), bio_year)
        # merge의 행 순서를 고정하고 정답은 입력 처리가 끝난 뒤 연결한다.
        assert q[['game_pk', 'at_bat_number', 'pitch_number']].equals(raw[['game_pk', 'at_bat_number', 'pitch_number']])
        order = pd.MultiIndex.from_frame(d.loc[d.season.eq(year), ['pitcher', 'season']])
        # 기존 모집단 밖의 선수는 참조 시즌 통계에 포함하지 않는다.
        keep = q.pitcher_id.isin(order.get_level_values('pitcher'))
        q = q.loc[keep].reset_index(drop=True)
        y = raw.loc[keep, 'arm_angle'].where(raw.loc[keep, 'arm_angle'].between(-90, 90)).to_numpy()
        stat, _ = moments(q, y, order)
        ref = d.loc[d.season.eq(year)]
        np.testing.assert_array_equal(stat['n'], ref.n)
        np.testing.assert_allclose(stat['train_y_mean'], ref.valid_pitch_observed_mean, atol=1e-10)
        parts.append((year, stat))
        coverage.append({'season': year, 'valid_pitches': int(stat['n'].sum()),
                         'observed_pitches': int(stat['observed_n'].sum()),
                         'seasons': len(ref), 'coverage95_seasons': int((stat['observed_n']/stat['n']>=.95).sum())})
        print('투구별 충분통계', year, int(stat['n'].sum()), flush=True)
    # 원래 정렬은 선수→시즌 순서다. 연도 순서로 계산한 통계를 재정렬한다.
    stats = combine([p[1] for p in parts])
    concat_index = pd.concat([d.loc[d.season.eq(y), ['pitcher', 'season']] for y, _ in parts], ignore_index=True)
    source_order = pd.MultiIndex.from_frame(concat_index)
    target_order = pd.MultiIndex.from_frame(d[['pitcher', 'season']])
    stats = subset(stats, source_order.get_indexer(target_order))
    assert (stats['observed_n']>=30).all()
    np.savez(path, **stats)
    saved = {'inputs': expected, 'coverage': coverage, 'basis_names': BASIS_NAMES,
             'geometry_indices': GEOMETRIC.tolist(), 'moments_sha256': sha(path),
             'season_target_vs_valid_pitch_mean_max_abs_deg': float(abs(d.arm_angle-stats['train_y_mean']).max())}
    save(manifest, saved)
    return d, stats, saved


def assemble_kbo():
    old = ROOT/'.cache/arm_angle/low_ivb_20261006'
    d = pd.read_parquet(old/'kbo_multi.parquet')
    valid = d.n.ge(100)&d.n_ff.ge(100)&np.isfinite(d[MODEL_FEATURES]).all(axis=1)
    d = d.loc[valid].copy()
    d['pitcher'] = d.index.astype(str)
    d['season'] = 2026
    d = d.reset_index(drop=True)
    expected = {'season': 2026, 'summary_sha256': sha(ROOT/'data/curated/summary.json'),
                'schema_sha256': sha(ROOT/'data/curated/schema.json'),
                'heights_sha256': sha(ROOT/'data/tracking/player_heights.csv'),
                'bio_sha256': sha(ROOT/'data/curated/players/player_bio.parquet'),
                'previous_input_sha256': sha(old/'kbo_multi.parquet'),
                'feature_code_sha256': sha(Path(__file__))}
    path, manifest = CACHE/'kbo_moments.npz', CACHE/'kbo_manifest.json'
    if path.exists():
        saved = json.loads(manifest.read_text())
        assert saved['inputs']==expected and saved['moments_sha256']==sha(path)
        return d, load_stats(path), saved
    rows = [r for r in load_rows(ROOT, 'pitches', 2026, columns=KBO_FIELDS) if r.get('pitcher_id')]
    raw = pd.DataFrame(rows)
    raw.pitcher_id = raw.pitcher_id.astype(str)
    heights = _heights(ROOT)
    bio = pd.read_parquet(ROOT/'data/curated/players/player_bio.parquet', columns=['player_id', 'player_name', 'throws'])
    bio.player_id = bio.player_id.astype(str)
    bio = bio.set_index('player_id').to_dict('index')
    raw['height_cm'] = pd.to_numeric(raw.pitcher_id.map(lambda p: heights.get(p, {}).get('height_cm')), errors='coerce')
    raw['pitcher_hand'] = raw.pitcher_id.map(lambda p: {'R': 'Right', 'L': 'Left'}.get(bio.get(p, {}).get('throws')))
    identity = raw.pitcher_name.map(_name).eq(raw.pitcher_id.map(lambda p: _name(heights.get(p, {}).get('player_name'))))
    identity &= raw.pitcher_name.map(_name).eq(raw.pitcher_id.map(lambda p: _name(bio.get(p, {}).get('player_name'))))
    numeric = KBO_FIELDS[7:]
    raw[numeric] = raw[numeric].apply(pd.to_numeric, errors='coerce')
    adjusted = calibrate_eaa(rows, raw.pitch_type_code.fillna('').tolist(), 2026)
    q = pitch_features(raw, adjusted)
    q.numeric_valid &= quality_mask(raw)&identity.to_numpy()
    q['game_key'] = q.game_id.astype(str)
    control = multi_inputs(q).reindex(d.pitcher)
    np.testing.assert_allclose(control[MODEL_FEATURES], d[MODEL_FEATURES], atol=1e-10, rtol=0)
    order = pd.MultiIndex.from_frame(d[['pitcher', 'season']])
    clean = q.loc[q.pitcher_id.isin(d.pitcher)&q.numeric_valid].reset_index(drop=True)
    stat, _ = moments(clean, order=order)
    np.testing.assert_array_equal(stat['n'], d.n)
    columns = ['pitcher_id', 'season', 'game_key', 'pitch_type_code', 'numeric_valid']+BASE_COLUMNS
    clean[columns].to_parquet(CACHE/'kbo_pitches.parquet', index=False)
    np.savez(path, **stat)
    schema = json.loads((ROOT/'data/curated/schema.json').read_text())
    names = [c['name'] for c in schema['tables']['pitches']]
    saved = {'inputs': expected, 'players': len(d), 'valid_pitches': len(clean),
             'moments_sha256': sha(path), 'pitch_input_sha256': sha(CACHE/'kbo_pitches.parquet'),
             'independent_variables': {
                 'RPM_columns': [c for c in names if 'spin' in c.lower() or 'rpm' in c.lower()],
                 'extension_columns': [c for c in names if 'extension' in c.lower()],
                 'arm_length_or_wingspan_columns': [],
                 'reference_y0_counts': {str(k): int(v) for k, v in raw.y0.value_counts(dropna=False).items()},
                 'source_y0_counts': {str(k): int(v) for k, v in raw.source_y0.value_counts(dropna=False).items()},
                 'y0_is_trajectory_reference_plane_not_extension': True,
                 'height_metadata_fields': pd.read_csv(ROOT/'data/tracking/player_heights.csv', nrows=0).columns.tolist(),
                 'independent_measurements_imputed': False}}
    save(manifest, saved)
    print('KBO2026 투구별 충분통계', len(d), len(clean), flush=True)
    return d, stat, saved


if __name__=='__main__':
    assemble_mlb()
    assemble_kbo()
