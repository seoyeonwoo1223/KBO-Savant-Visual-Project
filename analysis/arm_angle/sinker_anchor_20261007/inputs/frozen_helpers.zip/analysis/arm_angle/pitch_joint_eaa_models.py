"""투구별 정확한 가중 충분통계와 입력 분포 가중의 연구 전용 적합."""
import numpy as np
from scipy.linalg import solve
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score

from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES
from multi_pitch_eaa_features import training_weights
from multi_pitch_eaa_models import ridge_fit
from pitch_joint_eaa_features import JOINT, GEOMETRIC, subset

OPTIONS = ('baseline', 'moment_joint', 'pitch_joint', 'pitch_geometry',
           'moment_joint_domain', 'pitch_joint_domain', 'pitch_geometry_domain')
ALPHA = 100.


def fit_domain(source, target):
    """관측 각도가 아닌 현재 학습 입력과 고정 KBO 입력만 사용한다."""
    a = source[MODEL_FEATURES].to_numpy(float)
    b = target[MODEL_FEATURES].to_numpy(float)
    x = np.vstack([a, b])
    labels = np.r_[np.zeros(len(a)), np.ones(len(b))]
    scaler = StandardScaler().fit(x)
    model = LogisticRegression(C=.1, class_weight='balanced', max_iter=1000,
                               solver='lbfgs', random_state=20261006)
    model.fit(scaler.transform(x), labels)
    margin = model.decision_function(scaler.transform(x))
    # 균형 클래스 prior에서 posterior odds가 밀도비 근사다.
    ratios = np.clip(np.exp(np.clip(margin[:len(a)], -30, 30)), .25, 4.)
    diagnostic = {'source_seasons': len(a), 'KBO_players': len(b),
                  'in_sample_domain_AUC_diagnostic_only': float(roc_auc_score(labels, margin)),
                  'raw_ratio_mean': float(ratios.mean()),
                  'ratio_min': float(ratios.min()), 'ratio_max': float(ratios.max()),
                  'lower_clip_fraction': float((ratios<=.25).mean()),
                  'upper_clip_fraction': float((ratios>=4).mean()),
                  'ratio_effective_seasons': float(ratios.sum()**2/(ratios@ratios)),
                  'label_or_identity_input_used': False, 'transductive_KBO_input_weighting': True}
    return {'mean': scaler.mean_, 'scale': scaler.scale_,
            'coef': model.coef_[0], 'intercept': float(model.intercept_[0])}, ratios, diagnostic


def domain_ratio(model, frame):
    x = frame[MODEL_FEATURES].to_numpy(float)
    logits = ((x-model['mean'])/model['scale'])@model['coef']+model['intercept']
    return np.clip(np.exp(np.clip(logits, -30, 30)), .25, 4.)


def fit_moments(stats, target, weights, indices, pitch_targets):
    """StandardScaler+Ridge의 직접 가중 적합과 같은 방정식을 푼다."""
    ix = np.asarray(indices, int)
    w = np.asarray(weights, float)
    total = w.sum()
    if pitch_targets:
        sx = np.einsum('n,np->p', w, stats['train_x_mean'][:, ix])
        sxx = np.einsum('n,npq->pq', w, stats['train_xx_mean'][:, ix][:, :, ix])
        sxy = np.einsum('n,np->p', w, stats['train_xy_mean'][:, ix])
        sy = w@stats['train_y_mean']
    else:
        x = stats['x_mean'][:, ix]
        sx = w@x
        sxx = x.T@(w[:, None]*x)
        sxy = x.T@(w*np.asarray(target, float))
        sy = w@np.asarray(target, float)
    mean = sx/total
    covariance = sxx-np.outer(sx, sx)/total
    covariance = (covariance+covariance.T)/2
    variance = np.maximum(np.diag(covariance)/total, 0.)
    scale = np.sqrt(variance)
    # 거의 상수인 항에서 반올림 오차로 비정상 스케일이 생기지 않게 한다.
    scale = np.where(variance<=1e-12, 1., scale)
    gram = covariance/np.outer(scale, scale)+ALPHA*np.eye(len(ix))
    rhs = (sxy-sx*sy/total)/scale
    coef = solve(gram, rhs, assume_a='pos')
    return {'indices': ix, 'mean': mean, 'scale': scale, 'coef': coef,
            'intercept': float(sy/total), 'pitch_target': bool(pitch_targets),
            'season_weight_sum': float(total), 'alpha': ALPHA}


def predict_moments(model, stats):
    x = stats['x_mean'][:, model['indices']]
    return ((x-model['mean'])/model['scale'])@model['coef']+model['intercept']


def predict_pitch_basis(model, matrix):
    x = matrix[:, model['indices']]
    return ((x-model['mean'])/model['scale'])@model['coef']+model['intercept']


def fit_all(d, stats, kbo):
    assert len(d)==len(stats['n']) and (stats['observed_n']>0).all()
    weights = training_weights(d)
    domain, ratio, diagnostic = fit_domain(d, kbo)
    result = {'baseline': ridge_fit(d, MODEL_FEATURES), 'domain': domain,
              'domain_diagnostic': diagnostic}
    for name in OPTIONS[1:]:
        domain_weight = name.endswith('_domain')
        w = weights*ratio if domain_weight else weights.copy()
        w *= len(d)/w.sum()
        indices = GEOMETRIC if name.startswith('pitch_geometry') else JOINT
        pitch_targets = not name.startswith('moment_')
        result[name] = fit_moments(stats, d.arm_angle.to_numpy(), w, indices, pitch_targets)
    return result


def predict_all(models, frame, stats):
    result = {'baseline': models['baseline'].predict(frame[MODEL_FEATURES].to_numpy(float))}
    for name in OPTIONS[1:]:
        result[name] = predict_moments(models[name], stats)
    return result


def portable(models):
    """충분통계 계수를 JSON에 보존해 NumPy로 다시 계산한다."""
    result = {}
    for name in OPTIONS[1:]:
        result[name] = {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in models[name].items()}
    return result
