"""Identical MLB/KBO context and force proxies; no measured spin or AA inputs."""
import numpy as np
import pandas as pd
from visualbaseball.arm_angle_aggregation import trimmed_mean
from visualbaseball.numeric_arm_angle_features import MODEL_FEATURES,season_features,plane_time

CONTEXT=['ff_share','ff_side_delta','ff_height_delta','ff_lateral_launch_delta',
         'ff_vertical_launch_delta','all_side_spread','all_height_spread','ff_speed_spread']
LIFT='ff_lift_proxy'

def context_inputs(frame):
    q=frame.loc[frame.numeric_valid].copy()
    base=season_features(q,'trimmed10')
    g=q.groupby('pitcher_id');ff=q.loc[q.pitch_type_code.eq('FF')].copy();fg=ff.groupby('pitcher_id')
    base['ff_share']=base.n_ff/base.n
    for name,col in [('ff_side_delta','side55_over_height'),('ff_height_delta','z55_over_height'),
                     ('ff_lateral_launch_delta','armside_vx_over_minus_vy'),('ff_vertical_launch_delta','vz_over_minus_vy')]:
        base[name]=fg[col].agg(trimmed_mean)-g[col].agg(trimmed_mean)
    base['all_side_spread']=g.side55_over_height.std(ddof=0)
    base['all_height_spread']=g.z55_over_height.std(ddof=0)
    base['ff_speed_spread']=fg.speed55.quantile(.9)-fg.speed55.quantile(.1)
    t50=plane_time(ff.y0,ff.vy0,ff.ay,50.)
    end=plane_time(ff.y0,ff.vy0,ff.ay,17/12.)
    # Magnitude divided by flight time squared and speed squared: a
    # lift-coefficient proxy, not active RPM or actual spin efficiency.
    ff['lift_proxy']=ff.movement_size_m/(.5*(end-t50)**2*ff.speed55**2)
    base[LIFT]=ff.groupby('pitcher_id').lift_proxy.agg(trimmed_mean)
    return base

def feature_set(family):
    if family in {'baseline','soft_blend'}:return MODEL_FEATURES
    if family=='direction':return [c for c in MODEL_FEATURES if c!='ff_movement_size_m']
    features=[c for c in MODEL_FEATURES if c!='ff_movement_size_m']+[LIFT] if 'lift' in family else MODEL_FEATURES.copy()
    if family=='context_direction':features=[c for c in MODEL_FEATURES if c!='ff_movement_size_m']
    if family.startswith('context'):features+=CONTEXT
    return features
