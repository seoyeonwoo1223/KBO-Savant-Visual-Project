"""낮은 IVB 저평가: 다구종/균형/교차적합을 투수 분리로 검증한다."""
from pathlib import Path
import argparse
import json
import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from visualbaseball.curated import load_rows
from visualbaseball.estimated_arm_angle import _heights, _name, _predict
from visualbaseball.eaa_movement_calibration import calibrate_eaa
from visualbaseball.numeric_arm_angle_features import (
    MODEL_FEATURES, pitch_features, quality_mask, G, FT_M,
)
from direct_numeric_features import mlb_adapter
from run_conditional_eaa_20261006 import ROOT, OUT, FOCUS, sha, save, gain
from multi_pitch_eaa_features import multi_inputs, GROUPS
from multi_pitch_eaa_models import OPTIONS, SEED, fit_all, predict_all

CACHE = ROOT/'.cache/arm_angle/low_ivb_20261006'
PREFIX = 'eaa_low_ivb_20261006'
FEATURE_CODE = Path(__file__).with_name('multi_pitch_eaa_features.py')
MODEL_CODE = Path(__file__).with_name('multi_pitch_eaa_models.py')


def assemble_mlb():
    source = json.loads((ROOT/'.cache/arm_angle/conditional_20261006/mlb_manifest.json').read_text())
    inputs = OUT/'robust_mlb_inputs.csv'
    expected = {'sources': source['sources'], 'feature_code_sha256': sha(FEATURE_CODE),
        'common_input_sha256': sha(inputs), 'bio_sha256': sha(OUT/'direct_mlb_inputs.csv')}
    for name, digest in expected['sources'].items(): assert sha(ROOT/name)==digest
    path = CACHE/'mlb_multi.parquet'; manifest = CACHE/'mlb_manifest.json'
    if path.exists():
        assert json.loads(manifest.read_text())==expected, '새 실험 입력 캐시가 변경되었습니다'
        return pd.read_parquet(path), expected
    reference = pd.read_csv(inputs, dtype={'pitcher': str}).query('aggregation=="trimmed10"')
    reference = reference.sort_values(['pitcher', 'season']).reset_index(drop=True)
    bio = pd.read_csv(OUT/'direct_mlb_inputs.csv', usecols=['pitcher', 'season', 'height_cm', 'pitch_hand'],
                      dtype={'pitcher': str})
    fields = ['pitcher', 'game_date', 'game_type', 'game_year', 'game_pk', 'at_bat_number', 'pitch_number',
        'pitch_type', 'p_throws', 'release_pos_x', 'release_pos_y', 'release_pos_z',
        'vx0', 'vy0', 'vz0', 'ax', 'ay', 'az']
    parts = []
    for year in range(2020, 2025):
        paths = [ROOT/name for name in expected['sources'] if name.endswith(f'_{year}.parquet') or name.endswith(f'-{year}.parquet')]
        assert len(paths)==2
        raw = pd.concat([pd.read_parquet(p, columns=fields) for p in paths], ignore_index=True)
        assert not raw.duplicated(['game_pk', 'at_bat_number', 'pitch_number']).any()
        assert raw.game_type.eq('R').all() and raw.game_year.eq(year).all()
        raw.pitcher = raw.pitcher.astype(str)
        raw = raw.merge(bio.loc[bio.season.eq(year)], on='pitcher', validate='many_to_one')
        assert raw.p_throws.eq(raw.pitch_hand).all()
        raw['pitcher_id'] = raw.pitcher; raw['pitch_type_code'] = raw.pitch_type
        q = pitch_features(mlb_adapter(raw))
        q.numeric_valid &= q.ay.between(5, 55)&np.hypot(q.ax, q.az+G/FT_M).le(45)
        part = multi_inputs(q).reset_index().rename(columns={'pitcher_id': 'pitcher'})
        part['season'] = year; parts.append(part)
        print('MLB 다구종 입력', year, len(part), flush=True)
    d = pd.concat(parts, ignore_index=True).sort_values(['pitcher', 'season']).reset_index(drop=True)
    assert d[['pitcher', 'season']].equals(reference[['pitcher', 'season']])
    np.testing.assert_allclose(d[MODEL_FEATURES], reference[MODEL_FEATURES], atol=1e-10, rtol=0)
    for c in ['arm_angle', 'outer_fold', 'fixed_training_row', 'selected_single_period_calibration_row',
              'eval2024_independent_train_and_calibration_player']: d[c] = reference[c]
    d.to_parquet(path, index=False); save(manifest, expected)
    return d, expected


def assemble_kbo():
    expected = {'season': 2026, 'canonical_summary_sha256': sha(ROOT/'data/curated/summary.json'),
        'height_sha256': sha(ROOT/'data/tracking/player_heights.csv'),
        'bio_sha256': sha(ROOT/'data/curated/players/player_bio.parquet'),
        'feature_code_sha256': sha(FEATURE_CODE),
        'movement_calibration_code_sha256': sha(ROOT/'src/visualbaseball/eaa_movement_calibration.py')}
    path = CACHE/'kbo_multi.parquet'; manifest = CACHE/'kbo_manifest.json'
    if path.exists():
        assert json.loads(manifest.read_text())==expected
        return pd.read_parquet(path), expected
    fields = ['season', 'game_id', 'pitch_id', 'pitcher_id', 'pitcher_name', 'pitch_type_code', 'stadium',
        'x0', 'y0', 'z0', 'vx0', 'vy0', 'vz0', 'ax', 'ay', 'az', 'px', 'pz', 'sz_top', 'sz_bottom',
        'horizontal_movement_cm', 'vertical_movement_cm']
    rows = [r for r in load_rows(ROOT, 'pitches', 2026, columns=fields) if r.get('pitcher_id')]
    raw = pd.DataFrame(rows); raw.pitcher_id = raw.pitcher_id.astype(str)
    heights = _heights(ROOT)
    bio = pd.read_parquet(ROOT/'data/curated/players/player_bio.parquet', columns=['player_id', 'player_name', 'throws'])
    bio.player_id = bio.player_id.astype(str); bio = bio.set_index('player_id').to_dict('index')
    raw['height_cm'] = pd.to_numeric(raw.pitcher_id.map(lambda p: heights.get(p, {}).get('height_cm')), errors='coerce')
    raw['pitcher_hand'] = raw.pitcher_id.map(lambda p: {'R': 'Right', 'L': 'Left'}.get(bio.get(p, {}).get('throws')))
    identity = raw.pitcher_name.map(_name).eq(raw.pitcher_id.map(lambda p: _name(heights.get(p, {}).get('player_name'))))
    identity &= raw.pitcher_name.map(_name).eq(raw.pitcher_id.map(lambda p: _name(bio.get(p, {}).get('player_name'))))
    numeric = fields[7:]; raw[numeric] = raw[numeric].apply(pd.to_numeric, errors='coerce')
    adjusted = calibrate_eaa(rows, raw.pitch_type_code.fillna('').tolist(), 2026)
    q = pitch_features(raw, adjusted)
    q.numeric_valid &= quality_mask(raw)&identity.to_numpy()
    d = multi_inputs(q)
    old = pd.read_parquet(ROOT/'.cache/arm_angle/conditional_20261006/kbo_2026_context.parquet')
    np.testing.assert_allclose(d[MODEL_FEATURES], old[MODEL_FEATURES], atol=1e-10, rtol=0, equal_nan=True)
    d.to_parquet(path); save(manifest, expected)
    focus = q.loc[q.pitcher_id.isin(FOCUS)&q.numeric_valid]
    focus[['pitcher_id', 'pitch_type_code', 'numeric_valid', 'height_m', 'left_hand', 'z55_over_height',
        'side55_over_height', 'speed55', 'armside_vx_over_minus_vy', 'vz_over_minus_vy', 'flight55_to_plate',
        'movement_axis_arm_sin', 'movement_axis_up_cos', 'movement_size_m']].to_parquet(CACHE/'kbo_focus_pitches.parquet', index=False)
    print('KBO2026 다구종 입력', len(rows), len(d), flush=True)
    return d, expected


def low_masks(d):
    angle, speed = np.floor(d.arm_angle/5), np.floor(d.ff_speed55)
    count = d.groupby([angle, speed]).pitcher.transform('size')
    median = d.ff_ivb_in.groupby([angle, speed]).transform('median')
    matched = d.arm_angle.ge(35)&d.arm_angle.lt(60)&count.ge(4)
    return matched&d.ff_ivb_in.le(median), matched&d.ff_ivb_in.gt(median)


def masks(d):
    low, high = low_masks(d)
    return {'all': pd.Series(True, index=d.index),
        'middle35_60': d.arm_angle.ge(35)&d.arm_angle.lt(60), 'high60': d.arm_angle.ge(60),
        'low20': d.arm_angle.lt(20), 'matched_low_IVB': low, 'matched_high_IVB': high,
        'observed50plus_low_IVB': low&d.arm_angle.ge(50),
        'left_matched_low_IVB': low&d.left_hand.eq(1), 'right_matched_low_IVB': low&d.left_hand.eq(0)}


def summary(d, prediction):
    error = pd.Series(np.asarray(prediction)-d.arm_angle.to_numpy(), index=d.index)
    result = {}
    for name, mask in masks(d).items():
        q, e = d.loc[mask], error.loc[mask]
        result[name] = {'seasons': len(q), 'players': int(q.pitcher.nunique()),
            'MAE': float(e.abs().mean()) if len(q) else None,
            'bias': float(e.mean()) if len(q) else None,
            'player_MAE': float(e.abs().groupby(q.pitcher).mean().mean()) if len(q) else None}
    return result


def choose(d, label):
    predictions = {name: np.full(len(d), np.nan) for name in OPTIONS}
    for fold, (train, val) in enumerate(GroupKFold(3, shuffle=True, random_state=SEED).split(d, groups=d.pitcher)):
        assert set(d.iloc[train].pitcher).isdisjoint(d.iloc[val].pitcher)
        result, _ = predict_all(fit_all(d.iloc[train]), d.iloc[val])
        for name, p in result.items(): predictions[name][val] = p
        print(label, '선택 inner', fold, flush=True)
    scores = {name: summary(d, p) for name, p in predictions.items()}
    baseline = scores['baseline']; eligible = []
    for name, values in scores.items():
        low, base_low = values['matched_low_IVB'], baseline['matched_low_IVB']
        accept = name=='baseline' or (
            abs(low['bias'])<=abs(base_low['bias'])-.30 and low['player_MAE']<=base_low['player_MAE']-.05
            and all(values[group]['player_MAE']<=baseline[group]['player_MAE']+margin
                for group, margin in [('all', .15), ('middle35_60', .05), ('high60', .25), ('low20', .50)]))
        score = low['player_MAE']+abs(low['bias'])+.25*values['all']['player_MAE']
        scores[name] = {'summary': values, 'eligible': bool(accept), 'score': float(score)}
        if accept: eligible.append(name)
    selected = min(eligible, key=lambda n: scores[n]['score'])
    return selected, scores


def evaluate(d):
    table = d[['pitcher', 'season', 'arm_angle', 'outer_fold', 'ff_ivb_in', 'ff_hb_arm_in',
        'ff_speed55', 'left_hand', 'n', 'n_ff']].copy()
    for name in OPTIONS: table[name] = np.nan
    table['nested_selected'] = np.nan
    choices = []
    for fold in sorted(d.outer_fold.unique()):
        train, val = d.outer_fold.ne(fold), d.outer_fold.eq(fold)
        assert set(d.loc[train, 'pitcher']).isdisjoint(d.loc[val, 'pitcher'])
        selected, scores = choose(d.loc[train].reset_index(drop=True), f'outer{fold}')
        result, details = predict_all(fit_all(d.loc[train]), d.loc[val])
        for name, p in result.items(): table.loc[val, name] = p
        table.loc[val, 'nested_selected'] = result[selected]
        table.loc[val, 'IVB_deficit_in'] = details['IVB_deficit_in']
        table.loc[val, 'gate'] = details['gate']
        table.loc[val, 'nonFF_experts'] = details['nonFF_experts']
        choices.append({'fold': int(fold), 'selected': selected, 'training_selection': scores})
        print('outer 확정', fold, selected, flush=True)
    train = d.loc[d.fixed_training_row]
    cal = d.loc[d.selected_single_period_calibration_row]
    test = d.loc[d.eval2024_independent_train_and_calibration_player]
    assert set(train.pitcher).isdisjoint(set(cal.pitcher)|set(test.pitcher)) and set(cal.pitcher).isdisjoint(test.pitcher)
    selected, scores = choose(train.reset_index(drop=True), '고정 학습')
    fixed = fit_all(train)
    test_pred, _ = predict_all(fixed, test)
    cal_pred, _ = predict_all(fixed, cal)
    frozen = json.loads((ROOT/'data/models/estimated_arm_angle_v3.json').read_text())
    check, _ = predict_all(fixed, d)
    np.testing.assert_allclose(check['baseline'], [_predict(frozen['angle'], x) for x in d[MODEL_FEATURES].to_numpy(float)], atol=1e-8, rtol=0)
    fixed_report = {name: summary(test, p) for name, p in test_pred.items()}
    oof_report = {name: summary(d, table[name]) for name in OPTIONS+('nested_selected',)}
    player_gains = {name: gain(d, table.baseline.to_numpy(), table.nested_selected.to_numpy(), mask.to_numpy())
                   for name, mask in masks(d).items() if name in ['all', 'middle35_60', 'high60', 'matched_low_IVB']}
    low, base_low = oof_report['nested_selected']['matched_low_IVB'], oof_report['baseline']['matched_low_IVB']
    fixed_low, fixed_base_low = fixed_report[selected]['matched_low_IVB'], fixed_report['baseline']['matched_low_IVB']
    checks = {'nonbaseline_selected': selected!='baseline',
        'nested_lowIVB_bias_improves_0p30': abs(low['bias'])<=abs(base_low['bias'])-.30,
        'nested_lowIVB_player_MAE_gain_CI_lower_gt0': player_gains['matched_low_IVB']['bootstrap95'][0]>0,
        'nested_all_noninferiority': player_gains['all']['bootstrap95'][0]>=-.10,
        'nested_high_noninferiority': player_gains['high60']['bootstrap95'][0]>=-.25,
        'fixed2024_lowIVB_MAE_improves': fixed_low['player_MAE']<fixed_base_low['player_MAE'],
        'fixed2024_lowIVB_bias_improves': abs(fixed_low['bias'])<abs(fixed_base_low['bias']),
        'fixed2024_all_margin': fixed_report[selected]['all']['MAE']<=fixed_report['baseline']['all']['MAE']+.15,
        'fixed2024_high_margin': fixed_report[selected]['high60']['MAE']<=fixed_report['baseline']['high60']['MAE']+.25}
    intervals = {}
    for name in ['baseline', selected]:
        residual = cal.arm_angle.to_numpy()-cal_pred[name]
        ordered = np.sort(residual)
        lower_rank = max(1, int(np.floor((len(cal)+1)*.05)))
        upper_rank = min(len(cal), int(np.ceil((len(cal)+1)*.95)))
        low_q, high_q = ordered[lower_rank-1], ordered[upper_rank-1]
        error = test.arm_angle.to_numpy()-test_pred[name]
        groups = {}
        for group, mask in masks(test).items():
            observed = mask.to_numpy()
            groups[group] = {'seasons': int(observed.sum()),
                'covered': int(((error>=low_q)&(error<=high_q)&observed).sum()),
                'coverage': float(((error>=low_q)&(error<=high_q))[observed].mean()) if observed.any() else None}
        intervals[name] = {'lower_residual_deg': float(low_q), 'upper_residual_deg': float(high_q),
            'width_deg': float(high_q-low_q), 'fixed2024': groups, 'KBO_interval_coverage_validated': False}
    test_table = test[['pitcher', 'season', 'arm_angle', 'ff_ivb_in', 'ff_speed55', 'left_hand', 'n', 'n_ff']].copy()
    for name, p in test_pred.items(): test_table[name] = p
    report = {'scope': 'KBO2026만; 기존 MLB2020–2024 저장 자료, 이미지 모델 없음',
        'MLB_seasons': len(d), 'MLB_players': int(d.pitcher.nunique()),
        'fixed_training_seasons': len(train), 'fixed_training_players': int(train.pitcher.nunique()),
        'calibration_players': len(cal), 'independent2024_players': len(test),
        'options_predeclared': list(OPTIONS), 'selected_train_only': selected, 'inner_selection': scores,
        'outer_choices': choices, 'OOF': oof_report, 'independent2024': fixed_report,
        'paired_player_gains': player_gains, 'promotion_checks': checks,
        'promotion_eligible_MLB': bool(all(checks.values())), 'intervals': intervals,
        'KBO_or_WBC_labels_used_for_training_or_selection': False,
        'WBC_labels_loaded_after_fixed_selection': False, 'production_changed': False,
        'sha256': {'script': sha(Path(__file__)), 'features': sha(FEATURE_CODE), 'models': sha(MODEL_CODE),
            'predeclared_plan': sha(Path(__file__).with_name('eaa-2026-low-ivb-plan.md')),
            'frozen_v3': sha(ROOT/'data/models/estimated_arm_angle_v3.json')}}
    table.to_csv(OUT/(PREFIX+'_mlb_predictions.csv'), index=False)
    test_table.to_csv(OUT/(PREFIX+'_independent2024_predictions.csv'), index=False)
    save(OUT/(PREFIX+'_model_report.json'), report)
    with (CACHE/'fixed_models.pkl').open('wb') as stream: pickle.dump(fixed, stream)
    return fixed, selected, report


def kbo_cases(d, models, selected):
    valid = d.n.ge(100)&d.n_ff.ge(100)&np.isfinite(d[MODEL_FEATURES]).all(axis=1)
    q = d.loc[valid].copy(); q['pitcher'] = q.index.astype(str)
    predictions, details = predict_all(models, q)
    table = pd.DataFrame({'pitcher_id': q.index, 'n': q.n, 'n_ff': q.n_ff,
        'ff_ivb_in_common_frame': q.ff_ivb_in, 'IVB_deficit_in': details['IVB_deficit_in'],
        'gate': details['gate'], 'nonFF_experts': details['nonFF_experts']})
    for name, p in predictions.items(): table[name] = p
    table['selected'] = selected; table['selected_angle_deg'] = predictions[selected]
    table['delta_deg'] = predictions[selected]-predictions['baseline']
    table['KBO_true_accuracy_validated'] = False
    table.to_csv(OUT/(PREFIX+'_KBO2026_predictions.csv'), index=False)
    focused = table.loc[table.pitcher_id.isin(FOCUS)].copy()
    focused['name'] = focused.pitcher_id.map(FOCUS)
    focused.to_csv(OUT/(PREFIX+'_KBO2026_focus.csv'), index=False)
    save(OUT/(PREFIX+'_KBO2026_focus.json'), {'selected_MLB_training_only': selected,
        'cases': focused.to_dict('records'), 'production_changed': False})
    return table


def continuity(models, selected):
    pitches = pd.read_parquet(CACHE/'kbo_focus_pitches.parquet')
    rows = []
    for pid, name in FOCUS.items():
        original = pitches.loc[pitches.pitcher_id.eq(pid)].copy()
        if not len(original): continue
        ff = original.pitch_type_code.eq('FF')
        for delta in np.linspace(-4, 4, 33):
            q = original.copy()
            hb = original.loc[ff, 'movement_size_m']*original.loc[ff, 'movement_axis_arm_sin']
            ivb = original.loc[ff, 'movement_size_m']*original.loc[ff, 'movement_axis_up_cos']+delta*.0254
            size = np.hypot(hb, ivb)
            q.loc[ff, 'movement_size_m'] = size
            q.loc[ff, 'movement_axis_arm_sin'] = hb/size
            q.loc[ff, 'movement_axis_up_cos'] = ivb/size
            frame = multi_inputs(q); frame['pitcher'] = pid
            pred, details = predict_all(models, frame)
            rows.append({'pitcher_id': pid, 'name': name, 'FF_IVB_scenario_delta_in': float(delta),
                'baseline': float(pred['baseline'][0]), 'selected': float(pred[selected][0]),
                'gate': float(details['gate'][0]), 'is_observed_angle_or_Y2Y': False})
    result = pd.DataFrame(rows)
    result.to_csv(OUT/(PREFIX+'_IVB_continuity.csv'), index=False)
    maxima = result.groupby('pitcher_id').apply(lambda q: float(np.abs(np.diff(q.selected)).max()), include_groups=False).to_dict()
    return {'scenario': '포심만 투구별50ft IVB±4인치,0.25인치 간격; 다른 입력 고정',
        'largest_selected_step_deg_by_player': maxima, 'physical_arm_angle_change_verified': False}


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--assemble-only', action='store_true')
    parser.add_argument('--finish-only', action='store_true'); args = parser.parse_args()
    CACHE.mkdir(parents=True, exist_ok=True)
    d, mlb_manifest = assemble_mlb(); kbo, kbo_manifest = assemble_kbo()
    if args.assemble_only: return
    if args.finish_only:
        report = json.loads((OUT/(PREFIX+'_model_report.json')).read_text())
        assert report['sha256']['features']==sha(FEATURE_CODE) and report['sha256']['models']==sha(MODEL_CODE)
        with (CACHE/'fixed_models.pkl').open('rb') as stream: models = pickle.load(stream)
        selected = report['selected_train_only']
    else: models, selected, report = evaluate(d)
    kbo_cases(kbo, models, selected)
    report['continuity_audit'] = continuity(models, selected)
    report['MLB_inputs'] = mlb_manifest; report['KBO_inputs'] = kbo_manifest
    save(OUT/(PREFIX+'_model_report.json'), report)
    print('최종 선택', selected, 'MLB 승격', report['promotion_eligible_MLB'], flush=True)
    print(json.dumps({n: {'all_MAE': r['all']['MAE'], 'lowIVB_bias': r['matched_low_IVB']['bias'],
        'lowIVB_MAE': r['matched_low_IVB']['MAE']} for n, r in report['OOF'].items()}, ensure_ascii=False), flush=True)


if __name__ == '__main__': main()
