# eAA nonimage review context, 2026-10-05

Start with analysis/arm_angle/nonimage-expansion-study-20261005.md.
This is a new snapshot; it does not replace the older 20261003 context.
The JSON/CSV files include selected data, whole-player folds, predictions, source hashes and conditional KBO scenarios.
Original public arm/spin/height responses and research model states are included.
No large raw pitch extracts, canonical KBO partitions or raw TrackMan matching caches are included.
You can independently recalculate metrics, coordinate identities and support checks from the included data.
Full assemble/ODE/transfer reruns require the repository and the source caches described in the report.
The models in .cache/arm_angle/expanded are research states; production eAA-v1 is unchanged.
This packet has not been pushed to GitHub or sent to an external service.
