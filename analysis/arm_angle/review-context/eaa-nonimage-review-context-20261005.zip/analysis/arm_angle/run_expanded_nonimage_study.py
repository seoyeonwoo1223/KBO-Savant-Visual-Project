"""Expanded source-backed MLB eAA experiment; never writes production data.

Stages retain official responses and hashes, enforce observed pitch counts, and
hold whole players out. Optical spin and movement proxies are separate families.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys

import numpy as np
import pandas as pd
import requests
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/arm_angle/results'
CACHE = ROOT / '.cache/arm_angle/expanded'
sys.path.insert(0, str(ROOT / 'scripts'))
from collect_mlb_arm_candidates import collect_interval, DATES
from run_joint_movement_extension_check import cached_ff_movement
from visualbaseball.arm_angle_calibration import features, metrics
from visualbaseball.arm_angle_candidates import prepare_pitches, aggregate_seasons, ALL_FEATURES

FAMILIES = ['geometry', 'movement_speed', 'movement_rpm_extension',
            'movement_rpm_extension_posture_proxies', 'movement_axis_active_proxy',
            'optical_spin', 'optical_spin_movement_extension']
POSTURE_FAMILIES = ['posture_movement_speed', 'posture_movement_rpm_extension',
                    'posture_optical_spin', 'posture_optical_spin_movement_extension']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def fetch(url, path):
    if path.exists():
        return path.read_bytes()
    r = requests.get(url, timeout=50)
    r.raise_for_status()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(r.content)
    return r.content


def collect_reference():
    CACHE.mkdir(parents=True, exist_ok=True)
    def arm(year):
        url = f'https://baseballsavant.mlb.com/leaderboard/pitcher-arm-angles?season={year}&min=1'
        path = CACHE / f'source_cache/arm-{year}-min1.html'
        content = fetch(url, path); text = content.decode()
        params = json.loads(re.search(r'const serverParams\s*=\s*(\{.*?\});', text)[1])
        if params['season'] != str(year) or params['min'] != '1' or params['validGameTypes'] != ['R']:
            raise ValueError('Arm reference filter mismatch')
        data = pd.DataFrame(json.loads(re.search(r'const rawData\s*=\s*(\[.*?\]);', text, re.S)[1]))
        raw_rows = len(data)
        data = data.loc[data.n_pitches.ge(100)].copy()
        # A switch-pitcher can have separate hand rows. Do not merge opposing
        # hands; fail if such a player survives the observed-count threshold.
        if data.pitcher.duplicated().any():
            raise ValueError('Duplicate eligible pitcher/hand source observations')
        data['season'] = year
        data['pitcher'] = data.pitcher.astype(str)
        data['reference_source_url'] = url; data['reference_source_sha256'] = sha(path)
        print('arm reference', year, 'raw', raw_rows, 'observed>=100', len(data), flush=True)
        return data, {'season': year, 'url': url, 'sha256': sha(path),
                      'raw_rows': raw_rows, 'observed_pitch_100_rows': len(data)}
    with ThreadPoolExecutor(max_workers=3) as pool:
        collected = list(pool.map(arm, range(2020, 2025)))
    data = pd.concat([x[0] for x in collected], ignore_index=True)
    # The numeric minimum response is NOT a superset of the retained qualified
    # response. Union verified official rows; never silently lose the original
    # high-volume pitchers while trying to expand the population.
    previous_path = OUT / 'mlb_reference.csv'
    previous = pd.read_csv(previous_path, dtype={'pitcher': str})
    for year in range(2020, 2025):
        path = ROOT / f'.cache/arm_angle/source_cache/mlb/savant-{year}.html.gz'
        content = gzip.decompress(path.read_bytes())
        expected = hashlib.sha256(content).hexdigest()
        if not previous.loc[previous.season.eq(year), 'reference_source_sha256'].eq(expected).all():
            raise ValueError('Prior qualified source hash mismatch')
    shared = previous.merge(data, on=['season', 'pitcher'], suffixes=('_q', '_min'))
    if not np.allclose(shared.arm_angle_q, shared.arm_angle_min, atol=1e-8):
        raise ValueError('Conflicting official labels between source scopes')
    data = pd.concat([previous[data.columns], data], ignore_index=True).drop_duplicates(['season', 'pitcher'])
    heights_path = OUT / 'mlb_heights.csv'
    heights = pd.read_csv(heights_path, dtype={'pitcher': str})
    missing = sorted(set(data.pitcher) - set(heights.pitcher))
    batches = [missing[i:i+50] for i in range(0, len(missing), 50)]
    def people(ids):
        url = 'https://statsapi.mlb.com/api/v1/people?personIds=' + ','.join(ids)
        path = CACHE / ('source_cache/people-' + hashlib.sha256(url.encode()).hexdigest()[:16] + '.json')
        content = fetch(url, path); raw = json.loads(content)['people']
        if {str(x['id']) for x in raw} != set(ids):
            raise ValueError('Official height identity mismatch')
        out = []
        for person in raw:
            match = re.fullmatch(r"(\d+)'\s*(\d+)\"", person.get('height', ''))
            if not match:
                continue
            height = (int(match[1])*12 + int(match[2]))*2.54
            if not 140 <= height <= 220:
                raise ValueError('Implausible official height')
            out.append({'pitcher': str(person['id']), 'height_cm': height,
                        'height_source_url': url, 'height_source_sha256': sha(path)})
        return out
    with ThreadPoolExecutor(max_workers=3) as pool:
        extra = [r for rows in pool.map(people, batches) for r in rows]
    heights = pd.concat([heights, pd.DataFrame(extra)], ignore_index=True)
    if heights.pitcher.duplicated().any():
        raise ValueError('Duplicate official heights')
    data = data.merge(heights, on='pitcher', how='left', validate='many_to_one')
    data['rel_height'] = data.release_ball_z*.3048
    data['rel_side'] = -data.release_ball_x*.3048
    data['pitcher_hand'] = data.pitch_hand.map({'R': 'Right', 'L': 'Left'})
    h = data.height_cm/100
    mirror = data.pitch_hand.map({'R': -1., 'L': 1.})
    data['oracle_com_over_height'] = mirror*(data.release_ball_x-data.relative_release_ball_x)*.3048/h
    data['oracle_shoulder_z_over_height'] = data.shoulder_z*.3048/h
    data['oracle_relative_shoulder_x_over_height'] = mirror*data.relative_shoulder_x*.3048/h
    frontal = np.degrees(np.arctan2(data.release_ball_z-data.shoulder_z,
                                   abs(data.relative_release_ball_x-data.relative_shoulder_x)))
    data['angle_of_mean_points_deg'] = frontal
    spin_path = OUT / 'ode_mlb_spin_reference.csv'
    spin = pd.read_csv(spin_path, dtype={'player_id': str}).rename(columns={'player_id': 'pitcher',
          'n_pitches': 'n_ff_spin', 'pitch_hand': 'spin_hand', 'source_url': 'spin_source_url',
          'source_sha256': 'spin_source_sha256'})
    for year in range(2020, 2025):
        path = ROOT / f'.cache/arm_angle/ode/source_cache/spin-direction-pitches-{year}.html'
        if not spin.loc[spin.season.eq(year), 'spin_source_sha256'].eq(sha(path)).all():
            raise ValueError('Retained spin source changed')
    data = data.merge(spin, on=['season', 'pitcher'], how='left', validate='one_to_one')
    if not data.loc[data.spin_hand.notna(), 'pitch_hand'].eq(data.loc[data.spin_hand.notna(), 'spin_hand']).all():
        raise ValueError('Spin hand mismatch')
    data['ff_speed_m_s'] = data.release_speed*.44704
    valid = (data.height_cm.between(140, 220) & data.arm_angle.between(-90, 90)
             & data.rel_height.between(.05, 2.7) & data.rel_side.between(-2, 2) & data.pitcher_hand.notna())
    data = data.loc[valid].reset_index(drop=True)
    data.to_csv(OUT / 'expanded_mlb_reference.csv', index=False)
    report = {'sources': [x[1] for x in collected], 'rows': len(data),
              'pitchers': int(data.pitcher.nunique()), 'new_heights': len(extra),
              'missing_height_ids': sorted(set(missing) - {x['pitcher'] for x in extra}),
              'local_count_filter': 'Verified union of qualified and min1 official responses; >=100 observed pitches',
              'filter_note': 'Numeric min100 was not inclusive; use min1 and enforce actual counts locally',
              'matching_rows_between_sources': len(shared),
              'height_note': 'Current official MLB heights; no inference from an image',
              'season_counts': data.groupby('season').size().to_dict(),
              'angle_max_deg': float(data.arm_angle.max()),
              'high60_rows': int(data.arm_angle.ge(60).sum()),
              'high75_rows': int(data.arm_angle.ge(75).sum()),
              'angle_of_mean_points_abs_gap_p95': float(abs(data.angle_of_mean_points_deg-data.arm_angle).quantile(.95)),
              'input_sha256': {str(p.relative_to(ROOT)): sha(p) for p in [heights_path, spin_path, previous_path]}}
    save_json(OUT / 'expanded_mlb_sources.json', report)
    print(json.dumps(report, ensure_ascii=False), flush=True)


def collect_details():
    ref = pd.read_csv(OUT / 'expanded_mlb_reference.csv', dtype={'pitcher': str})
    old = pd.read_csv(OUT / 'candidate_mlb_season_inputs.csv', dtype={'pitcher': str})
    optical = np.isfinite(ref[['hawkeye_measured', 'active_spin', 'spin_rate', 'ff_speed_m_s',
                               'movement_inferred', 'alan_active_spin_pct']]).all(axis=1)
    eligible = ref.loc[optical & ref.n_ff_spin.ge(100) & ref.active_spin.between(0, 1)
                       & ref.alan_active_spin_pct.between(0, 1)]
    cache = CACHE / 'statcast/source_cache'; cache.mkdir(parents=True, exist_ok=True)
    all_metadata = {}
    for year in range(2020, 2025):
        ids = sorted(set(eligible.loc[eligible.season.eq(year), 'pitcher'])
                     - set(old.loc[old.season.eq(year), 'pitcher']))
        if not ids:
            continue
        start, finish = map(date.fromisoformat, DATES[year]); windows = []
        while start <= finish:
            end = min(start+timedelta(days=27), finish); windows.append((start, end))
            start = end+timedelta(days=1)
        def one(window):
            return collect_interval(year, *window, ids, cache)
        frames = []; requests_meta = []
        with ThreadPoolExecutor(max_workers=3) as pool:
            for i, (frame, meta) in enumerate(pool.map(one, windows), 1):
                frames.append(frame); requests_meta += meta
                print('new MLB details', year, 'IDs', len(ids), i, '/', len(windows), flush=True)
        frame = pd.concat(frames, ignore_index=True)
        if frame.duplicated(['game_pk', 'at_bat_number', 'pitch_number']).any():
            raise ValueError('Expanded details duplicate pitch')
        frame.to_parquet(CACHE / f'statcast/details-{year}.parquet', index=False)
        all_metadata[str(year)] = {'new_requested_ids': ids, 'rows': len(frame), 'source_requests': requests_meta}
        save_json(OUT / 'expanded_statcast_source_manifest.json', all_metadata)
    print('expanded details complete', flush=True)


def assemble():
    ref = pd.read_csv(OUT / 'expanded_mlb_reference.csv', dtype={'pitcher': str})
    extension = pd.read_csv(OUT / 'candidate_mlb_season_inputs.csv', dtype={'pitcher': str})
    old_manifest = json.loads((OUT / 'candidate_statcast_source_manifest.json').read_text())
    movement, movement_meta = cached_ff_movement(old_manifest)
    parts = []
    manifest = json.loads((OUT / 'expanded_statcast_source_manifest.json').read_text())
    for year, info in manifest.items():
        y = int(year)
        for meta in info['source_requests']:
            if meta['capped']:
                continue
            tag = hashlib.sha256(meta['url'].encode()).hexdigest()[:16]
            path = CACHE / f"statcast/source_cache/{y}-{meta['date_start']}-{meta['date_end']}-{tag}.csv.gz"
            content = gzip.decompress(path.read_bytes())
            if hashlib.sha256(content).hexdigest() != meta['source_sha256']:
                raise ValueError('Expanded response hash mismatch')
            cols = ['pitcher', 'game_year', 'game_type', 'game_date', 'game_pk', 'at_bat_number',
                    'pitch_number', 'pitch_type', 'pfx_z', 'pfx_x', 'release_extension', 'release_spin_rate']
            d = pd.read_csv(io.BytesIO(content), usecols=cols, dtype={'pitcher': str})
            if len(d) != meta['rows'] or not d.game_year.eq(y).all() or not d.game_type.eq('R').all():
                raise ValueError('Expanded response scope mismatch')
            d['season'] = y; parts.append(d)
    new = pd.concat(parts, ignore_index=True)
    if new.duplicated(['season', 'game_pk', 'at_bat_number', 'pitch_number']).any():
        raise ValueError('Expanded source pitch overlap')
    # Recompute both old and new extension/launch/spread from the same valid
    # per-pitch transformation. This avoids source-population-specific features.
    candidate_parts = []; label_checks = []
    for year in range(2020, 2025):
        old_path = ROOT / f'.cache/arm_angle/candidates/statcast_candidates_{year}.parquet'
        if sha(old_path) != old_manifest[str(year)]['parquet_sha256']:
            raise ValueError('Retained official details parquet hash changed')
        raw = pd.read_parquet(old_path)
        new_path = CACHE / f'statcast/details-{year}.parquet'
        if new_path.exists():
            raw = pd.concat([raw, pd.read_parquet(new_path)], ignore_index=True)
        raw.pitcher = raw.pitcher.astype(str)
        if raw.duplicated(['game_pk', 'at_bat_number', 'pitch_number']).any():
            raise ValueError('Qualified/expanded pitch overlap')
        raw['season'] = year
        raw = raw.merge(ref[['season', 'pitcher', 'height_cm']], on=['season', 'pitcher'], validate='many_to_one')
        raw['pitcher_hand'] = raw.p_throws.map({'R': 'Right', 'L': 'Left'})
        raw['rel_side'] = -raw.release_pos_x*.3048; raw['rel_height'] = raw.release_pos_z*.3048
        raw['extension'] = raw.release_extension*.3048
        raw['reference_y_m'] = 50*.3048; raw['release_y_m'] = raw.release_pos_y*.3048
        for old_name, new_name in [('vx0', 'vx_m_s'), ('vy0', 'vy_m_s'), ('vz0', 'vz_m_s'),
                                   ('ax', 'ax_m_s2'), ('ay', 'ay_m_s2'), ('az', 'az_m_s2')]:
            raw[new_name] = raw[old_name]*.3048
        prepared = prepare_pitches(raw)
        grouped = aggregate_seasons(prepared)
        candidate_parts.append(grouped[['season', 'pitcher', 'extension_over_height'] +
                                       [x for x in ALL_FEATURES if x != 'extension_over_height']])
        labelled = raw.groupby(['season', 'pitcher']).agg(statcast_arm_angle=('arm_angle','mean'),
                        statcast_arm_n=('arm_angle','count'), statcast_rows=('pitcher','size')).reset_index()
        label_checks.append(labelled)
    all_ext = pd.concat(candidate_parts, ignore_index=True)
    if all_ext.duplicated(['season', 'pitcher']).any():
        raise ValueError('Expanded and qualified pitcher sets overlap')
    ff = new.loc[new.pitch_type.eq('FF') & np.isfinite(new[['pfx_z', 'pfx_x']]).all(axis=1)]
    nm = ff.groupby(['season', 'pitcher']).agg(ff_ivb_ft=('pfx_z', 'mean'),
        ff_hb_ft=('pfx_x', 'mean'), n_ff_movement=('pitcher', 'size')).reset_index()
    nm['ff_ivb_m'] = nm.ff_ivb_ft*.3048; nm['ff_hb_m'] = nm.ff_hb_ft*.3048
    movement = pd.concat([movement, nm], ignore_index=True)
    ref = ref.merge(all_ext, on=['season', 'pitcher'], how='left', validate='one_to_one')
    ref = ref.merge(movement, on=['season', 'pitcher'], how='left', validate='one_to_one')
    needed = ['hawkeye_measured', 'active_spin', 'spin_rate', 'ff_speed_m_s', 'movement_inferred',
              'alan_active_spin_pct', 'extension_over_height', 'ff_ivb_m', 'ff_hb_m'] + ALL_FEATURES
    keep = np.isfinite(ref[needed]).all(axis=1) & ref.n_ff_spin.ge(100) & ref.n_ff_movement.ge(100)
    keep &= ref.active_spin.between(0, 1) & ref.alan_active_spin_pct.between(0, 1)
    d = ref.loc[keep].sort_values(['pitcher', 'season']).reset_index(drop=True)
    label_check = pd.concat(label_checks, ignore_index=True)
    d = d.merge(label_check, on=['season', 'pitcher'], validate='one_to_one')
    discrepancy = abs(d.arm_angle-d.statcast_arm_angle)
    if not discrepancy.le(.5).all():
        raise ValueError('Official arm labels disagree with same-season MLB details; investigate source scope')
    old_ids = set(pd.read_csv(OUT / 'joint_movement_extension_mlb_validation.csv', dtype={'pitcher': str}).pitcher)
    d['new_to_previous_joint_player'] = ~d.pitcher.isin(old_ids)
    d.to_csv(OUT / 'expanded_mlb_model_inputs.csv', index=False)
    save_json(OUT / 'expanded_mlb_assembly.json', {'rows': len(d), 'pitchers': int(d.pitcher.nunique()),
        'new_detail_pitches': len(new), 'new_FF_movement_pitches': len(ff),
        'old_movement_source': movement_meta, 'excluded_reference_rows': int((~keep).sum()),
        'extension_note': 'Same transformation for old/new: all valid per-pitch release plane extension, launch/spread/mix',
        'official_label_vs_statcast_mean_max_abs_gap_deg': float(discrepancy.max()),
        'movement_note': 'Official Statcast pfx_z/pfx_x FF regular-season means; not proven equivalent to TM/VB',
        'input_sha256': {str(p.relative_to(ROOT)): sha(p) for p in [OUT/'expanded_mlb_reference.csv',
             OUT/'expanded_statcast_source_manifest.json', OUT/'candidate_statcast_source_manifest.json']}})
    print('expanded model cohort', len(d), 'players', d.pitcher.nunique(), flush=True)


def x_for(d, family):
    family = family.removeprefix('posture_')
    x = features(d)
    hand = d.pitcher_hand.map({'Right': 1., 'Left': -1.}).to_numpy(float)
    if family == 'geometry':
        return x
    if family == 'movement_speed' or family.startswith('movement_rpm_extension'):
        movement = np.column_stack([d.ff_speed_m_s/40, d.ff_ivb_m, -hand*d.ff_hb_m])
    if family == 'movement_speed':
        return np.column_stack([x, movement])
    if family.startswith('movement_rpm_extension'):
        x = np.column_stack([x, movement, d.spin_rate/2000, d.extension_over_height])
        if family.endswith('posture_proxies'):
            x = np.column_stack([x, d[[v for v in ALL_FEATURES if v != 'extension_over_height']]])
        return x
    optical = family.startswith('optical_spin')
    axis = d.hawkeye_measured if optical else d.movement_inferred
    active = d.active_spin if optical else d.alan_active_spin_pct
    angle = np.radians(axis)
    extra = np.column_stack([hand*np.sin(angle), -np.cos(angle), d.spin_rate/2000, d.ff_speed_m_s/40, active])
    x = np.column_stack([x, extra])
    if family == 'optical_spin_movement_extension':
        x = np.column_stack([x, d.ff_ivb_m, -hand*d.ff_hb_m, d.extension_over_height])
    return x


def estimator():
    return make_pipeline(PolynomialFeatures(2, include_bias=False), StandardScaler(), Ridge(alpha=10.))


def posture_targets(d):
    return np.column_stack([d.oracle_shoulder_z_over_height,
        d.oracle_com_over_height+d.oracle_relative_shoulder_x_over_height])


def posture_angle(d, prediction):
    # Predicting unobserved posture is a constrained surrogate, not a new
    # observation. No real shoulder value enters the query or held-out inputs.
    geom = features(d)
    return np.degrees(np.arctan2(geom[:,1]-prediction[:,0], abs(geom[:,2]-prediction[:,1])))


def summarize(d, prediction):
    result = {'overall': metrics(d.arm_angle, prediction)}
    for name, mask in [('observed_60plus', d.arm_angle.ge(60)), ('observed_50to60', d.arm_angle.between(50, 60, inclusive='left')),
                       ('observed_below20', d.arm_angle.lt(20)), ('predicted_55plus', prediction >= 55),
                       ('new_players', d.new_to_previous_joint_player)]:
        mask = np.asarray(mask)
        result[name] = {**metrics(d.arm_angle.to_numpy()[mask], prediction[mask]),
                        'pitchers': int(d.loc[mask, 'pitcher'].nunique())} if mask.any() else {'n': 0}
    return result


def compare():
    d = pd.read_csv(OUT/'expanded_mlb_model_inputs.csv', dtype={'pitcher': str})
    y = d.arm_angle.to_numpy(float)
    # Hash allocation uses player identity only, independent of observed angles.
    buckets = d.pitcher.map(lambda p: int(hashlib.sha256(('eaa-expanded-v1:'+p).encode()).hexdigest()[:8], 16)%10)
    d['split'] = np.where(buckets.lt(6), 'train', np.where(buckets.lt(8), 'calibration', 'test'))
    train = d.split.eq('train').to_numpy(); cal = d.split.eq('calibration').to_numpy(); test = d.split.eq('test').to_numpy()
    folds = list(GroupKFold(5, shuffle=True, random_state=42).split(d, y, d.pitcher))
    reports = {}; state = {}; baseline = {}
    from visualbaseball.vb_arm_angle import model_state
    for family in FAMILIES + POSTURE_FAMILIES:
        x = x_for(d, family); pred = np.full(len(d), np.nan)
        is_pose = family.startswith('posture_')
        target = posture_targets(d) if is_pose else y
        for fold, (a, b) in enumerate(folds):
            if set(d.pitcher.iloc[a]) & set(d.pitcher.iloc[b]):
                raise ValueError('Whole-player CV leakage')
            value = estimator().fit(x[a], target[a]).predict(x[b])
            pred[b] = posture_angle(d.iloc[b], value) if is_pose else value
            d.loc[b, 'fold'] = fold
        model = estimator().fit(x[train], target[train]); value = model.predict(x)
        fixed = posture_angle(d, value) if is_pose else value
        d['oof_'+family] = pred; d['fixed_'+family] = fixed
        # One calibration score per player: maximum over that player's seasons.
        # This is conservatively simultaneous across observed player seasons.
        scores = pd.Series(abs(fixed[cal]-y[cal]), index=d.loc[cal, 'pitcher']).groupby(level=0).max().to_numpy()
        n = len(scores); rank = int(np.ceil((n+1)*.90))
        if rank > n:
            raise ValueError('Insufficient independent calibration players')
        radius = float(np.sort(scores)[rank-1])
        covered = abs(fixed[test]-y[test]) <= radius
        group_cover = pd.Series(covered, index=d.loc[test, 'pitcher']).groupby(level=0).all()
        reports[family] = {'whole_player_OOF': summarize(d, pred),
            'fixed_test': summarize(d.loc[test].reset_index(drop=True), fixed[test]),
            'calibration_player_count': n, 'MLB_player_simultaneous_90pct_radius_deg': radius,
            'fixed_test_player_all_seasons_coverage': float(group_cover.mean()),
            'fixed_test_row_coverage': float(covered.mean()), 'input_feature_count': x.shape[1]}
        state[family] = {'model': model_state(model), 'feature_min': x[train].min(axis=0).tolist(),
                         'feature_max': x[train].max(axis=0).tolist(), 'radius_MLB_only_deg': radius,
                         'prediction_kind': 'predicted_shoulder_z_and_absolute_x_then_atan2' if is_pose else 'direct_angle'}
        print('expanded compare', family, 'OOF MAE', reports[family]['whole_player_OOF']['overall']['mae_deg'], flush=True)
    # Isolate sample expansion using identical evaluation players/folds. Only
    # formerly qualified rows are used for the restricted-training comparator.
    old = pd.read_csv(OUT/'joint_movement_extension_mlb_validation.csv', dtype={'pitcher': str})
    old_keys = set(zip(old.pitcher, old.season)); qualified = np.array([(p,s) in old_keys for p,s in zip(d.pitcher,d.season)])
    for family in ['geometry', 'optical_spin', 'optical_spin_movement_extension']:
        x = x_for(d, family); pred = np.full(len(d), np.nan)
        for a, b in folds:
            a = a[qualified[a]]
            pred[b] = estimator().fit(x[a], y[a]).predict(x[b])
        d['qualified_train_oof_'+family] = pred
        baseline[family] = summarize(d, pred)
    optical = d.hawkeye_measured.between(165, 195) & d.active_spin.ge(.985)
    # FF eligibility excludes e.g. extreme-slot splitter/cutter pitchers. Keep
    # the broader geometry-only population visible instead of disguising this
    # selection as an exhaustive MLB sample.
    reference = pd.read_csv(OUT/'expanded_mlb_reference.csv', dtype={'pitcher': str})
    rx = features(reference); ry = reference.arm_angle.to_numpy(float); rp = np.full(len(reference),np.nan)
    for a,b in GroupKFold(5,shuffle=True,random_state=42).split(reference,ry,reference.pitcher):
        rp[b] = estimator().fit(rx[a],ry[a]).predict(rx[b])
    reference['geometry_oof_deg'] = rp
    reference.to_csv(OUT/'expanded_geometry_all_reference_validation.csv',index=False)
    all_geometry = {'rows':len(reference),'players':int(reference.pitcher.nunique()),
        'all':metrics(ry,rp),'observed60plus':metrics(ry[ry>=60],rp[ry>=60]),
        'high75_rows':int((ry>=75).sum()),'not_same_cohort_as_feature_comparison':True}
    report = {'model_spec': 'Predeclared degree2/scaled Ridge10; no tuning on user-reported KBO angles',
        'rows': len(d), 'players': int(d.pitcher.nunique()), 'splits': d.groupby('split').agg(rows=('pitcher','size'),
          players=('pitcher','nunique'), high60=('arm_angle', lambda s: int(s.ge(60).sum()))).to_dict('index'),
        'max_observed_angle_deg': float(y.max()), 'high75_rows': int((y>=75).sum()),
        'right_12_clock_high_efficiency_rows': int((optical & d.pitch_hand.eq('R')).sum()),
        'right_12_clock_high_efficiency_players': int(d.loc[optical & d.pitch_hand.eq('R'), 'pitcher'].nunique()),
        'all_reference_geometry_diagnostic':all_geometry,
        'validation': reports, 'qualified_only_training_same_folds': baseline,
        'interval_scope': 'Independent hash-split calibration MLB players; max absolute season error per player. No KBO coverage claim.',
        'input_sha256': {str(p.relative_to(ROOT)): sha(p) for p in [OUT/'expanded_mlb_model_inputs.csv', Path(__file__).resolve()]},
        'limitations': ['All-pitch seasonal arm-angle labels; FF spin/movement inputs are a distinct denominator',
            'Observed high-angle residuals alone do not establish conditional prediction bias',
            'Player hash-split test is newly defined but source labels have been explored; not prospectively untouched',
            'No true KBO shoulder/arm-angle labels; movement proxy and optical spin are separate',
            'No production replacement or Pitch Plot publication from these experiments']}
    d.to_csv(OUT/'expanded_mlb_validation.csv', index=False)
    save_json(OUT/'expanded_mlb_study_report.json', report)
    save_json(CACHE/'research_models.json', state)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['collect', 'details', 'assemble', 'compare'])
    args = parser.parse_args()
    {'collect': collect_reference, 'details': collect_details, 'assemble': assemble, 'compare': compare}[args.stage]()


if __name__ == '__main__':
    main()
