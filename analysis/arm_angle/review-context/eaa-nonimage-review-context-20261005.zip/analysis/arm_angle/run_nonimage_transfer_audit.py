"""Conditional flight-ODE stress tests and bounded VB inverse-spin transfer.

These are diagnostics, not optical spin measurements or KBO angle validation.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json

import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from scipy.special import expit, logit
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from run_expanded_nonimage_study import CACHE, OUT, ROOT, save_json, sha, x_for, posture_angle
from run_spin_ode_study import fit_row, TRAJ
from run_vb_spin_bridge_pilot import FEATURES, historical_inputs, vb_features
from visualbaseball.spin_axis_ode import (Environment, forward_observations, axis_from_degrees,
    axis_degrees, PLATE_FRONT_Y_M)
from visualbaseball.curated import load_table, table_digest
from visualbaseball.estimated_arm_angle import _predict, season_estimates
from visualbaseball.vb_arm_angle import model_state


def plane_time_fit(row, environment):
    r = [-row.rel_side, row.initial_y_m, row.rel_height]
    v = [row.initial_vx_m_s, row.initial_vy_m_s, row.initial_vz_m_s]
    spin = row.spin_rate*2*np.pi/60
    phi = float(np.degrees(np.arctan2(-row.observed_hb_m, -row.observed_ivb_m))%360)
    target = np.array([row.observed_hb_m, row.observed_ivb_m, row.zone_speed/3.6, PLATE_FRONT_Y_M])
    scales = np.array([.01, .01, .3, .01])
    def evaluate(p):
        axis = axis_from_degrees(p[2], v)
        return forward_observations(r, v, row.flight_time_s+p[3], axis*spin*p[1], p[0], environment)
    def residual(p):
        pred = evaluate(p)
        values = np.array([pred['horizontal_break_m'], pred['induced_vertical_break_m'],
                           pred['terminal_speed_m_s'], pred['terminal_y_m']])
        return (values-target)/scales
    fit = least_squares(residual, [.35, .8, phi, 0.],
          bounds=([.1, .001, phi-120, -.01], [.7, 1., phi+120, .01]),
          x_scale=[.3, .5, 30, .004], max_nfev=50)
    error = residual(fit.x)*scales
    closure = bool(abs(error[0])<=.02 and abs(error[1])<=.02 and abs(error[2])*3.6<=1)
    plane = bool(abs(error[3])<=.1); boundary = bool(fit.x[1]>=.999)
    return {'status': 'fitted' if fit.success else 'optimizer_not_converged',
        'axis_deg': axis_degrees(axis_from_degrees(fit.x[2], v)),
        'effective_active_fraction': float(fit.x[1]), 'drag_coefficient': float(fit.x[0]),
        'hb_closure_error_cm': float(error[0]*100), 'ivb_closure_error_cm': float(error[1]*100),
        'speed_closure_error_kmh': float(error[2]*3.6), 'plate_y_error_cm': float(error[3]*100),
        'spin_fraction_at_boundary': boundary, 'closure_pass': closure, 'plane_pass': plane,
        'fit_eligible': bool(fit.success and closure and plane and not boundary),
        'flight_time_adjustment_ms': float(fit.x[3]*1000),
        'time_adjustment_at_bound': bool(abs(fit.x[3])>=.00999)}


def ode_audit():
    path = OUT/'ode_kbo_fastball_seasons.csv'
    d = pd.read_csv(path, dtype={'pitcher_id': str})
    focus = d.loc[d.pitcher_id.isin(['52060', '51897'])]
    remaining = d.loc[~d.index.isin(focus.index)].sort_values(['effective_active_fraction','season','pitcher_id'])
    # Deterministic span of efficiency, includes successful and failed fits.
    sample = remaining.iloc[np.unique(np.linspace(0, len(remaining)-1, 40, dtype=int))]
    sample = pd.concat([focus, sample]).reset_index(drop=True)
    scenarios = [('nominal_fixed_time', Environment(), False),
        ('low_density_fixed_time', Environment(density_kg_m3=1.10), False),
        ('high_density_fixed_time', Environment(density_kg_m3=1.30), False),
        ('alternative_lift_fixed_time', Environment(lift_law='piecewise'), False),
        ('nominal_fit_time_and_plane', Environment(), True),
        ('high_density_fit_time_and_plane', Environment(density_kg_m3=1.30), True)]
    jobs = [(row, name, env, fit_time) for row in sample.itertuples() for name, env, fit_time in scenarios]
    def one(job):
        row, name, env, fit_time = job
        result = plane_time_fit(row, env) if fit_time else fit_row(row, env)
        if not fit_time:
            result['flight_time_adjustment_ms'] = 0.; result['time_adjustment_at_bound'] = False
        return {'season': row.season, 'pitcher_id': row.pitcher_id, 'pitcher_name': row.pitcher_name,
                'scenario': name, 'density_kg_m3': env.density_kg_m3, 'lift_law': env.lift_law,
                'original_flight_time_s': row.flight_time_s, **result}
    rows = []
    with ThreadPoolExecutor(max_workers=2) as pool:
        for i, row in enumerate(pool.map(one, jobs), 1):
            rows.append(row)
            if i%48 == 0:
                print('ODE stress tests', i, '/', len(jobs), flush=True)
    result = pd.DataFrame(rows)
    result.to_csv(OUT/'nonimage_ode_stress_audit.csv', index=False)
    summary = result.groupby('scenario').agg(rows=('pitcher_id','size'), eligible=('fit_eligible','sum'),
        fraction_boundary=('spin_fraction_at_boundary','sum'), plane_pass=('plane_pass','sum'),
        abs_time_adjustment_median_ms=('flight_time_adjustment_ms', lambda s: float(s.abs().median()))).to_dict('index')
    focus_result = result[result.pitcher_id.isin(['52060','51897'])]
    save_json(OUT/'nonimage_ode_stress_report.json', {'sample_seasons':len(sample),'scenarios':summary,
        'focus': focus_result[['season','pitcher_id','pitcher_name','scenario','axis_deg','effective_active_fraction',
            'plate_y_error_cm','fit_eligible','flight_time_adjustment_ms']].to_dict('records'),
        'not_optical_truth': True, 'not_an_eAA_calibration': True,
        'fit_time_note': 'Four fitted observations/parameters; flight time allowed +/-10ms. Closure is not independent accuracy.',
        'new_time_fit_not_used_as_VB_training_truth': True,
        'limitations': ['Density and lift-law scenarios are assumptions, not measured weather or ball calibration',
            'Changing flight time tests mixed-device consistency; derived VB time is not a separate measurement',
            'Missing shoulder geometry and SSW remain unresolved; a successful fit cannot identify arm slot'],
        'input_sha256':{str(path.relative_to(ROOT)):sha(path),str(Path(__file__).resolve().relative_to(ROOT)):sha(Path(__file__).resolve())}})
    print('ODE stress audit complete', flush=True)


def spin_targets(d, bounded):
    hand = d.pitcher_hand.map({'Right':1.,'Left':-1.}).to_numpy(float)
    a = np.radians(d.axis_deg)
    if bounded:
        return np.column_stack([np.log(d.spin_rate), logit(d.effective_active_fraction), hand*np.sin(a),np.cos(a)])
    return np.column_stack([np.log(d.spin_rate),np.log(d.spin_rate*d.effective_active_fraction),hand*np.sin(a),np.cos(a)])


def spin_predictions(model, d, bounded):
    raw = model.predict(d[FEATURES].to_numpy(float)); out = d.copy()
    out['pred_rpm'] = np.exp(raw[:,0])
    out['pred_fraction'] = expit(raw[:,1]) if bounded else np.exp(raw[:,1]-raw[:,0])
    out['pred_active_rpm'] = out.pred_rpm*out.pred_fraction
    hand = out.pitcher_hand.map({'Right':1.,'Left':-1.}).to_numpy(float)
    out['pred_axis_deg'] = np.degrees(np.arctan2(hand*raw[:,2],raw[:,3]))%360
    return out


def spin_metrics(d):
    gap = (d.pred_axis_deg-d.axis_deg+180)%360-180
    return {'rows':len(d),'players':int(d.pitcher_id.nunique()),
       'axis_MAE_deg':float(gap.abs().mean()), 'RPM_MAE':float(abs(d.pred_rpm-d.spin_rate).mean()),
       'fraction_MAE_percentage_points':float(abs(d.pred_fraction-d.effective_active_fraction).mean()*100),
       'fraction_outside_0_1':int((~d.pred_fraction.between(0,1)).sum())} if len(d) else {'rows':0}


def transfer():
    target_path = OUT/'ode_kbo_fastball_seasons.csv'
    target = pd.read_csv(target_path, dtype={'pitcher_id':str})
    fpath = CACHE/'vb_season_features.parquet'
    if fpath.exists():
        feat = pd.read_parquet(fpath)
        input_meta = json.loads((CACHE/'vb_season_feature_sources.json').read_text())
        for rel, digest in input_meta['matched_hashes'].items():
            if sha(ROOT/rel) != digest:
                raise ValueError('Historical matched feature source changed')
    else:
        feat, hashes, counts = historical_inputs(target)
        feat.to_parquet(fpath,index=False)
        input_meta = {'matched_hashes':hashes,'counts':counts}
        save_json(CACHE/'vb_season_feature_sources.json',input_meta)
    feat.pitcher_id = feat.pitcher_id.astype(str)
    d = target.merge(feat,on=['season','pitcher_id','pitcher_name','pitcher_hand'],validate='one_to_one')
    d = d.loc[d.fit_eligible & d.effective_active_fraction.between(.001,.998999)].reset_index(drop=True)
    buckets = d.pitcher_id.map(lambda p:int(hashlib.sha256(('vb-spin-v2:'+p).encode()).hexdigest()[:8],16)%10)
    pre = d.season.le(2023); train = pre & buckets.lt(6); test_players = pre & buckets.ge(8)
    time = d.season.eq(2024); strict = time & ~d.pitcher_id.isin(set(d.loc[train,'pitcher_id']))
    if set(d.loc[train,'pitcher_id']) & set(d.loc[test_players,'pitcher_id']):
        raise ValueError('VB inverse-spin player leakage')
    models = {}; evaluations = {}; predictions = []
    for bounded in [False,True]:
        name = 'bounded_logit_fraction' if bounded else 'unbounded_active_RPM_ratio'
        model = make_pipeline(StandardScaler(),Ridge(alpha=10.)).fit(d.loc[train,FEATURES].to_numpy(float),spin_targets(d,bounded)[train])
        models[name] = model
        pred = spin_predictions(model,d,bounded); pred['model'] = name
        pred['eval_unseen_player_pre2024'] = test_players; pred['eval2024_time'] = time; pred['eval2024_unseen_player'] = strict
        predictions.append(pred)
        evaluations[name] = {label:spin_metrics(pred.loc[mask]) for label,mask in [
            ('pre2024_unseen_players',test_players),('2024_time',time),('2024_unseen_players',strict)]}
    pd.concat(predictions,ignore_index=True).to_csv(OUT/'nonimage_vb_spin_transfer_validation.csv',index=False)
    # The bounded family is predeclared for application; physical bounds alone
    # are not evidence of improved spin accuracy or KBO angle accuracy.
    bridge = models['bounded_logit_fraction']
    state = json.loads((CACHE/'research_models.json').read_text())
    frozen_path = ROOT/'data/models/estimated_arm_angle_v1.json'; frozen = json.loads(frozen_path.read_text())
    heights = pd.read_csv(ROOT/'data/tracking/player_heights.csv',dtype={'player_id':str}).set_index('player_id')
    bio = pd.read_parquet(ROOT/'data/curated/players/player_bio.parquet').set_index('player_id')
    bio.index = bio.index.astype(str)
    cols = list(dict.fromkeys(['season','game_id','pitch_id','pitcher_id','pitcher_name','stadium','pitch_type_code',
        'trajectory_valid','source_y0','release_x_55','release_z_55','vx_55','vy_55','vz_55','velocity_kmh',
        'vertical_movement_cm','horizontal_movement_cm']+TRAJ))
    future = []; source_hashes = {}
    optical_scenarios = []
    support_train = d.loc[train,FEATURES]
    for year in [2025,2026]:
        for pid in ['52060','51897','56459']:
            table = load_table(ROOT,'pitches',year,columns=cols,player_id=pid)
            raw = table.to_pandas()
            if raw.empty:
                continue
            if set(raw.pitcher_name) != {str(heights.loc[pid,'player_name'])}:
                raise ValueError('KBO source identity mismatch')
            h = float(heights.loc[pid,'height_cm'])/100
            hand = 'Right' if bio.loc[pid,'throws']=='R' else 'Left'; sign = 1 if hand=='Right' else -1
            source_hashes[f'{year}/{pid}'] = table_digest(table.to_pylist(),table.schema)
            raw['height_cm'] = h*100; raw['pitcher_hand'] = hand
            scopes = [(f'{year}_full',raw)]
            if year==2026:
                scopes.append(('2026_through0728',raw.loc[raw.game_id.str[:8].le('20260728')]))
            for scope, part in scopes:
                ff = vb_features(part.loc[part.pitch_type_code.eq('FF')])
                if len(ff)<100:
                    continue
                observed = season_estimates(ROOT,year,part.to_dict('records'))[pid]
                good = part.loc[part.trajectory_valid.fillna(False)&np.isfinite(part[['release_x_55','release_z_55','vx_55','vy_55','vz_55']]).all(axis=1)&part.vy_55.lt(0)]
                bx = [h,float((-sign*good.release_x_55/100).mean()),float((good.release_z_55/100).mean()),
                      float((-sign*good.vx_55/good.vy_55).mean()),float((good.vz_55/good.vy_55).mean())]
                delta = _predict(frozen['bridge'],bx)
                season = pd.DataFrame([{**ff[FEATURES].mean().to_dict(),'pitcher_hand':hand,
                    'height_cm':h*100,'rel_height':bx[2]+delta[1],'rel_side':sign*(bx[1]+delta[0])}])
                predicted = spin_predictions(bridge,season,True)
                predicted['movement_inferred'] = predicted.pred_axis_deg
                predicted['alan_active_spin_pct'] = predicted.pred_fraction
                predicted['spin_rate'] = predicted.pred_rpm
                predicted['ff_speed_m_s'] = predicted.speed55
                family = 'movement_axis_active_proxy'; x = x_for(predicted,family)[0]
                angle = float(_predict(state[family]['model'],x))
                qfeatures = predicted[FEATURES].iloc[0]
                beyond = (qfeatures<support_train.min()) | (qfeatures>support_train.max())
                outside_angle = bool(np.any(x<np.array(state[family]['feature_min'])) or np.any(x>np.array(state[family]['feature_max'])))
                future.append({'scope':scope,'pitcher_id':pid,'pitcher_name':str(part.pitcher_name.iloc[0]),
                    'all_pitches':len(part),'FF_feature_pitches':len(ff),'frozen_v1_deg':observed['angle_deg'],
                    'raw_conditional_movement_proxy_deg':angle,'bounded_predicted_RPM':float(predicted.pred_rpm.iloc[0]),
                    'bounded_conditional_fraction':float(predicted.pred_fraction.iloc[0]),
                    'predicted_effective_axis_deg':float(predicted.pred_axis_deg.iloc[0]),
                    'outside_VB_transfer_training_features':beyond[beyond].index.tolist(),
                    'outside_MLB_proxy_training_bounds':outside_angle,
                    'point_eligible_under_numeric_bounds':bool(not beyond.any() and not outside_angle),
                    'MLB_proxy_query_features':x.tolist(),
                    'actual_2025_2026_optical_inputs':False,'KBO_reference_interval':None,
                    'unseen_stadium_in_frozen_bridge':observed.get('flags',{}).get('unseen_stadium'),
                    'status':'audit_only; conditional inverse proxy is not verified equivalent to MLB alan/movement fields'})
                if pid in ['52060','51897']:
                    # User-reported optical-like values remain explicit inputs
                    # to a sensitivity scenario, never fitted reference labels.
                    anchor = target.loc[target.pitcher_id.eq(pid)&target.season.eq(2024)]
                    if len(anchor)!=1:
                        raise ValueError('Missing unique observed2024RPM anchor')
                    for axis in ([172.5,180.] if pid=='52060' else [180.]):
                        q = season.copy(); q['hawkeye_measured'] = axis; q['active_spin'] = .99
                        q['spin_rate'] = float(anchor.spin_rate.iloc[0]); q['ff_speed_m_s'] = q.speed55
                        estimates = {}; flags = {}
                        for optic_family in ['optical_spin','posture_optical_spin']:
                            optic_x = x_for(q,optic_family)[0]
                            value = np.asarray(_predict(state[optic_family]['model'],optic_x))
                            value = float(posture_angle(q,value.reshape(1,2))[0]) if optic_family.startswith('posture_') else float(value)
                            estimates[optic_family] = value
                            flags[optic_family] = bool(np.any(optic_x<np.array(state[optic_family]['feature_min'])) or np.any(optic_x>np.array(state[optic_family]['feature_max'])))
                        optical_scenarios.append({'scope':scope,'pitcher_id':pid,
                            'assumed_axis_deg':axis,'assumed_fraction':.99,'anchor_total_RPM':float(anchor.spin_rate.iloc[0]),
                            'anchor_RPM_season':2024,'frozen_v1_deg':observed['angle_deg'],
                            'estimates_deg':estimates,'outside_univariate_training_bounds':flags,
                            'optical_query_features':x_for(q,'optical_spin')[0].tolist(),
                            'actual_optical_inputs':False,'not_a_confidence_interval':True})
    save_json(OUT/'nonimage_vb_spin_transfer_report.json',{'method':'VB numerical features -> logRPM,logit conditional fraction,circular effective axis; scaled Ridge10',
        'evaluation':evaluations,'KBO_cases':future,'KBO_optical_input_scenarios':optical_scenarios,
        'train_seasons':'2019–2023; hash60% of eligible players',
        'training_rows':int(train.sum()),'training_players':int(d.loc[train,'pitcher_id'].nunique()),
        'Park_eligible_target_rows':int(d.pitcher_id.eq('52060').sum()),
        'target_is_conditional_ODE_not_optical_spin':True,'not_actual_KBO_angle_accuracy':True,
        'no_new_time_fit_or_boundary_labels_in_training':True,'source_hashes':source_hashes,
        'input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in [target_path,fpath,CACHE/'research_models.json',frozen_path]},
        'limitations':['Bounded fractions are guaranteed by parameterization; this is not validation of 99% efficiency',
            '2024 time-only set can include prior-season training players; unseen-player subset reported separately',
            'No optical labels or SSG same-pitch correspondence; MLB/KBO proxy definition equivalence unverified',
            'No stadium-held-out transfer claim; unknown stadium/device effects remain',
            'No production or Pitch Plot changes']})
    print('VB transfer audit complete', json.dumps(evaluations,ensure_ascii=False),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('stage',choices=['ode','transfer'])
    args=parser.parse_args();{'ode':ode_audit,'transfer':transfer}[args.stage]()


if __name__=='__main__':main()
