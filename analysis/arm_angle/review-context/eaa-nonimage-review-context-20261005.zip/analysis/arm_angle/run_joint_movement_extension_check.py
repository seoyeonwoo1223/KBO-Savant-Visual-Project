"""Same-cohort MLB extension/movement/spin check and Paddack external case."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import gzip
import hashlib
import io
import json
import re

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from run_park_spin_sensitivity import build_reference, inputs
from visualbaseball.arm_angle_calibration import metrics
from visualbaseball.curated import load_table, table_digest
from visualbaseball.estimated_arm_angle import _predict, season_estimates

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/arm_angle/results'
OPTIONS = ['geometry', 'geometry_extension', 'optical_spin', 'optical_spin_extension',
           'optical_spin_movement', 'optical_spin_extension_movement']


def cached_ff_movement(manifest):
    jobs = [(int(year), q) for year, m in manifest.items() for q in m['source_requests'] if not q['capped']]

    def read(job):
        year, q = job
        tag = hashlib.sha256(q['url'].encode()).hexdigest()[:16]
        path = ROOT / '.cache/arm_angle/candidates/source_cache' / f"{year}-{q['date_start']}-{q['date_end']}-{tag}.csv.gz"
        content = gzip.decompress(path.read_bytes())
        if hashlib.sha256(content).hexdigest() != q['source_sha256']:
            raise ValueError('Unverified retained Statcast response')
        columns = ['pitcher', 'game_year', 'game_pk', 'at_bat_number', 'pitch_number', 'pitch_type', 'pfx_z', 'pfx_x']
        frame = pd.read_csv(io.BytesIO(content), usecols=columns, dtype={'pitcher': str})
        if len(frame) != q['rows'] or not frame.game_year.eq(year).all():
            raise ValueError('Retained response scope changed')
        frame = frame.loc[frame.pitch_type.eq('FF') & np.isfinite(frame[['pfx_z', 'pfx_x']]).all(axis=1)].copy()
        frame['season'] = year
        return frame

    with ThreadPoolExecutor(max_workers=3) as pool:
        frames = list(pool.map(read, jobs))
    pitches = pd.concat(frames, ignore_index=True)
    if pitches.duplicated(['season', 'game_pk', 'at_bat_number', 'pitch_number']).any():
        raise ValueError('Duplicate retained source pitch')
    out = pitches.groupby(['season', 'pitcher']).agg(
        ff_ivb_ft=('pfx_z', 'mean'), ff_hb_ft=('pfx_x', 'mean'), n_ff_movement=('pitcher', 'size')).reset_index()
    out['ff_ivb_m'] = out.ff_ivb_ft * .3048
    out['ff_hb_m'] = out.ff_hb_ft * .3048
    return out, {'verified_uncapped_responses': len(jobs), 'FF_pitches': len(pitches),
                 'source': 'Retained official Statcast CSV pfx_z/pfx_x in feet; FF regular-season means',
                 'TM_VB_movement_definition_equivalence_verified': False}


def model_inputs(data, family):
    optical = family.startswith('optical_spin')
    x = inputs(data, 'optical_axis_rpm_speed_active' if optical else 'geometry')
    if 'extension' in family:
        x = np.column_stack([x, data.extension_over_height])
    if 'movement' in family:
        hand = data.pitcher_hand.map({'Right': 1., 'Left': -1.}).to_numpy(float)
        x = np.column_stack([x, data.ff_ivb_m, -hand * data.ff_hb_m])
    return x


def estimator():
    return make_pipeline(PolynomialFeatures(2, include_bias=False), StandardScaler(), Ridge(alpha=10.))


def main():
    reference, sources, source_paths = build_reference()
    extension_path = OUT / 'candidate_mlb_season_inputs.csv'
    manifest_path = OUT / 'candidate_statcast_source_manifest.json'
    extension = pd.read_csv(extension_path, dtype={'pitcher': str})
    if extension.duplicated(['season', 'pitcher']).any():
        raise ValueError('Duplicate extension input')
    movement, movement_source = cached_ff_movement(json.loads(manifest_path.read_text()))
    data = reference.merge(extension[['season', 'pitcher', 'extension_over_height']],
                           on=['season', 'pitcher'], validate='one_to_one')
    data = data.merge(movement, on=['season', 'pitcher'], validate='one_to_one')
    valid = (np.isfinite(data[['extension_over_height', 'ff_ivb_m', 'ff_hb_m']]).all(axis=1)
             & data.n_ff_movement.ge(100))
    data = data.loc[valid].reset_index(drop=True)
    if data.groupby('pitcher').split.nunique().max() != 1:
        raise ValueError('Player split leakage')
    truth = data.arm_angle.to_numpy(float)
    train = data.split.eq('train').to_numpy(); test = data.split.eq('test').to_numpy()
    folds = list(GroupKFold(n_splits=5, shuffle=True, random_state=42).split(data, truth, data.pitcher))
    reports = {}
    for family in OPTIONS:
        x = model_inputs(data, family); oof = np.full(len(data), np.nan)
        for a, b in folds:
            if set(data.pitcher.iloc[a]) & set(data.pitcher.iloc[b]):
                raise ValueError('CV player leakage')
            oof[b] = estimator().fit(x[a], truth[a]).predict(x[b])
        fixed = estimator().fit(x[train], truth[train])
        data['oof_' + family] = oof
        data['fixed_' + family] = fixed.predict(x)
        high = truth >= 60
        reports[family] = {'fixed_test': metrics(truth[test], data.loc[test, 'fixed_' + family]),
                           'whole_player_OOF': metrics(truth, oof),
                           'high60plus_OOF': metrics(truth[high], oof[high]),
                           'input_features': int(x.shape[1]),
                           'high60plus_fixed_test_rows': int((high & test).sum())}
        print(family, reports[family]['fixed_test']['mae_deg'], flush=True)
    paddack = data.loc[data.pitcher.eq('663978')].copy()
    if paddack.empty or not paddack.split.eq('calibration').all():
        raise ValueError('Paddack must be outside fixed training set')
    selected = ['season', 'pitcher', 'p_name_display_first_last', 'arm_angle', 'rel_side', 'rel_height',
                'height_cm', 'axis_deg', 'active_fraction', 'spin_rate', 'extension_over_height',
                'ff_ivb_m', 'ff_hb_m', 'n_ff_movement', 'split'] + ['fixed_' + f for f in OPTIONS]
    paddack[selected].to_csv(OUT / 'paddack_mlb_joint_check.csv', index=False)
    data.to_csv(OUT / 'joint_movement_extension_mlb_validation.csv', index=False)

    columns = ['season', 'game_id', 'pitch_id', 'pitcher_id', 'pitcher_name', 'stadium', 'pitch_type_code',
               'velocity_kmh', 'trajectory_valid', 'source_y0', 'release_x_55', 'release_z_55',
               'vx_55', 'vy_55', 'vz_55', 'vertical_movement_cm', 'horizontal_movement_cm']
    table = load_table(ROOT, 'pitches', 2026, columns=columns, player_id='56459')
    kbo = table.to_pandas()
    if set(kbo.pitcher_name) != {'페덱'}:
        raise ValueError('KBO player identity changed')
    official_height = pd.read_csv(ROOT / 'data/tracking/player_heights.csv', dtype={'player_id': str})
    height = official_height.loc[official_height.player_id.eq('56459')]
    if len(height) != 1 or height.player_name.iloc[0] != '페덱':
        raise ValueError('KBO official height identity mismatch')
    h = float(height.height_cm.iloc[0]) / 100
    ok = (kbo.trajectory_valid.fillna(False) & np.isfinite(kbo[['release_x_55', 'release_z_55', 'vx_55', 'vy_55', 'vz_55']]).all(axis=1)
          & kbo.vy_55.lt(0))
    part = kbo.loc[ok]
    bx = [h, float((-part.release_x_55 / 100).mean()), float((part.release_z_55 / 100).mean()),
          float((-part.vx_55 / part.vy_55).mean()), float((part.vz_55 / part.vy_55).mean())]
    frozen_path = ROOT / 'data/models/estimated_arm_angle_v1.json'; frozen = json.loads(frozen_path.read_text())
    correction = _predict(frozen['bridge'], bx)
    kbo_summary = {'season': 2026, 'KBO_id': '56459', 'MLB_id': '663978',
                   'player_name': '페덱', 'height_cm': h * 100,
                   'n_pitches': len(kbo), 'n_games': int(kbo.game_id.nunique()),
                   'first_date': str(kbo.game_id.str[:8].min()), 'last_date': str(kbo.game_id.str[:8].max()),
                   'bridged_rel_side_m': float(bx[1] + correction[0]),
                   'bridged_rel_height_m': float(bx[2] + correction[1]),
                   'frozen_eAA': season_estimates(ROOT, 2026, table.to_pylist())['56459'],
                   'joint_model_prediction': None,
                   'joint_prediction_withheld_reason': 'No2026actual extension,totalRPM,opticaldirection,activefraction; VB IVB not verified equivalent to Statcast pfx_z',
                   'MLB2024_angle_is_not2026_ground_truth': True,
                   'columns': columns, 'selected_digest': table_digest(table.to_pylist(), table.schema)}

    html_path = ROOT / '.cache/arm_angle/definition_check/savant_arm_angles.html'
    js_path = ROOT / '.cache/arm_angle/definition_check/pitcher-arm-angles.js'
    html = html_path.read_text(); js = js_path.read_text()
    raw = json.loads(re.search(r'(?:var|const|let)\s+rawData\s*=\s*(\[.*?\]);', html, re.S).group(1))
    official = next(r for r in raw if str(r['pitcher']) == '663978')
    frontal = float(np.degrees(np.arctan2(official['release_ball_z'] - official['shoulder_z'],
                                        abs(official['relative_shoulder_x'] - official['relative_release_ball_x']))))
    if 'Math.atan2(t,n)' not in js or abs(frontal - official['arm_angle']) > 1:
        raise ValueError('Official display definition or Paddack point reconciliation changed')
    report = {'scope': 'Research-only same-cohort MLB combined inputs; not a KBO angle calibration',
              'cohort_rows': len(data), 'cohort_pitchers': int(data.pitcher.nunique()),
              'lost_from_optical_cohort': len(reference) - len(data), 'splits': data.groupby('split').size().to_dict(),
              'model_specification': 'Predeclared degree2/scaled Ridge10; all six families evaluated without selecting on Paddack or test',
              'validation': reports, 'Paddack_MLB': paddack[selected].to_dict('records'), 'Paddack_KBO': kbo_summary,
              'Savant_definition': {'url': 'https://baseballsavant.mlb.com/leaderboard/pitcher-arm-angles?season=2024',
                                    'description': 'Release throwing-shoulder-to-ball line versus flat-ground horizontal,0horizontal90overhead',
                                    'plot_JS_formula': 'atan2(release_ball_z-shoulder_z,relative_shoulder_x-relative_release_ball_x); hand display mapping',
                                    'Paddack2024_published_angle_deg': official['arm_angle'],
                                    'Paddack2024_angle_of_season_mean_points_deg': frontal,
                                    'mean_angle_is_not_angle_of_mean_points': True,
                                    'SSG_internal_formula_verified': False},
              'movement_sources': movement_source, 'optical_sources': sources,
              'limitations': ['MLB source-backed movement/spin and actual extension; KBO2026joint inputs absent',
                              'Statcast pfx/TM IVB/VB vMov equivalence not established',
                              'Fixed test has no60plus angles; OOF subgroup results are descriptive',
                              'Paddack was calibration-held-out from fitting but previously inspected; not a newly untouched test',
                              'Cross-season MLB-KBO difference mixes genuine mechanics changes and device/model differences',
                              'No imagery processed; no production or Pitch Plot changes'],
              'input_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [*source_paths, extension_path, manifest_path, frozen_path, html_path, js_path,
                                         ROOT / 'data/tracking/player_heights.csv', Path(__file__).resolve()]}}
    (OUT / 'joint_movement_extension_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'cohort': len(data), 'Paddack': report['Paddack_MLB'], 'KBO': kbo_summary,
                      'Savant_definition': report['Savant_definition']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
