"""Park-only conditional spin experiment; no measured 2026 gyro/spin truth."""
from pathlib import Path
import hashlib
import json
import re

import numpy as np
import pandas as pd
from scipy.optimize import least_squares
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from visualbaseball.arm_angle_calibration import features, metrics
from visualbaseball.curated import load_table, table_digest
from visualbaseball.estimated_arm_angle import _predict
from visualbaseball.spin_axis_ode import (axis_from_degrees, conditional_full_axes,
    forward_observations, Environment, PLATE_FRONT_Y_M)
from visualbaseball.vb_arm_angle import model_state

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/arm_angle/results'
FAMILIES = ['geometry', 'optical_axis', 'optical_axis_rpm_speed',
            'optical_axis_rpm_speed_active', 'transverse_spin_vector', 'full_spin_vector_proxy']


def build_reference():
    reference_path = OUT / 'eaa_mlb_split_validation.csv'
    spin_path = OUT / 'ode_mlb_spin_reference.csv'
    reference = pd.read_csv(reference_path, dtype={'pitcher': str})
    spin = pd.read_csv(spin_path, dtype={'player_id': str}).rename(columns={'player_id': 'pitcher'})
    source_rows, hashes = [], {}
    for year in range(2020, 2025):
        p = ROOT / f'.cache/arm_angle/ode/source_cache/spin-direction-pitches-{year}.html'
        if not p.exists():
            raise FileNotFoundError(f'Cached authorized source needed: {p}')
        content = p.read_bytes(); sha = hashlib.sha256(content).hexdigest()
        hashes[str(p.relative_to(ROOT))] = sha
        match = re.search(r'(?:var|const|let)\s+leaderboardData\s*=\s*(\[.*?\]);', content.decode(), re.S)
        if not match:
            raise ValueError('Spin source schema changed')
        for r in json.loads(match.group(1)):
            if r.get('season') == year and r.get('api_pitch_type') == 'FF' and r.get('is_sport_mlb') == 1:
                source_rows.append({'pitcher': str(r['player_id']), 'season': year,
                    **{k: r[k] for k in ['image_spin_x', 'image_spin_y', 'image_spin_z']},
                    'vector_source_sha256': sha})
    vector = pd.DataFrame(source_rows)
    if vector.duplicated(['pitcher', 'season']).any():
        raise ValueError('Duplicate vector reference')
    spin = spin.merge(vector, on=['pitcher', 'season'], validate='one_to_one')
    if not spin.source_sha256.eq(spin.vector_source_sha256).all():
        raise ValueError('Vector and spin reference source mismatch')
    data = reference.merge(spin, on=['pitcher', 'season'], suffixes=('', '_ff'), validate='one_to_one')
    if not data.pitch_hand.eq(data.pitch_hand_ff).all():
        raise ValueError('Hand mismatch')
    data['ff_speed_m_s'] = data.release_speed * .44704
    data['axis_deg'] = data.hawkeye_measured
    data['active_fraction'] = data.active_spin
    data[['spin_x', 'spin_y', 'spin_z']] = data[['image_spin_x', 'image_spin_y', 'image_spin_z']]
    needed = ['axis_deg', 'active_fraction', 'spin_rate', 'ff_speed_m_s', 'spin_x', 'spin_y', 'spin_z']
    keep = np.isfinite(data[needed]).all(axis=1) & data.active_fraction.between(0, 1) & data.n_pitches_ff.ge(100)
    excluded = int((~keep).sum()); data = data.loc[keep].reset_index(drop=True)
    if data.groupby('pitcher').split.nunique().max() != 1:
        raise ValueError('Reference split leaks pitchers')
    vector_angle = np.degrees(np.arctan2(-data.spin_z, data.spin_x)) % 360
    gap = np.abs((vector_angle - data.axis_deg + 180) % 360 - 180)
    # The cached components are season-average display/source proxies, not
    # independent per-pitch 3D angular velocities; allow their observed mismatch.
    if gap.max() > 3:
        raise ValueError('Unexplained axis/vector coordinate mismatch')
    source = {'html_sha256': hashes, 'excluded': excluded,
              'vector_axis_abs_gap_max_deg': float(gap.max()),
              'vector_norm_min': float(np.linalg.norm(data[['spin_x','spin_y','spin_z']], axis=1).min()),
              'vector_norm_max': float(np.linalg.norm(data[['spin_x','spin_y','spin_z']], axis=1).max()),
              'vector_kind': 'Savant image_spin xyz seasonal source proxies, not per-pitch measured omega',
              'active_fraction_field': 'active_spin; alan_active_spin_pct is NOT substituted'}
    return data, source, [reference_path, spin_path]


def inputs(data, family):
    base = features(data)
    if family == 'geometry':
        return base
    phi = np.radians(data.axis_deg.to_numpy(float))
    hand = data.pitcher_hand.map({'Right': 1., 'Left': -1.}).to_numpy(float)
    direction = np.column_stack([hand * np.sin(phi), -np.cos(phi)])
    rpm = data.spin_rate.to_numpy(float) / 2000
    speed = data.ff_speed_m_s.to_numpy(float) / 40
    active = data.active_fraction.to_numpy(float)
    if family == 'optical_axis':
        return np.column_stack([base, direction])
    if family == 'optical_axis_rpm_speed':
        return np.column_stack([base, direction, rpm, speed])
    if family == 'optical_axis_rpm_speed_active':
        return np.column_stack([base, direction, rpm, speed, active])
    if family == 'transverse_spin_vector':
        return np.column_stack([base, direction * (rpm * active)[:, None], rpm, speed])
    if family == 'full_spin_vector_proxy':
        # Spin is an axial vector: mirroring left/right flips y,z, but not x.
        vector = np.column_stack([-data.spin_x, hand*data.spin_y, -hand*data.spin_z])
        return np.column_stack([base, vector * rpm[:, None], rpm, speed, active])
    raise ValueError(family)


def fit_models(data):
    truth = data.arm_angle.to_numpy(float)
    train, test = data.split.eq('train'), data.split.eq('test')
    folds = list(GroupKFold(n_splits=5, shuffle=True, random_state=42).split(data, truth, data.pitcher))
    models, reports = {}, {}
    for family in FAMILIES:
        x = inputs(data, family)
        oof = np.full(len(data), np.nan)
        def estimator():
            return make_pipeline(PolynomialFeatures(2, include_bias=False), StandardScaler(), Ridge(alpha=10.))
        for tr, te in folds:
            if set(data.pitcher.iloc[tr]) & set(data.pitcher.iloc[te]):
                raise ValueError('CV pitcher leakage')
            oof[te] = estimator().fit(x[tr], truth[tr]).predict(x[te])
        model = estimator().fit(x[train], truth[train])
        data['oof_' + family] = oof
        test_prediction = model.predict(x[test])
        data['split_' + family] = model.predict(x)
        high = test & data.arm_angle.ge(60)
        reports[family] = {'same_cohort_group_cv': metrics(truth, oof),
                          'fixed_split_test': metrics(truth[test], test_prediction),
                          'test_high_slot_60plus': metrics(truth[high], model.predict(x[high])) if high.any()
                              else {'n': 0, 'status': 'No60plusangles_in_fixed_test_cohort'},
                          'fitted_model': model_state(model),
                          'feature_min': x[train].min(axis=0).tolist(),
                          'feature_max': x[train].max(axis=0).tolist()}
        models[family] = model
        print(family, reports[family]['fixed_split_test']['mae_deg'], flush=True)
    return models, reports


def paired_test_improvement(data, base, augmented):
    d = data.loc[data.split.eq('test')].copy()
    improvement = (d['split_'+base]-d.arm_angle).abs() - (d['split_'+augmented]-d.arm_angle).abs()
    groups = improvement.groupby(d.pitcher).agg(['sum','count'])
    rng = np.random.default_rng(42)
    picks = rng.integers(0,len(groups),(2000,len(groups)))
    samples = groups['sum'].to_numpy()[picks].sum(axis=1) / groups['count'].to_numpy()[picks].sum(axis=1)
    return {'same_test_paired_MAE_improvement_deg':float(improvement.mean()),
            'pitcher_bootstrap_95_low_deg':float(np.quantile(samples,.025)),
            'pitcher_bootstrap_95_high_deg':float(np.quantile(samples,.975)),
            'n_pitchers':len(groups), 'not_a_KBO_angle_uncertainty_interval':True}


def park_inputs():
    columns = ['season','game_id','pitch_id','pitcher_id','pitcher_name','stadium',
               'trajectory_valid','source_y0','release_x_55','release_z_55','vx_55','vy_55','vz_55',
               'pitch_type_code','velocity_kmh']
    table = load_table(ROOT, 'pitches', 2026, columns=columns, player_id='52060')
    d = table.to_pandas()
    if set(d.pitcher_name) != {'박영현'}:
        raise ValueError('Identity mismatch')
    cols = ['release_x_55','release_z_55','vx_55','vy_55','vz_55']
    ok = d.trajectory_valid.fillna(False) & np.isfinite(d[cols]).all(axis=1) & d.vy_55.lt(0)
    d = d.loc[ok].copy()
    frozen_path = ROOT / 'data/models/estimated_arm_angle_v1.json'
    frozen = json.loads(frozen_path.read_text())
    rows = []
    for scope, part in [('2026_full', d), ('2026_through_0728', d[d.game_id.str[:8].le('20260728')])]:
        bridge_x = [1.83, float((-part.release_x_55/100).mean()), float((part.release_z_55/100).mean()),
                    float((-part.vx_55/part.vy_55).mean()), float((part.vz_55/part.vy_55).mean())]
        correction = _predict(frozen['bridge'], bridge_x)
        side, z = bridge_x[1] + correction[0], bridge_x[2] + correction[1]
        ff = part[part.pitch_type_code.eq('FF')]
        v = np.array([ff.vx_55.mean(), ff.vy_55.mean(), ff.vz_55.mean()], float)
        rows.append({'scope': scope, 'season': 2026, 'pitcher_hand': 'Right', 'height_cm': 183.,
                     'rel_side': side, 'rel_height': z, 'n_geometry_pitches': len(part), 'n_ff': len(ff),
                     'ff_speed_m_s': float(ff.velocity_kmh.mean()/3.6), 'velocity': v/np.linalg.norm(v),
                     'frozen_v1_deg': float(_predict(frozen['angle'], [1.83,z/1.83,side/1.83,0.])),
                     'geometry_source': '2026 canonical VB bridged to TM plane',
                     'RPM_source': '2024 FF mean used only as a scenario anchor; NOT measured2026RPM'})
    old_path = OUT / 'ode_kbo_fastball_seasons.csv'
    old = pd.read_csv(old_path)
    geom_path = OUT / 'park_diagnostics.json'; geom = json.loads(geom_path.read_text())
    for r in old[old.pitcher_id.eq(52060)].itertuples():
        g = next(x for x in geom['matched_years'] if x['season'] == r.season)
        v = np.array([r.initial_vx_m_s, r.initial_vy_m_s, r.initial_vz_m_s])
        rows.append({'scope': f'{r.season}_actual_TM_geometry', 'season': int(r.season),
                     'pitcher_hand': 'Right', 'height_cm': 183.,
                     'rel_side': g['actual_TM_rel_side_m'], 'rel_height': g['actual_TM_rel_height_m'],
                     'n_geometry_pitches': g['matched_pitches'], 'n_ff': int(r.n_ff),
                     'ff_speed_m_s': r.rel_speed/3.6, 'velocity': v/np.linalg.norm(v),
                     'frozen_v1_deg': g['frozen_TM_input_model_deg'], 'spin_rate_anchor': r.spin_rate,
                     'geometry_source': 'Actual TM2022–2024, user2026axis only as hypothetical perturbation',
                     'RPM_source': 'Measured TM FF mean in this season'})
    return rows, old, {'canonical_selected_column_digest': table_digest(table.to_pylist(), table.schema),
                      'canonical_columns': columns, 'canonical_rows': len(table)}, [frozen_path, old_path, geom_path]


def sensitivity(park, models, reports, anchor):
    rows = []
    # 12:00->180deg and 12:15->172.5deg in the cached Savant convention.
    # Active fractions are declared hypotheses, not inferred measurements.
    for base in park:
        for rpm in ([2300., anchor, 2600.] if base['season'] == 2026 else [base['spin_rate_anchor']]):
            for angle in [172.5, 176.25, 180.]:
                for active in [.80, .90, .95, .98, 1.]:
                    axis = axis_from_degrees(angle, base['velocity'])
                    for branch, vector in zip(['gyro_plus', 'gyro_minus'], conditional_full_axes(axis, active, base['velocity'])):
                        d = pd.DataFrame([{**{k:v for k,v in base.items() if k!='velocity'},
                            'axis_deg': angle, 'active_fraction': active, 'spin_rate': rpm,
                            'spin_x': vector[0], 'spin_y': vector[1], 'spin_z': vector[2]}])
                        record = {'scope': base['scope'], 'season': base['season'], 'axis_deg': angle,
                            'clock_label': {172.5:'12:15',176.25:'12:07.5',180.:'12:00'}[angle],
                            'assumed_active_fraction': active, 'assumed_spin_rate_rpm': rpm, 'gyro_branch': branch,
                            'conditional_omega_x_rad_s': float(vector[0]*rpm*2*np.pi/60),
                            'conditional_omega_y_rad_s': float(vector[1]*rpm*2*np.pi/60),
                            'conditional_omega_z_rad_s': float(vector[2]*rpm*2*np.pi/60),
                            'frozen_v1_deg': base['frozen_v1_deg'], 'all_extra_spin_values_are_scenarios': True,
                            'eligible_for_publication': False}
                        for family, model in models.items():
                            x = inputs(d, family); record[family+'_deg'] = float(model.predict(x)[0])
                            record[family+'_outside_training_bounds'] = bool(np.any(x[0] < reports[family]['feature_min']) or
                                                                           np.any(x[0] > reports[family]['feature_max']))
                        rows.append(record)
    return pd.DataFrame(rows)


def fixed_axis_physics(old):
    rows = []
    for r in old[old.pitcher_id.eq(52060) & old.season.eq(2024)].itertuples():
        position = [-r.rel_side, r.initial_y_m, r.rel_height]
        velocity = [r.initial_vx_m_s, r.initial_vy_m_s, r.initial_vz_m_s]
        target = np.array([r.observed_hb_m, r.observed_ivb_m, r.zone_speed/3.6])
        for angle in [172.5, 180.]:
            axis = axis_from_degrees(angle, velocity)
            def evaluate(p):
                return forward_observations(position, velocity, r.flight_time_s,
                    axis*(r.spin_rate*2*np.pi/60)*p[1], p[0], Environment())
            def residual(p):
                f = evaluate(p)
                return (np.array([f['horizontal_break_m'], f['induced_vertical_break_m'], f['terminal_speed_m_s']])-target)/[.01,.01,.3]
            fit = least_squares(residual, [.34,.95], bounds=([.10,.001],[.70,1.]), max_nfev=40)
            f = evaluate(fit.x); e = residual(fit.x)*[.01,.01,.3]
            rows.append({'season': 2024, 'assumed_axis_deg': angle,
                         'fit_active_fraction': float(fit.x[1]), 'fit_drag_coefficient': float(fit.x[0]),
                         'HB_error_cm': float(e[0]*100), 'IVB_error_cm': float(e[1]*100),
                         'speed_error_kmh': float(e[2]*3.6),
                         'plate_y_error_cm': float((f['terminal_y_m']-PLATE_FRONT_Y_M)*100),
                         'scope': '2024 measured movement,2026 reported clock axis as hypothetical constraint; not same-year consistency test'})
    return rows


def main():
    data, sources, paths = build_reference()
    models, reports = fit_models(data)
    park, old, canonical, other_paths = park_inputs(); paths += other_paths
    anchor = float(old.loc[old.pitcher_id.eq(52060) & old.season.eq(2024), 'spin_rate'].iloc[0])
    trial = sensitivity(park, models, reports, anchor)
    data.to_csv(OUT/'park_spin_mlb_validation.csv', index=False)
    trial.to_csv(OUT/'park_spin_sensitivity.csv', index=False)
    summary = {}
    for scope, part in trial.groupby('scope', sort=False):
        central = part[np.isclose(part.assumed_active_fraction,.95) &
                       (np.isclose(part.assumed_spin_rate_rpm, anchor) if scope.startswith('2026') else True)]
        summary[scope] = {'frozen_v1_deg': float(part.frozen_v1_deg.iloc[0]),
            'conditional_95pct_active_anchor_RPM': {family:{'min_deg':float(central[family+'_deg'].min()),
                'max_deg':float(central[family+'_deg'].max())} for family in FAMILIES},
            'all_scenario_ranges': {family:{'min_deg':float(part[family+'_deg'].min()),
                'max_deg':float(part[family+'_deg'].max()),
                'outside_training_bounds_scenarios':int(part[family+'_outside_training_bounds'].sum())} for family in FAMILIES}}
    report = {'status': 'Research conditional sensitivity, NOT measured Park arm slot',
        'MLB_cohort': {'rows':len(data),'pitchers':int(data.pitcher.nunique()),
                       'splits': data.groupby('split').size().to_dict()},
        'reference_sources':sources, 'validation':reports, 'Park_canonical':canonical,
        'paired_test_improvements': {
            'axis_RPM_speed_active_vs_geometry':paired_test_improvement(data,'geometry','optical_axis_rpm_speed_active'),
            'full_vector_vs_axis_RPM_speed_active':paired_test_improvement(data,'optical_axis_rpm_speed_active','full_spin_vector_proxy')},
        'Park_inputs': [{k:v for k,v in x.items() if k!='velocity'} for x in park],
        'Park_summary':summary, 'fixed_axis_2024_physics_diagnostic':fixed_axis_physics(old),
        'clock_mapping': 'Cached Savant convention: backspin180deg=12:00,172.5deg=12:15; user device convention unverified',
        'feature_redundancy': 'Axis, spin magnitude, active fraction define a conditional vector; not three independent measurements',
        'specification': 'Predeclared degree2 StandardScaler Ridge10; whole-pitcher CV5; fixed train only for Park predictions',
        'limitations': ['2026 RPM and active fraction are unmeasured; 2024 RPM anchor is a scenario only',
            '2026 axis is approximate user reference, not verified per-pitch or season optical measurement',
            'Full vector has two assumed gyro branches; sign is not identified by transverse movement',
            'Savant vector components are seasonal display/source proxies; mean vector is not individual-pitch omega',
            'Scenario full unit axes differ from norms of MLB mean-vector proxies; transfer is unvalidated',
            'Axis/active fraction and polynomial feature interactions are redundant; ablations need same cohort',
            'MLB validation is not KBO angle validation; scenario min/max is not an error interval',
            '2024 ODE failure is not repaired by assuming a 2026 clock axis',
            'No production model, PitchPlot or reference-range change'],
        'input_sha256': {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (OUT/'park_spin_sensitivity.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'Park':summary,'physics':report['fixed_axis_2024_physics_diagnostic']},ensure_ascii=False))


if __name__ == '__main__':
    main()
