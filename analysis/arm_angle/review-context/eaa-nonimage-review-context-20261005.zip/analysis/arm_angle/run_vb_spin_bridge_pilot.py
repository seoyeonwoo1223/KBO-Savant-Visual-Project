"""Conditional TM inverse-spin targets -> VB-only season features, research pilot."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler,PolynomialFeatures

from run_spin_ode_study import prepare_physics,TRAJ,TM
from run_park_spin_sensitivity import inputs
from visualbaseball.curated import load_table,table_digest
from visualbaseball.spin_axis_ode import FT_M,G,PLATE_FRONT_Y_M,time_to_plane
from visualbaseball.estimated_arm_angle import _predict
from visualbaseball.arm_angle_calibration import metrics

ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'analysis/arm_angle/results'
FEATURES=['height_m','left_hand','z55_over_height','side55_over_height','speed55','speed_mid',
          'armside_vx_over_minus_vy','vz_over_minus_vy','axis_arm_sin','axis_up_cos',
          'transverse_accel','drag_accel','flight55_to_plate']

def vb_features(d):
    d=d.copy();p=d[['x0','y0','z0']].to_numpy(float)*FT_M
    v=d[['vx0','vy0','vz0']].to_numpy(float)*FT_M
    a=d[['ax','ay','az']].to_numpy(float)*FT_M
    t55=time_to_plane(p[:,1],v[:,1],a[:,1],55*FT_M)
    end=time_to_plane(p[:,1],v[:,1],a[:,1],PLATE_FRONT_Y_M)
    v55=v+a*t55[:,None];mid=v+a*((t55+end)/2)[:,None]
    pos55=p+v*t55[:,None]+.5*a*t55[:,None]**2
    speed=np.linalg.norm(mid,axis=1);direction=mid/speed[:,None]
    aero=a+[0,0,G];parallel=(aero*direction).sum(axis=1);force=aero-parallel[:,None]*direction
    size=np.linalg.norm(force,axis=1);axis=np.cross(direction,force/size[:,None]);xz=np.linalg.norm(axis[:,[0,2]],axis=1)
    h=d.height_cm.to_numpy(float)/100;hand=d.pitcher_hand.map({'Right':1.,'Left':-1.}).to_numpy(float)
    d[FEATURES]=np.column_stack([h,(hand<0).astype(float),pos55[:,2]/h,-hand*pos55[:,0]/h,
        np.linalg.norm(v55,axis=1),speed,hand*v55[:,0]/(-v55[:,1]),v55[:,2]/(-v55[:,1]),
        hand*(-axis[:,2]/xz),-axis[:,0]/xz,size,-parallel,end-t55])
    keep=np.isfinite(d[FEATURES]).all(axis=1)&d.trajectory_valid.fillna(False)&(v55[:,1]<0)&(size>.01)&(size<40)&((end-t55)>.2)&((end-t55)<.8)
    return d.loc[keep]

def historical_inputs(target):
    parts=[];hashes={};counts=[]
    geom=pd.read_parquet(ROOT/'.cache/arm_angle/ode/geometry_inputs.parquet')
    old_report=json.loads((OUT/'ode_study_report.json').read_text())
    for year in range(2019,2025):
        p=ROOT/f'.cache/arm_angle/vb_bridge/matched/matched_{year}.parquet'
        digest=hashlib.sha256(p.read_bytes()).hexdigest();hashes[str(p.relative_to(ROOT))]=digest
        if old_report['matched_pitch_hashes'].get(f'matched_{year}')!=digest:
            raise ValueError('Matched source changed')
        cols=list(dict.fromkeys(['pitcher_id','pitcher_name','pitcher_hand','pitch_type','auto_pitch_type','trajectory_valid']+TRAJ+TM))
        raw=pq.read_table(p,columns=cols,filters=[('pitch_type','=','4-Seam Fastball')]).to_pandas()
        raw['season']=year
        raw=raw.merge(geom[['season','pitcher_id','height_cm']],on=['season','pitcher_id'],validate='many_to_one')
        d=prepare_physics(raw);d=d.loc[d.physics_valid&d.is_ff]
        d=vb_features(d)
        grouped=d.groupby(['season','pitcher_id','pitcher_name','pitcher_hand']).agg(
            **{name:(name,'mean') for name in FEATURES},n_feature_pitches=('height_cm','size')).reset_index()
        parts.append(grouped);counts.append({'season':year,'valid_FF_rows':len(d),'groups':len(grouped)})
    return pd.concat(parts,ignore_index=True),hashes,counts

def target_metrics(d):
    angle_error=(d.pred_axis_deg-d.axis_deg+180)%360-180
    f_true=d.effective_active_fraction;f_pred=d.pred_active_fraction
    valid=f_pred.between(.001,1)
    return {'rows':len(d),'pitchers':int(d.pitcher_id.nunique()),
        'axis_MAE_deg':float(angle_error.abs().mean()),
        'total_RPM_MAE':float((d.pred_total_rpm-d.spin_rate).abs().mean()),
        'conditional_active_RPM_MAE':float((d.pred_active_rpm-d.target_active_rpm).abs().mean()),
        'conditional_fraction_MAE_percentage_points':float((f_pred-f_true).abs().mean()*100),
        'predicted_fraction_outside_0_1':int((~valid).sum()),
        'not_optical_spin_accuracy':True}

def apply_bridge(model,d):
    raw=model.predict(d[FEATURES].to_numpy(float));d=d.copy()
    d['pred_total_rpm']=np.exp(raw[:,0]);d['pred_active_rpm']=np.exp(raw[:,1])
    d['pred_active_fraction']=d.pred_active_rpm/d.pred_total_rpm
    hand=d.pitcher_hand.map({'Right':1.,'Left':-1.}).to_numpy(float)
    d['pred_axis_deg']=np.degrees(np.arctan2(hand*raw[:,2],raw[:,3]))%360
    return d

def arm_model():
    d=pd.read_csv(OUT/'park_spin_mlb_validation.csv',dtype={'pitcher':str})
    # Movement-based quantities must not be substituted for optical quantities
    # in a model trained on the optical feature definition.
    d['axis_deg']=d.movement_inferred;d['active_fraction']=d.alan_active_spin_pct
    x=inputs(d,'optical_axis_rpm_speed_active');train=d.split.eq('train');test=d.split.eq('test')
    def est():return make_pipeline(PolynomialFeatures(2,include_bias=False),StandardScaler(),Ridge(alpha=10.))
    model=est().fit(x[train],d.loc[train,'arm_angle'])
    base=est().fit(inputs(d,'geometry')[train],d.loc[train,'arm_angle'])
    return model,{'same_cohort_fixed_test_geometry':metrics(d.loc[test,'arm_angle'],base.predict(inputs(d,'geometry')[test])),
                  'same_cohort_fixed_test_movement_active_proxy':metrics(d.loc[test,'arm_angle'],model.predict(x[test])),
                  'input_definition':'Official movement_inferred direction and alan_active_spin_pct proxy, NOT hawkeye_measured/active_spin',
                  'KBO_ODE_equivalence_verified':False}

def arm_inputs(d,predicted):
    out=d.copy()
    out['axis_deg']=out.pred_axis_deg if predicted else out.axis_deg
    out['active_fraction']=out.pred_active_fraction if predicted else out.effective_active_fraction
    out['spin_rate']=out.pred_total_rpm if predicted else out.spin_rate
    out['ff_speed_m_s']=out.speed55
    return inputs(out,'optical_axis_rpm_speed_active')

def main():
    target_path=OUT/'ode_kbo_fastball_seasons.csv';geom_path=ROOT/'.cache/arm_angle/ode/geometry_inputs.parquet'
    t=pd.read_csv(target_path,dtype={'pitcher_id':str});geom=pd.read_parquet(geom_path);geom.pitcher_id=geom.pitcher_id.astype(str)
    t=t.merge(geom[['season','pitcher_id','rel_height','rel_side','height_cm']],on=['season','pitcher_id'],
              suffixes=('_ff',''),validate='one_to_one')
    features,hashes,counts=historical_inputs(t);features.pitcher_id=features.pitcher_id.astype(str)
    d=t.merge(features,on=['season','pitcher_id','pitcher_name','pitcher_hand'],validate='one_to_one')
    d=d.loc[d.fit_eligible].reset_index(drop=True)
    d['target_active_rpm']=d.spin_rate*d.effective_active_fraction
    d['height_cm']=d.height_m*100
    pre=d.season.le(2023);ids=sorted(d.loc[pre,'pitcher_id'].unique());rng=np.random.default_rng(42);rng.shuffle(ids)
    n=len(ids);training=set(ids[:int(.6*n)]);testing=set(ids[int(.8*n):])
    train=pre&d.pitcher_id.isin(training);player_test=pre&d.pitcher_id.isin(testing);time_test=d.season.eq(2024)
    if set(d.loc[train,'pitcher_id'])&set(d.loc[player_test,'pitcher_id']):raise ValueError('Player leakage')
    # Mirror direction targets as well as features, then restore catcher axes.
    hand=d.pitcher_hand.map({'Right':1.,'Left':-1.}).to_numpy(float)
    y=np.column_stack([np.log(d.spin_rate),np.log(d.target_active_rpm),
                       hand*np.sin(np.radians(d.axis_deg)),np.cos(np.radians(d.axis_deg))])
    model=make_pipeline(StandardScaler(),Ridge(alpha=10.)).fit(d.loc[train,FEATURES].to_numpy(float),y[train])
    pred=apply_bridge(model,d)
    arm,arm_validation=arm_model()
    valid=pred.pred_active_fraction.between(.001,1)
    pred['TM_inverse_input_arm_proxy_deg']=arm.predict(arm_inputs(pred,False))
    pred['VB_predicted_inverse_input_arm_proxy_deg']=np.nan
    pred.loc[valid,'VB_predicted_inverse_input_arm_proxy_deg']=arm.predict(arm_inputs(pred.loc[valid],True))
    evaluation={}
    for name,mask in [('pre2024_unseen_pitchers',player_test),('2024_time_holdout',time_test)]:
        part=pred.loc[mask];evaluation[name]=target_metrics(part)
        usable=part.loc[part.pred_active_fraction.between(.001,1)]
        evaluation[name]['arm_proxy_bridge_MAE_deg']=float((usable.VB_predicted_inverse_input_arm_proxy_deg-usable.TM_inverse_input_arm_proxy_deg).abs().mean())
        evaluation[name]['arm_proxy_comparison_rows']=len(usable)
        evaluation[name]['not_actual_KBO_arm_angle_error']=True
        evaluation[name]['spin_only_comparison_common_TM_geometry_and_VB55_speed']=True
    pred.to_csv(OUT/'vb_spin_bridge_validation.csv',index=False)
    future=[];canonical_hashes={}
    frozen_path=ROOT/'data/models/estimated_arm_angle_v1.json';frozen=json.loads(frozen_path.read_text())
    cols=['season','game_id','pitch_id','pitcher_id','pitcher_name','stadium','pitch_type_code','trajectory_valid',
          'source_y0','release_x_55','release_z_55','vx_55','vy_55','vz_55','velocity_kmh']+TRAJ
    for year in [2025,2026]:
        table=load_table(ROOT,'pitches',year,columns=cols,player_id='52060');canonical_hashes[str(year)]=table_digest(table.to_pylist(),table.schema)
        raw=table.to_pandas();raw['height_cm']=183.;raw['pitcher_hand']='Right'
        # Current canonical coefficients are already normalized to50ft; their
        # actual y0 is used above, not source_y0 metadata.
        for scope,all_rows in [(f'{year}_full',raw)]+([(f'{year}_through0728',raw[raw.game_id.str[:8].le('20260728')])] if year==2026 else []):
            ff=vb_features(all_rows[all_rows.pitch_type_code.eq('FF')])
            if len(ff)<100:continue
            f=pd.DataFrame([{**ff[FEATURES].mean().to_dict(),'season':year,'pitcher_id':'52060','pitcher_hand':'Right'}]);p=apply_bridge(model,f)
            geometry=all_rows.loc[all_rows.trajectory_valid.fillna(False)&np.isfinite(all_rows[['release_x_55','release_z_55','vx_55','vy_55','vz_55']]).all(axis=1)&all_rows.vy_55.lt(0)]
            bx=[1.83,float((-geometry.release_x_55/100).mean()),float((geometry.release_z_55/100).mean()),
                float((-geometry.vx_55/geometry.vy_55).mean()),float((geometry.vz_55/geometry.vy_55).mean())]
            correction=_predict(frozen['bridge'],bx);p['rel_side']=bx[1]+correction[0];p['rel_height']=bx[2]+correction[1];p['height_cm']=183.
            a=float(p.pred_active_fraction.iloc[0]);values=f[FEATURES].iloc[0]
            beyond=(values<d.loc[train,FEATURES].min())|(values>d.loc[train,FEATURES].max())
            outside=bool(beyond.any())
            angle=float(arm.predict(arm_inputs(p,True))[0]) if .001<=a<=1 else None
            future.append({'scope':scope,'FF_feature_pitches':len(ff),'predicted_total_RPM':float(p.pred_total_rpm.iloc[0]),
                'predicted_conditional_active_RPM':float(p.pred_active_rpm.iloc[0]),'predicted_conditional_fraction':a,
                'predicted_effective_axis_deg':float(p.pred_axis_deg.iloc[0]),
                'raw_conditional_arm_proxy_audit_only_deg':angle,
                'conditional_arm_proxy_deg':angle if not outside else None,
                'inverse_bridge_outside_training_bounds':bool(outside),
                'outside_feature_names':beyond[beyond].index.tolist(),
                'status':'unvalidated2025_2026_transfer_NOT_published','actual_optical_axis_or_fraction':False})
    evaluation['labels']={'all_ODE_seasons':len(t),'eligible_ODE_seasons':len(d),'train_rows':int(train.sum()),
                         'train_pitchers':len(training),'Park_ODE_eligible_labels':int(d.pitcher_id.eq('52060').sum())}
    report={'method':'VB55-plane seasonal force/direction features -> log(totalRPM),log(conditional_activeRPM),hand-normalized effective_axis sin/cos; scaled Ridge10',
        'evaluation':evaluation,'movement_arm_model':arm_validation,'Park_2025_2026_pilot':future,
        'input_season_counts':counts,'canonical_Park_input_digests':canonical_hashes,
        'input_sha256':{**hashes,**{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [target_path,geom_path,frozen_path,OUT/'park_spin_mlb_validation.csv',Path(__file__).resolve()]}},
        'limitations':['Inverse targets are assumptions under lift/density/noSSW, not optical truth',
            'Season means are nonlinear summaries and different from mean pitch inversions',
            'No 2025/2026 TM RPM/extension/optical spin truth to verify transfer',
            'Valid-ODE selection excludes Park2022–2024; bridge predictions do not repair its failed ODE',
            'Held-out target agreement does not establish actual KBO arm-angle improvement',
            'MLB movement proxy to KBO ODE mapping is unverified; do not use optical-feature model here',
            'TotalRPM cannot be uniquely inferred from a trajectory; empirical RPM bridge retains gyro uncertainty',
            'No publishing, no reference interval, no production changes']}
    (OUT/'vb_spin_bridge_pilot.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(report,ensure_ascii=False))

if __name__=='__main__':main()
