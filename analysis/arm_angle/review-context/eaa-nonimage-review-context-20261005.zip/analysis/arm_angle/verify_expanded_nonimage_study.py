"""Independent numeric checks, whole-player uncertainty and query-support audit."""
import json
from pathlib import Path
import subprocess

import numpy as np
import pandas as pd

from run_expanded_nonimage_study import ROOT, OUT, CACHE, estimator, x_for, posture_targets, posture_angle, save_json, sha


def player_bootstrap(d, values):
    z = pd.DataFrame({'pitcher':d.pitcher.to_numpy(),'value':np.asarray(values)})
    groups = z.groupby('pitcher').value.agg(['sum','count'])
    rng = np.random.default_rng(42); draws = rng.integers(0,len(groups),(2000,len(groups)))
    samples = groups['sum'].to_numpy()[draws].sum(axis=1)/groups['count'].to_numpy()[draws].sum(axis=1)
    return {'estimate':float(z.value.mean()),'player_bootstrap_95_low':float(np.quantile(samples,.025)),
            'player_bootstrap_95_high':float(np.quantile(samples,.975)), 'rows':len(z),'players':len(groups)}


def distinct_neighbours(dist, ids, count=5):
    chosen = []; used = set()
    for i in np.argsort(dist):
        if np.isfinite(dist[i]) and ids[i] not in used:
            chosen.append(int(i)); used.add(ids[i])
            if len(chosen)==count:
                return chosen
    raise ValueError('Insufficient independent neighbour players')


def wilson(successes,n):
    z=1.95996398454; p=successes/n; denom=1+z*z/n
    centre=(p+z*z/(2*n))/denom
    width=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/denom
    return [float(centre-width),float(centre+width)]


def main():
    d=pd.read_csv(OUT/'expanded_mlb_validation.csv',dtype={'pitcher':str})
    report=json.loads((OUT/'expanded_mlb_study_report.json').read_text())
    transfer=json.loads((OUT/'nonimage_vb_spin_transfer_report.json').read_text())
    high=d.arm_angle.ge(60).to_numpy();checks={}
    assert not d.duplicated(['season','pitcher']).any()
    assert d.groupby('pitcher').split.nunique().max()==1
    assert d.groupby('pitcher').fold.nunique().max()==1
    source_angle=np.degrees(np.arctan2(d.release_ball_z-d.shoulder_z,
                      abs(d.relative_release_ball_x-d.relative_shoulder_x)))
    assert np.allclose(source_angle,d.angle_of_mean_points_deg,atol=1e-10)
    assert np.allclose(posture_angle(d,posture_targets(d)),source_angle,atol=1e-10)
    checks['unique_rows']=True;checks['whole_player_split_and_fold']=True;checks['source_coordinate_identity']=True
    coverage={};bias_intervals={}
    for family, result in report['validation'].items():
        error=d['oof_'+family].to_numpy()-d.arm_angle.to_numpy()
        assert abs(np.mean(abs(error))-result['whole_player_OOF']['overall']['mae_deg'])<1e-10
        assert abs(error[high].mean()-result['whole_player_OOF']['observed_60plus']['bias_deg'])<1e-10
        bias_intervals[family]=player_bootstrap(d.loc[high],error[high])
        cal=d.split.eq('calibration'); test=d.split.eq('test')
        scores=(d.loc[cal,'fixed_'+family]-d.loc[cal,'arm_angle']).abs().groupby(d.loc[cal,'pitcher']).max()
        radius=float(np.sort(scores)[int(np.ceil((len(scores)+1)*.9))-1])
        assert abs(radius-result['MLB_player_simultaneous_90pct_radius_deg'])<1e-10
        covered=(d.loc[test,'fixed_'+family]-d.loc[test,'arm_angle']).abs().le(radius)
        player_covered=covered.groupby(d.loc[test,'pitcher']).all()
        assert player_covered.mean()==result['fixed_test_player_all_seasons_coverage']
        coverage[family]={'independent_test_players':len(player_covered),
            'covered_players':int(player_covered.sum()),'observed_coverage':float(player_covered.mean()),
            'Wilson_95_interval':wilson(int(player_covered.sum()),len(player_covered)),'not_KBO_coverage':True}
    checks['metrics_independently_recomputed']=True;checks['independent_player_calibration_rank']=True
    pairs=[('oof_geometry','oof_movement_speed'),('oof_geometry','oof_movement_rpm_extension'),
        ('oof_optical_spin','oof_optical_spin_movement_extension'),
        ('oof_optical_spin_movement_extension','oof_posture_optical_spin_movement_extension'),
        ('qualified_train_oof_optical_spin_movement_extension','oof_optical_spin_movement_extension')]
    paired={}
    for before,after in pairs:
        improvement=abs(d[before]-d.arm_angle)-abs(d[after]-d.arm_angle)
        paired[before+' -> '+after]={'all':player_bootstrap(d,improvement),
                                  'observed60plus':player_bootstrap(d.loc[high],improvement[high]),
                                  'observed_below20':player_bootstrap(d.loc[d.arm_angle.lt(20)],improvement[d.arm_angle.lt(20)])}
    # Source means use a different valid-pitch denominator; retain its measured
    # discrepancy instead of presenting the two averages as numerically equal.
    checks['official_label_to_same_season_MLB_max_gap_deg']=float(abs(d.arm_angle-d.statcast_arm_angle).max())
    train=d.loc[d.split.eq('train')].reset_index(drop=True)
    tx=x_for(train,'optical_spin'); centre=tx.mean(axis=0);scale=tx.std(axis=0)
    scale=np.where(scale>1e-10,scale,1.); z=(tx-centre)/scale; ids=train.pitcher.to_numpy()
    squared=np.maximum(0,(z*z).sum(axis=1)[:,None]+(z*z).sum(axis=1)[None,:]-2*z@z.T)
    distance=np.sqrt(squared);distance[ids[:,None]==ids[None,:]]=np.inf
    fifth=np.array([distance[i,distinct_neighbours(distance[i],ids)[-1]] for i in range(len(train))])
    queries=[]
    for q in transfer['KBO_optical_input_scenarios']:
        if q['scope']!='2026_full':continue
        x=np.array(q['optical_query_features']); dist=np.linalg.norm(z-(x-centre)/scale,axis=1)
        neighbours=distinct_neighbours(dist,ids)
        overflow=np.maximum(np.maximum(tx.min(axis=0)-x,x-tx.max(axis=0)),0)
        queries.append({'pitcher_id':q['pitcher_id'],'assumed_axis_deg':q['assumed_axis_deg'],
            'fifth_distinct_player_distance':float(dist[neighbours[-1]]),
            'training_fifth_distance_percentile':float(np.mean(fifth<=dist[neighbours[-1]])*100),
            'maximum_standardized_univariate_overflow':float(np.max(overflow/scale)),
            'neighbours':train.iloc[neighbours][['pitcher','season','p_name_display_first_last','arm_angle',
                  'hawkeye_measured','active_spin','rel_height','rel_side']].to_dict('records'),
            'distance_is_diagnostic_not_OOD_probability':True})
    # Assess sensitivity to the single new near12h/99%/74deg training pitcher.
    influence=[]; keep=train.pitcher.ne('676720').to_numpy()
    for family in ['optical_spin','posture_optical_spin']:
        x=x_for(train,family); target=posture_targets(train) if family.startswith('posture_') else train.arm_angle.to_numpy()
        model=estimator().fit(x[keep],target[keep])
        for q in transfer['KBO_optical_input_scenarios']:
            if q['scope']!='2026_full':continue
            qx=np.array(q['optical_query_features']); p=np.asarray(model.predict(qx.reshape(1,-1)))
            if family.startswith('posture_'):
                prediction=float(np.degrees(np.arctan2(qx[1]-p[0,0],abs(qx[2]-p[0,1]))))
            else:prediction=float(p[0])
            influence.append({'family':family,'pitcher_id':q['pitcher_id'],'axis_deg':q['assumed_axis_deg'],
                'prediction_without_Tommy_Romero_deg':prediction,
                'change_vs_fixed_training_deg':prediction-q['estimates_deg'][family],
                'stress_test_not_model_selection':True})
    paddack=d.loc[d.pitcher.eq('663978'),['season','pitcher','arm_angle','split','oof_geometry',
        'oof_optical_spin_movement_extension','oof_posture_optical_spin_movement_extension']]
    paddack.to_csv(OUT/'expanded_paddack_OOF_check.csv',index=False)
    protected=['data/models','data/curated','seasons','data/tracking','web',
               'src/visualbaseball/estimated_arm_angle.py','src/visualbaseball/movement_calibration.py']
    changes=subprocess.check_output(['git','diff','--name-only','HEAD','--',*protected],cwd=ROOT,text=True)
    assert not changes.strip(); checks['protected_paths_have_no_tracked_changes']=True
    core=ROOT/'data/models/estimated_arm_angle_v1.json'
    head=subprocess.check_output(['git','show','HEAD:data/models/estimated_arm_angle_v1.json'],cwd=ROOT)
    assert core.read_bytes()==head;checks['production_model_matches_HEAD']=True
    save_json(OUT/'expanded_nonimage_verification.json',{'checks':checks,
        'high60_bias_intervals_MLB_only':bias_intervals,'paired_MAE_improvements':paired,
        'MLB_interval_coverage':coverage,'optical_scenario_joint_support':queries,
        'remove_new_high_slot_training_player_sensitivity':influence,
        'tests':'22 passed: spin_axis_ode,arm_angle_candidates,estimated_arm_angle,mlb_arm_candidate_collection',
        'input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in [OUT/'expanded_mlb_validation.csv',
             OUT/'expanded_mlb_study_report.json',OUT/'nonimage_vb_spin_transfer_report.json',core,Path(__file__).resolve()]}})
    print('Independent verification passed',json.dumps(paired,ensure_ascii=False),flush=True)
    print('Romero influence',json.dumps(influence,ensure_ascii=False),flush=True)
    plot(d,bias_intervals)


def plot(d,bias_intervals):
    import matplotlib;matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(12.5,5.2),gridspec_kw={'width_ratios':[1.2,1]})
    right=d.loc[d.pitch_hand.eq('R')].copy();right['clock_min']=(right.hawkeye_measured-180)/.5
    visible=right.loc[right.clock_min.between(-90,90)]
    axes[0].scatter(visible.clock_min,visible.arm_angle,s=14,color='#5f7b94',alpha=.35,label='RHP seasons')
    focus=visible.loc[visible.active_spin.ge(.985)]
    axes[0].scatter(focus.clock_min,focus.arm_angle,s=55,facecolors='none',edgecolors='#bb6c2f',marker='s',label='Optical active spin >=98.5%')
    axes[0].axvspan(-30,30,color='#777777',alpha=.08)
    axes[0].set(xlim=(-90,90),ylim=(-5,85),xlabel='Optical FF spin direction (clock)',ylabel='Observed all-pitch arm slot (deg)',
                title='Expanded MLB support, 2020–2024')
    axes[0].set_xticks([-90,-60,-30,0,30,60,90],['10:30','11:00','11:30','12:00','12:30','13:00','13:30'])
    axes[0].legend(loc='lower left',fontsize=9);axes[0].grid(alpha=.15)
    families=['geometry','movement_speed','movement_rpm_extension','optical_spin_movement_extension',
              'posture_optical_spin_movement_extension']
    labels=['Release + height','+ speed / IVB / HB','+ RPM / extension','Optical spin + movement','Predicted shoulder surrogate']
    for i,family in enumerate(families):
        r=bias_intervals[family];axes[1].errorbar(r['estimate'],i,
           xerr=[[r['estimate']-r['player_bootstrap_95_low']],[r['player_bootstrap_95_high']-r['estimate']]],
           fmt='o',color='#315775',capsize=3)
    axes[1].set_yticks(range(len(labels)),labels);axes[1].invert_yaxis();axes[1].axvline(0,color='#555555',ls=':',lw=1)
    axes[1].set(xlabel='Mean predicted − observed angle (deg)',title='Observed arm slot >=60°\n57 seasons / 35 players')
    axes[1].grid(axis='x',alpha=.15)
    fig.text(.02,.015,'Same 2,292 pitcher-seasons / 961 players. Whole-player OOF. Bars: 95% player bootstrap of mean MLB bias; not KBO intervals.',fontsize=9)
    fig.tight_layout(rect=(0,.055,1,1));fig.savefig(OUT/'expanded_nonimage_support_and_bias.png',dpi=170)
    fig.savefig(OUT/'expanded_nonimage_support_and_bias.svg')


if __name__=='__main__':main()
