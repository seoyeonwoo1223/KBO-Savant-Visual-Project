"""Test immediately available eAA feature families without production mutation."""
from __future__ import annotations

import argparse
from importlib.metadata import version
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from visualbaseball.arm_angle_calibration import metrics
from visualbaseball.arm_angle_candidates import ALL_FEATURES, FAMILIES, KEYS, aggregate_seasons, candidate_features, prepare_pitches
from visualbaseball.spin_axis_ode import FT_M, RUBBER_Y_M
from visualbaseball.trackman_arm_angle import digest, load_height_table
from visualbaseball.vb_arm_angle import conformal_radius, model_state

ROOT = Path(__file__).resolve().parents[2]
OPTIONS = ["geometry", "extension", "launch", "dispersion", "mix", "all"]
MIN_PITCHES = 100


def estimator():
    return make_pipeline(PolynomialFeatures(degree=2, include_bias=False), StandardScaler(), Ridge(alpha=10.))


def input_features(data, family, spin=False):
    x = candidate_features(data, family)
    if spin:
        phi = np.radians(data.movement_inferred.to_numpy(float))
        hand = data.pitcher_hand.map({"Right": 1., "Left": -1.}).to_numpy(float)
        x = np.column_stack([x, hand*np.sin(phi), -np.cos(phi), data.spin_rate.to_numpy(float)/2000,
                             data.ff_speed_m_s.to_numpy(float)/40])
    return x


def cluster_difference(data, baseline, prediction):
    improvement = (np.abs(np.asarray(baseline)-data.arm_angle)-np.abs(np.asarray(prediction)-data.arm_angle))
    grouped = improvement.groupby(data.pitcher).agg(['sum','count'])
    rng = np.random.default_rng(42)
    sampled = rng.integers(0,len(grouped),(2000,len(grouped)))
    draws = grouped['sum'].to_numpy()[sampled].sum(axis=1)/grouped['count'].to_numpy()[sampled].sum(axis=1)
    return {'mae_improvement_deg':float(improvement.mean()),'cluster_bootstrap_95_low_deg':float(np.quantile(draws,.025)),
            'cluster_bootstrap_95_high_deg':float(np.quantile(draws,.975)),'resamples':2000,'cluster':'whole pitcher'}


def select_inner(data, spin):
    if data.pitcher.nunique()<6:
        raise ValueError('Too few training pitchers for feature selection')
    y=data.arm_angle.to_numpy(float)
    folds=list(GroupKFold(n_splits=3,shuffle=True,random_state=17).split(data,y,data.pitcher))
    scores={}
    for family in OPTIONS:
        x=input_features(data,family,spin)
        p=np.full(len(data),np.nan)
        for train,test in folds:
            if set(data.pitcher.iloc[train]) & set(data.pitcher.iloc[test]):
                raise AssertionError('Inner pitcher leakage')
            p[test]=estimator().fit(x[train],y[train]).predict(x[test])
        scores[family]=float(np.mean(np.abs(p-y)))
    return min(OPTIONS,key=lambda f:scores[f]),scores


def validate_features(data, spin=False):
    data=data.sort_values(['pitcher','season']).reset_index(drop=True).copy()
    y=data.arm_angle.to_numpy(float)
    folds=list(GroupKFold(n_splits=5,shuffle=True,random_state=42).split(data,y,data.pitcher))
    reports={}; predictions={}; selected_predictions=np.full(len(data),np.nan); selections=[]
    for family in OPTIONS:
        x=input_features(data,family,spin);p=np.full(len(data),np.nan)
        for fold,(train,test) in enumerate(folds,1):
            if set(data.pitcher.iloc[train]) & set(data.pitcher.iloc[test]):
                raise AssertionError('Outer pitcher leakage')
            p[test]=estimator().fit(x[train],y[train]).predict(x[test])
            data.loc[test,'fold']=fold
        predictions[family]=p;data['oof_'+family]=p
        reports[family]={'group_cv':metrics(y,p),
                         'high_slot_60plus':metrics(y[y>=60],p[y>=60]),
                         'low_slot_below20':metrics(y[y<20],p[y<20])}
    for fold,(train,test) in enumerate(folds,1):
        family,inner_scores=select_inner(data.iloc[train].reset_index(drop=True),spin)
        x=input_features(data,family,spin)
        selected_predictions[test]=estimator().fit(x[train],y[train]).predict(x[test])
        selections.append({'fold':fold,'selected_family':family,'inner_scores':inner_scores,
                           'train_pitchers':int(data.iloc[train].pitcher.nunique()),'test_pitchers':int(data.iloc[test].pitcher.nunique())})
        data.loc[test,'selected_family']=family
    data['oof_selected']=selected_predictions
    reports['selected']={'group_cv':metrics(y,selected_predictions),
                         'high_slot_60plus':metrics(y[y>=60],selected_predictions[y>=60]),
                         'low_slot_below20':metrics(y[y<20],selected_predictions[y<20]),
                         'selection':'3 whole-pitcher inner folds, choose minimum MAE; no outer-test selection',
                         'fold_selections':selections}
    for family in list(OPTIONS)+['selected']:
        reports[family]['paired_improvement_vs_geometry']=cluster_difference(data,predictions['geometry'],data['oof_'+family])
        high=data.arm_angle.ge(60)
        reports[family]['high_slot_paired_improvement_vs_geometry']=cluster_difference(
            data.loc[high],predictions['geometry'][high],data.loc[high,'oof_'+family])
    train,calibration,test=[data.split.eq(s).to_numpy() for s in ['train','calibration','test']]
    selected,inner_scores=select_inner(data.loc[train].reset_index(drop=True),spin)
    x=input_features(data,selected,spin)
    model=estimator().fit(x[train],y[train]);p=model.predict(x)
    data['split_selected']=p
    radius,_=conformal_radius(p[calibration]-y[calibration],data.loc[calibration,'pitcher'])
    reports['split_selection']={'family':selected,'train_only_inner_scores':inner_scores,
       'test_metrics':metrics(y[test],p[test]),'reference_radius_90_deg':radius,
       'test_high_slot_rows':int((y[test]>=60).sum()),'fitted_model':model_state(model),
       'training_feature_min':x[train].min(axis=0).tolist(),'training_feature_max':x[train].max(axis=0).tolist()}
    report={'rows':len(data),'pitchers':int(data.pitcher.nunique()),'high_slot_seasons':int((y>=60).sum()),
            'high_slot_pitchers':int(data.loc[y>=60,'pitcher'].nunique()),'spin_baseline':spin,
            'models':reports,'target':'mean measured Statcast arm_angle of exactly the candidate-valid pitches',
            'specification':'Standardized degree-2 Ridge(alpha=10), fixed; same outer folds for every candidate; nested selection'}
    print('candidate validation', 'spin' if spin else 'geometry', json.dumps({f:round(reports[f]['group_cv']['mae_deg'],4) for f in list(OPTIONS)+['selected']}),flush=True)
    return model,selected,data,report


def mlb_inputs(input_dir,years):
    reference=pd.read_csv(ROOT/'analysis/arm_angle/results/eaa_mlb_split_validation.csv',dtype={'pitcher':str})
    frames,audits,hashes=[],[],{}
    for year in years:
        path=input_dir/f'statcast_candidates_{year}.parquet';manifest=json.loads((input_dir/f'statcast_candidates_{year}.json').read_text())
        hashes[str(year)]=digest(path)
        if hashes[str(year)]!=manifest['parquet_sha256']:
            raise ValueError('Statcast retained input digest mismatch')
        raw=pd.read_parquet(path);raw['season']=year
        subset=reference.loc[reference.season.eq(year),['pitcher','height_cm','pitcher_hand']].rename(columns={'pitcher_hand':'reference_hand'})
        raw=raw.merge(subset,on='pitcher',validate='many_to_one')
        raw['pitcher_hand']=raw.p_throws.map({'R':'Right','L':'Left'})
        raw['rel_side']=-raw.release_pos_x*FT_M;raw['rel_height']=raw.release_pos_z*FT_M
        raw['extension']=raw.release_extension*FT_M;raw['reference_y_m']=50*FT_M;raw['release_y_m']=raw.release_pos_y*FT_M
        for a,b in [('vx0','vx_m_s'),('vy0','vy_m_s'),('vz0','vz_m_s'),('ax','ax_m_s2'),('ay','ay_m_s2'),('az','az_m_s2')]:raw[b]=raw[a]*FT_M
        prepared=prepare_pitches(raw)
        hand_ok=prepared.pitcher_hand.eq(prepared.reference_hand)
        prepared['candidate_valid'] &= hand_ok & prepared.arm_angle.between(-90,90)
        seasons=aggregate_seasons(prepared)
        counts=raw.loc[hand_ok].groupby(KEYS).agg(raw_pitches=('pitcher','size'),raw_arm_labels=('arm_angle','count'))
        seasons=seasons.merge(counts.reset_index(),on=KEYS,validate='one_to_one')
        seasons['common_pitch_coverage']=seasons.n_pitches/seasons.raw_arm_labels
        seasons=seasons.loc[seasons.n_pitches.ge(MIN_PITCHES)&seasons.common_pitch_coverage.ge(.95)].copy()
        original=reference.loc[reference.season.eq(year)].rename(columns={'arm_angle':'leader_arm_angle','rel_height':'leader_rel_height','rel_side':'leader_rel_side'})
        extra=['season','pitcher','pitcher_hand','split','leader_arm_angle','leader_rel_height','leader_rel_side','p_name_display_first_last','reference_source_url','reference_source_sha256','height_source_url','height_source_sha256']
        seasons=seasons.merge(original[extra],on=KEYS,validate='one_to_one')
        seasons['arm_angle']=seasons.matched_pitch_arm_angle_deg
        label_gap=(seasons.arm_angle-seasons.leader_arm_angle).abs()
        audits.append({'season':year,'raw_pitches':len(raw),'common_valid_pitches':int(prepared.candidate_valid.sum()),
                       'hand_disagreement_pitches':int((~hand_ok).sum()),'season_rows':len(seasons),
                       'arm_label_reconciliation_median_abs_deg':float(label_gap.median()),'arm_label_reconciliation_p95_abs_deg':float(label_gap.quantile(.95)),
                       'release_height_reconciliation_median_abs_cm':float((seasons.rel_height-seasons.leader_rel_height).abs().median()*100),
                       'release_side_reconciliation_median_abs_cm':float((seasons.rel_side-seasons.leader_rel_side).abs().median()*100),
                       'capped_parent_requests_split':sum(s['capped'] for s in manifest['source_requests']),
                       'uncapped_source_requests':sum(not s['capped'] for s in manifest['source_requests'])})
        frames.append(seasons)
        print('MLB candidate inputs',json.dumps(audits[-1]),flush=True)
    data=pd.concat(frames,ignore_index=True)
    if data.duplicated(KEYS).any() or not np.isfinite(data[ALL_FEATURES]).all().all():
        raise ValueError('Nonunique or incomplete candidate seasons')
    return data,audits,hashes


def kbo_inputs(matched_dir):
    prior=json.loads((ROOT/'analysis/arm_angle/results/ode_study_report.json').read_text())['matched_pitch_hashes']
    bio=pd.read_parquet(ROOT/'data/curated/players/player_bio.parquet');heights=load_height_table(ROOT/'data/tracking/player_heights.csv',bio)
    lookup=bio[['player_id','player_name','throws']].merge(heights[['player_id','height_cm']],on='player_id',how='left',validate='one_to_one')
    lookup=lookup.rename(columns={'player_id':'pitcher','player_name':'bio_name'})
    lookup['bio_hand']=lookup.throws.map({'R':'Right','L':'Left'})
    frames,audits,hashes=[],[],{}
    for year in range(2019,2025):
        path=matched_dir/f'matched_{year}.parquet';hashes[str(year)]=digest(path)
        if hashes[str(year)]!=prior[f'matched_{year}']:
            raise ValueError('KBO matched input differs from the audited ODE study')
        columns=['pitch_id','pitcher_id','pitcher_name','pitcher_hand','stadium','trajectory_valid','pitch_type','rel_side','rel_height','extension','x0','y0','z0','vx0','vy0','vz0','ax','ay','az']
        raw=pd.read_parquet(path,columns=columns).rename(columns={'pitcher_id':'pitcher'});raw['season']=year
        raw=raw.merge(lookup,on='pitcher',how='left',validate='many_to_one')
        raw['reference_y_m']=raw.y0*FT_M;raw['release_y_m']=RUBBER_Y_M-raw.extension
        for a,b in [('vx0','vx_m_s'),('vy0','vy_m_s'),('vz0','vz_m_s'),('ax','ax_m_s2'),('ay','ay_m_s2'),('az','az_m_s2')]:raw[b]=raw[a]*FT_M
        prepared=prepare_pitches(raw)
        identity_ok=prepared.pitcher_name.eq(prepared.bio_name)&prepared.pitcher_hand.eq(prepared.bio_hand)
        prepared['candidate_valid'] &= identity_ok & prepared.trajectory_valid.fillna(False)&prepared.y0.isin([50.,55.])
        seasons=aggregate_seasons(prepared);seasons=seasons.loc[seasons.n_pitches.ge(MIN_PITCHES)].copy()
        names=prepared.groupby(KEYS).pitcher_name.first().reset_index()
        seasons=seasons.merge(names,on=KEYS,validate='one_to_one')
        seasons['source_status']='TrackMan release/extension + matched VB initial direction; KBO arm-angle labels unavailable'
        frames.append(seasons)
        audits.append({'season':year,'matched_pitches':len(raw),'common_valid_pitches':int(prepared.candidate_valid.sum()),'season_rows':len(seasons),
                       'stadiums':sorted(prepared.loc[prepared.candidate_valid,'stadium'].dropna().unique().tolist())})
    return pd.concat(frames,ignore_index=True),audits,hashes


def apply_kbo(models,kbo,spin_kbo=None):
    outputs=[]
    for spin,model,family,training in models:
        data=kbo.copy()
        if spin:
            data=data.merge(spin_kbo,on=KEYS,validate='one_to_one')
            data['movement_inferred']=data.axis_deg
        x=input_features(data,family,spin);domain=input_features(training.loc[training.split.eq('train')],family,spin)
        outside=((x<domain.min(axis=0))|(x>domain.max(axis=0))).any(axis=1)
        finite=np.isfinite(x).all(axis=1);p=np.full(len(data),np.nan);p[finite]=model.predict(x[finite])
        eligible=finite&~outside&(np.abs(p)<=90)
        if spin:eligible&=data.fit_eligible.fillna(False).to_numpy()
        data['selected_family']=family;data['baseline_kind']='spin' if spin else 'geometry';data['raw_selected_eaa_deg']=p
        data['selected_eaa_deg']=np.where(eligible,p,np.nan);data['outside_training_domain']=outside
        train=training.loc[training.split.eq('train')]
        baseline=estimator().fit(input_features(train,'geometry',spin),train.arm_angle)
        bx=input_features(data,'geometry',spin);bf=np.isfinite(bx).all(axis=1);b=np.full(len(data),np.nan)
        b[bf]=baseline.predict(bx[bf]);data['same_sample_baseline_eaa_deg']=b
        data['change_vs_baseline_deg']=np.where(eligible,p-b,np.nan)
        data['status']='research_KBO_unvalidated';data['KBO_error_range_status']='unavailable_no_measured_KBO_labels'
        outputs.append(data)
    return pd.concat(outputs,ignore_index=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir',type=Path,default=ROOT/'.cache/arm_angle/candidates')
    parser.add_argument('--seasons',type=int,nargs='+',default=[2020,2021,2022,2023,2024])
    parser.add_argument('--out',type=Path,default=ROOT/'analysis/arm_angle/results')
    args=parser.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    mlb,audits,hashes=mlb_inputs(args.input_dir,args.seasons)
    source_manifest={str(year):json.loads((args.input_dir/f'statcast_candidates_{year}.json').read_text()) for year in args.seasons}
    source_path=args.out/'candidate_statcast_source_manifest.json'
    source_path.write_text(json.dumps(source_manifest,indent=2)+'\n')
    mlb.to_csv(args.out/'candidate_mlb_season_inputs.csv',index=False)
    model,family,scored,main_report=validate_features(mlb)
    scored.to_csv(args.out/'candidate_mlb_validation.csv',index=False)
    spin=pd.read_csv(ROOT/'analysis/arm_angle/results/ode_mlb_spin_reference.csv',dtype={'player_id':str}).rename(columns={'player_id':'pitcher'})
    spin=spin.rename(columns={'release_speed':'ff_speed_mph'})
    spin=spin[['season','pitcher','movement_inferred','spin_rate','ff_speed_mph']]
    spin['ff_speed_m_s']=pd.to_numeric(spin.ff_speed_mph)*.44704
    with_spin=mlb.merge(spin,on=['season','pitcher'],validate='one_to_one')
    smodel,sfamily,sscore,spin_report=validate_features(with_spin,True)
    sscore.to_csv(args.out/'candidate_mlb_spin_validation.csv',index=False)
    kbo,kaudits,khashes=kbo_inputs(ROOT/'.cache/arm_angle/vb_bridge/matched')
    kbo.to_csv(args.out/'candidate_kbo_season_inputs.csv',index=False)
    ode=pd.read_csv(ROOT/'analysis/arm_angle/results/ode_kbo_fastball_seasons.csv',dtype={'pitcher_id':str}).rename(columns={'pitcher_id':'pitcher'})
    ode=ode[KEYS+['axis_deg','spin_rate','rel_speed','fit_eligible']].copy();ode['ff_speed_m_s']=ode.rel_speed/3.6
    applied=apply_kbo([(False,model,family,scored),(True,smodel,sfamily,sscore)],kbo,ode)
    applied.to_csv(args.out/'candidate_kbo_eaa_comparison.csv',index=False)
    report={'scientific_status':'Research-only; MLB pitch-matched observed angles; KBO angle accuracy unverified',
        'features':FAMILIES,'minimum_pitches':MIN_PITCHES,'minimum_common_label_coverage':.95,
        'label':'Per-pitch Statcast arm_angle, aggregated over exactly the common valid candidate pitches',
        'velocity_plane':'Statcast vx0/vy0/vz0 at y=50ft confirmed in official CSV docs; extrapolated to observed release_pos_y per pitch. VB uses its actual y0.',
        'MLB_input_audits':audits,'KBO_input_audits':kaudits,'geometry_validation':main_report,'spin_validation':spin_report,
        'KBO_estimates':{str(key):{'rows':len(g),'eligible':int(g.selected_eaa_deg.notna().sum()),'selected_family':str(g.selected_family.iloc[0]),
             'median_change_deg':float(g.change_vs_baseline_deg.median())} for key,g in applied.groupby('baseline_kind')},
        'input_hashes':{'MLB_retained_parquet':hashes,'KBO_matched_parquet':khashes,
                       'MLB_source_manifest':digest(source_path),
                       'height_table':digest(ROOT/'data/tracking/player_heights.csv'),'MLB_reference':digest(ROOT/'analysis/arm_angle/results/eaa_mlb_split_validation.csv'),
                       'MLB_spin':digest(ROOT/'analysis/arm_angle/results/ode_mlb_spin_reference.csv'),
                       'KBO_ODE_features':digest(ROOT/'analysis/arm_angle/results/ode_kbo_fastball_seasons.csv')},
        'code_hashes':{'features':digest(ROOT/'src/visualbaseball/arm_angle_candidates.py'),'study':digest(Path(__file__)),'collector':digest(ROOT/'scripts/collect_mlb_arm_candidates.py')},
        'limitations':['Qualified MLB reference pitchers, not all pitchers','Individual candidate comparisons are exploratory; nested selection avoids choosing on outer tests',
                       'High-slot sample is small; repeated seasons remain clustered by pitcher','KBO flight directions come from VB while release/extension are TM',
                       'FF spin inputs are separate same-season summaries; not exactly the candidate-valid labeled pitch population',
                       'Dispersion and mix do not measure shoulder or torso','No matched optical KBO arm-angle labels; no finite validated KBO intervals',
                       'No measured TrackMan extension for Gwangju or 2025–2026; no arbitrary extension imputation'],
        'runtime':{'python':sys.version.split()[0],**{p:version(p) for p in ['numpy','pandas','scipy','scikit-learn','pyarrow']}}}
    (args.out/'candidate_study_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps(report['KBO_estimates'],ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
