"""Reproduce reviewed image-angle proxies without publishing/calibrating eAA."""
from pathlib import Path
import csv
import hashlib
import json
import statistics

import cv2

from visualbaseball.video_arm_projection import image_angle_box

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/arm_angle/results'
CACHE = ROOT / '.cache/arm_angle/video/angle-reviewed'


def main():
    labels_path = OUT / 'video_arm_manual_annotations.json'
    sources_path = OUT / 'video_actual_pilot_report.json'
    labels = json.loads(labels_path.read_text())
    sources = {r['drive_id']: r for r in json.loads(sources_path.read_text())['sources']}
    CACHE.mkdir(parents=True, exist_ok=True)
    rows = []
    for label in labels['rows']:
        source = sources[label['drive_id']]
        path = Path(source['original_path'])
        if hashlib.sha256(path.read_bytes()).hexdigest() != label['source_sha256']:
            raise ValueError('Reviewed original changed')
        poses_path = Path(source['output_directory']) / 'pose_keypoints.jsonl'
        poses = {r['frame_index']: r for r in map(json.loads, poses_path.read_text().splitlines())}
        pose = poses[label['frame_index']]
        shoulder = pose['landmarks'][label['shoulder_index']]
        result = image_angle_box(shoulder[:2], label['ball_xy'], label['shoulder_error_xy'],
                                 label['ball_error_xy'], roll_scenario_deg=label['roll_scenario_deg'])
        row = dict(label, **result, shoulder_xy=shoulder[:2],
                   shoulder_visibility=shoulder[2], shoulder_presence=shoulder[3],
                   timestamp_ms=pose['timestamp_ms'], original_name=source['original_name'],
                   original_path=str(path),
                   footage_year_candidate=int(source['original_name'][:4]) if source['original_name'][:4].isdigit() else None,
                   target='Savant frontal shoulder-to-ball angle; image proxy with unverified projection',
                   calibrated_release_frame=False, eligible_for_model_calibration=False,
                   pose_keypoints_sha256=hashlib.sha256(poses_path.read_bytes()).hexdigest())
        cap = cv2.VideoCapture(str(path)); cap.set(cv2.CAP_PROP_POS_FRAMES, label['frame_index'])
        ok, frame = cap.read(); cap.release()
        if not ok: raise ValueError('Reviewed frame unavailable')
        row['decoded_frame_sha256'] = hashlib.sha256(frame.tobytes()).hexdigest()
        sx, sy = map(round, shoulder[:2]); bx, by = map(round, label['ball_xy'])
        for point, error, color in [(shoulder[:2], label['shoulder_error_xy'], (0, 220, 255)),
                                     (label['ball_xy'], label['ball_error_xy'], (255, 160, 0))]:
            x, y = map(round, point); ex, ey = map(round, error)
            cv2.rectangle(frame, (x-ex, y-ey), (x+ex, y+ey), color, 2)
            cv2.circle(frame, (x, y), 4, color, -1)
        cv2.line(frame, (sx, sy), (bx, by), (220, 0, 220), 2)
        cv2.line(frame, (min(sx, bx)-20, sy), (max(sx, bx)+20, sy), (0, 220, 255), 1)
        lo, hi = row['coordinate_scenario_low_deg'], row['coordinate_scenario_high_deg']
        caption = f"IMAGE PROXY {row['image_angle_deg']:.1f} deg | pixel/roll {lo:.1f}..{hi:.1f} | NOT calibrated arm slot"
        cv2.putText(frame, caption, (12, 28), cv2.FONT_HERSHEY_SIMPLEX,
                    .42 if frame.shape[1] < 800 else .7, (0, 255, 255), 1, cv2.LINE_AA)
        image_path = CACHE / f"{label['drive_id']}-{label['frame_index']}-annotated.jpg"
        cv2.imwrite(str(image_path), frame)
        row['annotated_frame'] = str(image_path)
        row['annotated_frame_sha256'] = hashlib.sha256(image_path.read_bytes()).hexdigest()
        rows.append(row)
    players = []
    for player in sorted({r['player'] for r in rows}):
        eligible = [r for r in rows if r['player'] == player and r['eligible_for_frontal_approximation']]
        players.append({'player': player, 'reviewed_source_frames': sum(r['player'] == player for r in rows),
                        'frontal_approximation_source_frames': len(eligible),
                        'image_proxy_median_deg': statistics.median(r['image_angle_deg'] for r in eligible) if eligible else None,
                        'coordinate_scenario_low_deg': min(r['coordinate_scenario_low_deg'] for r in eligible) if eligible else None,
                        'coordinate_scenario_high_deg': max(r['coordinate_scenario_high_deg'] for r in eligible) if eligible else None,
                        'scope': 'Selected image projections, not an independent-pitch or pitcher-season mean',
                        'calibrated_Savant_angle_deg': None,
                        'camera_and_missed_release_uncertainty_included': False,
                        'eligible_for_model_calibration': False})
    report = {'scope': 'Image-based provisional eAA proxies; no calibrated Savant arm-angle truth',
              'reference_angles_used_to_place_points': labels['reference_angles_used_to_place_points'],
              'reviewer': 'Codex visual inspection; localization errors are subjective scenario boxes',
              'manually_reviewed_source_frames': len(rows), 'calibrated_Savant_angles_generated': 0,
              'excluded_reviewed_frames': labels.get('excluded_reviewed_frames', []),
              'reviewed_source_frames_total': labels.get('reviewed_source_frames_total', len(rows)),
              'sources': rows, 'players': players,
              'input_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [labels_path, sources_path]}}
    (OUT / 'video_arm_estimates.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    with (OUT / 'video_arm_estimates.csv').open('w') as f:
        keys = ['player','pitcher_id','drive_id','frame_index','image_angle_deg',
                'coordinate_scenario_low_deg','coordinate_scenario_high_deg',
                'eligible_for_frontal_approximation','camera_view','timing_status',
                'calibrated_Savant_angle_deg','eligible_for_model_calibration']
        writer = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    print(json.dumps(players, ensure_ascii=False))


if __name__ == '__main__': main()
