"""Offline, reproducible ODE / eAA feature study; no production files are written."""
from __future__ import annotations

import argparse
from dataclasses import asdict
from importlib.metadata import version
import json
from pathlib import Path
import sys
import time

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

from visualbaseball.arm_angle_calibration import features, metrics
from visualbaseball.spin_axis_ode import (
    Environment, FT_M, G, PLATE_FRONT_Y_M, RUBBER_Y_M,
    fit_inverse, time_to_plane,
)
from visualbaseball.trackman_arm_angle import digest, load_height_table
from visualbaseball.vb_arm_angle import conformal_radius, model_state

ROOT = Path(__file__).resolve().parents[2]
KEYS = ["season", "pitcher_id", "pitcher_name", "pitcher_hand"]
TRAJ = ["x0", "y0", "z0", "vx0", "vy0", "vz0", "ax", "ay", "az"]
TM = ["spin_rate", "induced_vert_break", "horz_break", "extension", "rel_height", "rel_side", "rel_speed", "zone_speed"]
MIN_FF = 100
MODEL_NAMES = ["geometry", "geometry_direction", "geometry_direction_spin_speed"]


def numeric_plane_times(data, target_y_m):
    y0, vy, ay = [data[c].to_numpy(float)*FT_M for c in ["y0", "vy0", "ay"]]
    target = np.broadcast_to(np.asarray(target_y_m, float), y0.shape)
    return time_to_plane(y0, vy, ay, target)


def prepare_physics(data):
    """Use TM actual extension plane, not VB's raw 50/55 ft timestamp."""
    data = data.copy()
    for c in TRAJ+TM:
        data[c] = pd.to_numeric(data[c], errors="coerce")
    y_release = RUBBER_Y_M-data.extension.to_numpy(float)
    start = numeric_plane_times(data, y_release)
    finish = numeric_plane_times(data, PLATE_FRONT_Y_M)
    velocity = (data[["vx0", "vy0", "vz0"]].to_numpy(float)
                + data[["ax", "ay", "az"]].to_numpy(float)*start[:, None])*FT_M
    with np.errstate(invalid="ignore", divide="ignore"):
        unit = velocity/np.linalg.norm(velocity, axis=1)[:, None]
    velocity = unit*(data.rel_speed.to_numpy(float)/3.6)[:, None]
    data["flight_time_s"] = finish-start
    data["initial_y_m"] = y_release
    data[["initial_vx_m_s", "initial_vy_m_s", "initial_vz_m_s"]] = velocity
    # Movement in TM is opposite catcher-view x, as established by paired data.
    data["observed_hb_m"] = -data.horz_break/100
    data["observed_ivb_m"] = data.induced_vert_break/100
    phi = np.arctan2(-data.observed_hb_m, -data.observed_ivb_m)
    data["tm_movement_axis_deg"] = np.degrees(phi) % 360
    data["tm_axis_sin"] = np.sin(phi)
    data["tm_axis_cos"] = np.cos(phi)
    midway = (start+finish)/2
    v_mid = (data[["vx0", "vy0", "vz0"]].to_numpy(float)
             + data[["ax", "ay", "az"]].to_numpy(float)*midway[:, None])*FT_M
    a = data[["ax", "ay", "az"]].to_numpy(float)*FT_M
    with np.errstate(invalid="ignore", divide="ignore"):
        direction = v_mid/np.linalg.norm(v_mid, axis=1)[:, None]
        aero = a+np.array([0., 0., G])
        transverse = aero-(aero*direction).sum(axis=1)[:, None]*direction
        axis = np.cross(direction, transverse)
        axis /= np.linalg.norm(axis, axis=1)[:, None]
    data["vb_force_axis_deg"] = np.degrees(np.arctan2(-axis[:, 2], axis[:, 0])) % 360
    needed = TRAJ+TM+["flight_time_s", "initial_vx_m_s", "initial_vy_m_s", "initial_vz_m_s"]
    finite = np.isfinite(data[needed]).all(axis=1)
    valid = (finite & data.trajectory_valid.fillna(False) & data.y0.isin([50., 55.])
             & data.vy0.lt(0)
             & data.spin_rate.between(100, 5000) & data.extension.between(.5, 3)
             & data.rel_speed.between(70, 180) & data.zone_speed.between(60, 170)
             & data.zone_speed.lt(data.rel_speed) & data.rel_height.between(.05, 2.7)
             & data.rel_side.between(-2, 2) & data.flight_time_s.between(.25, .8)
             & data.horz_break.abs().le(100) & data.induced_vert_break.abs().le(140)
             & data.pitcher_hand.isin(["Right", "Left"]))
    data["physics_valid"] = valid
    # Early exports use Fastball rather than Four-Seam; VB must also call it FF.
    data["is_ff"] = data.pitch_type.eq("4-Seam Fastball") & data.auto_pitch_type.isin(["Four-Seam", "Fastball"])
    return data


def fit_row(row, environment=Environment()):
    result = fit_inverse([-row.rel_side, row.initial_y_m, row.rel_height],
                         [row.initial_vx_m_s, row.initial_vy_m_s, row.initial_vz_m_s],
                         row.flight_time_s, row.spin_rate, row.observed_hb_m,
                         row.observed_ivb_m, row.zone_speed/3.6, environment)
    if result["status"] == "fitted":
        result["closure_pass"] = (abs(result["hb_closure_error_cm"]) <= 2
                                  and abs(result["ivb_closure_error_cm"]) <= 2
                                  and abs(result["speed_closure_error_kmh"]) <= 1)
        result["plane_pass"] = abs(result["plate_y_error_cm"]) <= 10
        result["fit_eligible"] = result["closure_pass"] and result["plane_pass"] and not result["spin_fraction_at_boundary"]
    else:
        result["fit_eligible"] = False
    return result


def build_kbo_inputs(root, matched_dir, cache):
    bio = pd.read_parquet(root / "data/curated/players/player_bio.parquet")
    heights = load_height_table(root / "data/tracking/player_heights.csv", bio)
    lookup = bio[["player_id", "player_name", "throws"]].merge(heights[["player_id", "height_cm"]], on="player_id", how="left")
    lookup = lookup.rename(columns={"player_id": "pitcher_id", "player_name": "bio_name"})
    lookup["bio_hand"] = lookup.throws.map({"R": "Right", "L": "Left"})
    aggregates, geometric, samples, audits, hashes = [], [], [], [], {}
    bridge_report = json.loads((root / "analysis/arm_angle/results/eaa_bridge_report.json").read_text())
    prior = bridge_report.get("input_hashes", {})
    rng = np.random.default_rng(42)
    for year in range(2019, 2025):
        path = matched_dir / f"matched_{year}.parquet"
        hashes[f"matched_{year}"] = digest(path)
        if f"matched_{year}" in prior and prior[f"matched_{year}"] != hashes[f"matched_{year}"]:
            raise ValueError("Matched input changed since validated VB bridge; rerun matching audit")
        columns = list(dict.fromkeys(["pitch_id", "game_id", "pitcher_id", "pitcher_name", "pitcher_hand", "stadium",
                   "pitch_type", "auto_pitch_type", "trajectory_valid", "arrival_time_s"]+TRAJ+TM))
        raw = pd.read_parquet(path, columns=columns)
        if raw.pitch_id.duplicated().any():
            raise ValueError("Duplicate matched pitch ID")
        raw["season"] = year
        raw = raw.merge(lookup, on="pitcher_id", how="left", validate="many_to_one")
        identity_ok = raw.pitcher_name.eq(raw.bio_name) & raw.pitcher_hand.eq(raw.bio_hand) & raw.height_cm.between(140, 220)
        # All-pitch geometry and FF physics have deliberately distinct denominators.
        geom_ok = identity_ok & raw.rel_height.between(.05, 2.7) & raw.rel_side.between(-2, 2)
        geometric.append(raw.loc[geom_ok].groupby(KEYS).agg(
            n_geometry=("pitch_id", "size"), rel_height=("rel_height", "mean"),
            rel_side=("rel_side", "mean"), height_cm=("height_cm", "first")).reset_index())
        prepared = prepare_physics(raw)
        valid = prepared.loc[prepared.physics_valid].copy()
        selected = valid.loc[valid.is_ff & identity_ok.loc[valid.index]].copy()
        numeric = ["initial_y_m", "initial_vx_m_s", "initial_vy_m_s", "initial_vz_m_s", "flight_time_s",
                   "observed_hb_m", "observed_ivb_m", "spin_rate", "zone_speed", "rel_speed", "extension",
                   "rel_height", "rel_side", "tm_axis_sin", "tm_axis_cos"]
        groups = selected.groupby(KEYS).agg({c: "mean" for c in numeric})
        groups["n_ff"] = selected.groupby(KEYS).size()
        groups = groups.reset_index().loc[lambda d: d.n_ff.ge(MIN_FF)]
        groups["ff_taxonomy"] = "VB_FF_and_TM_Fastball" if year < 2022 else "VB_FF_and_TM_Four-Seam"
        aggregates.append(groups)
        # Balanced individual-pitch ODE audit: 20 per VB pitch type and season.
        for kind, part in valid.groupby("pitch_type", dropna=False):
            take = part.iloc[rng.choice(len(part), min(20, len(part)), replace=False)].copy()
            take["sample_pitch_type"] = str(kind)
            take["sample_purpose"] = "balanced_type_audit"
            samples.append(take)
        # Compare angle-of-mean inversion with a circular mean of inversions on
        # the SAME 15 FF pitches, not unmatched full-season / sampled estimates.
        for group in groups.sort_values("tm_axis_sin").iloc[np.unique(np.linspace(0, len(groups)-1, 6, dtype=int))].itertuples():
            part = selected.loc[selected.pitcher_id.eq(group.pitcher_id)]
            take = part.iloc[rng.choice(len(part), 15, replace=False)].copy()
            take["sample_pitch_type"] = "4-Seam Fastball"
            take["sample_purpose"] = "same_pitches_aggregation"
            samples.append(take)
        audits.append({"season": year, "matched": len(raw), "physics_valid": len(valid),
                       "valid_ff": len(selected), "ff_seasons_at_least_100": len(groups),
                       "height_or_identity_excluded": int((~identity_ok).sum()),
                       "stadiums": sorted(valid.stadium.dropna().unique().tolist()),
                       "valid_flight_time_median_s": float(valid.flight_time_s.median()),
                       "raw_arrival_time_median_s": float(valid.arrival_time_s.median())})
        print(json.dumps(audits[-1], ensure_ascii=False), flush=True)
    ff = pd.concat(aggregates, ignore_index=True)
    geom = pd.concat(geometric, ignore_index=True)
    individual = pd.concat(samples, ignore_index=True)
    ff.to_parquet(cache / "ff_season_inputs.parquet", index=False)
    geom.to_parquet(cache / "geometry_inputs.parquet", index=False)
    individual.to_parquet(cache / "individual_inputs.parquet", index=False)
    return ff, geom, individual, audits, hashes


def study_features(data, name):
    x = features(data)
    if name == "geometry":
        return x
    phi = np.radians(data.movement_inferred.to_numpy(float))
    hand = data.pitcher_hand.map({"Right": 1., "Left": -1.}).to_numpy(float)
    x = np.column_stack([x, hand*np.sin(phi), -np.cos(phi)])
    if name == "geometry_direction_spin_speed":
        x = np.column_stack([x, data.spin_rate.to_numpy(float)/2000,
                             data.ff_speed_m_s.to_numpy(float)/40])
    return x


def estimator():
    return make_pipeline(PolynomialFeatures(degree=2, include_bias=False), StandardScaler(), Ridge(alpha=10.))


def cluster_improvement(data, base, augmented):
    improvement = (data[base]-data.arm_angle).abs()-(data[augmented]-data.arm_angle).abs()
    clusters = improvement.groupby(data.pitcher).agg(["sum", "count"])
    rng = np.random.default_rng(42)
    sampled = rng.integers(0, len(clusters), (2000, len(clusters)))
    boot = clusters['sum'].to_numpy()[sampled].sum(axis=1)/clusters['count'].to_numpy()[sampled].sum(axis=1)
    return {"paired_mae_improvement_deg": float(improvement.mean()),
            "cluster_bootstrap_95_low_deg": float(np.quantile(boot, .025)),
            "cluster_bootstrap_95_high_deg": float(np.quantile(boot, .975)),
            "unit": "entire pitcher, all seasons retained", "resamples": 2000}


def validate_arm_features(root, reference_path, output):
    reference = pd.read_csv(root / "analysis/arm_angle/results/eaa_mlb_split_validation.csv", dtype={"pitcher": str})
    spin = pd.read_csv(reference_path, dtype={"player_id": str})
    data = reference.merge(spin.rename(columns={"player_id": "pitcher"}), on=["pitcher", "season"],
                           suffixes=("", "_ff"), validate="one_to_one")
    if not data.pitch_hand.eq(data.pitch_hand_ff).all():
        raise ValueError("MLB hand mismatch")
    data["ff_speed_m_s"] = pd.to_numeric(data.release_speed)*.44704
    needed = ["movement_inferred", "spin_rate", "ff_speed_m_s"]
    valid = np.isfinite(data[needed]).all(axis=1) & data.n_pitches_ff.ge(MIN_FF)
    excluded = int((~valid).sum())
    data = data.loc[valid].reset_index(drop=True)
    y = data.arm_angle.to_numpy(float)
    folds = GroupKFold(n_splits=5, shuffle=True, random_state=42)
    reports, models = {}, {}
    for name in MODEL_NAMES:
        x = study_features(data, name)
        prediction = np.zeros(len(data))
        for fold, (train, test) in enumerate(folds.split(x, y, data.pitcher), 1):
            if set(data.pitcher.iloc[train]) & set(data.pitcher.iloc[test]):
                raise AssertionError("Pitcher leakage")
            prediction[test] = estimator().fit(x[train], y[train]).predict(x[test])
            data.loc[test, "fold"] = fold
        data[f"oof_{name}"] = prediction
        train, calibration, test = [data.split.eq(s) for s in ["train", "calibration", "test"]]
        model = estimator().fit(x[train], y[train])
        models[name] = model
        deployed = model.predict(x)
        data[f"split_{name}"] = deployed
        radius, _ = conformal_radius(deployed[calibration]-y[calibration], data.loc[calibration, "pitcher"])
        reports[name] = {"group_cv": metrics(y, prediction), "split_test": metrics(y[test], deployed[test]),
                         "reference_radius_90_deg": radius,
                         "group_cv_by_slot": {str(slot): metrics(part.arm_angle, part[f"oof_{name}"])
                             for slot, part in data.groupby(pd.cut(data.arm_angle, [-91, 0, 20, 40, 60, 91], right=False), observed=True)},
                         "fitted_model": model_state(model), "training_feature_min": x[train].min(axis=0).tolist(),
                         "training_feature_max": x[train].max(axis=0).tolist()}
        print(name, json.dumps(reports[name]["group_cv"]), flush=True)
    improvement = {name: cluster_improvement(data, "oof_geometry", f"oof_{name}") for name in MODEL_NAMES[1:]}
    phi = np.radians(data.movement_inferred.to_numpy(float))
    naive = np.degrees(np.arctan2(-np.cos(phi), np.abs(np.sin(phi))))
    data["naive_force_direction_as_arm_deg"] = naive
    optical_gap = (data.hawkeye_measured-data.movement_inferred+180)%360-180
    report = {"rows": len(data), "pitchers": int(data.pitcher.nunique()), "excluded": excluded,
              "label": "Savant observed all-pitch pitcher-season arm angle",
              "spin_input": "official movement-inferred FF direction, NOT optical axis",
              "splits": {s: {"rows": len(g), "pitchers": int(g.pitcher.nunique()),
                              "high_slot_rows_60plus": int(g.arm_angle.ge(60).sum())} for s, g in data.groupby("split")},
              "models": reports, "paired_improvements": improvement,
              "naive_force_direction_as_arm": metrics(y, naive),
              "optical_vs_movement_ff_axis": {"n": len(data), "median_abs_gap_deg": float(optical_gap.abs().median()),
                                              "abs_gap_p90_deg": float(optical_gap.abs().quantile(.9))},
              "specification": "Degree-2 standardized Ridge(alpha=10), fixed before this comparison; five whole-pitcher folds seed=42",
              "interpretation": "Validation of feature information in MLB, not validation of KBO ODE axis or KBO arm angle"}
    data.to_csv(output / "ode_mlb_feature_validation.csv", index=False)
    return models, data, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--matched-dir", type=Path, default=ROOT / ".cache/arm_angle/vb_bridge/matched")
    parser.add_argument("--spin-reference", type=Path, default=ROOT / ".cache/arm_angle/ode/mlb_fastball_spin_reference.csv")
    parser.add_argument("--out", type=Path, default=ROOT / "analysis/arm_angle/results")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    # Preserve the exact authorized external input so the companion notebook
    # remains usable without a local download cache or fresh network access.
    (args.out / "ode_mlb_spin_reference.csv").write_bytes(args.spin_reference.read_bytes())
    cache = ROOT / ".cache/arm_angle/ode"
    cache.mkdir(parents=True, exist_ok=True)
    ff, geom, sample, audits, hashes = build_kbo_inputs(ROOT, args.matched_dir, cache)
    models, reference, arm_report = validate_arm_features(ROOT, args.spin_reference, args.out)
    started = time.monotonic()
    fits = []
    for i, row in enumerate(ff.itertuples(index=False)):
        fits.append(fit_row(row))
        if (i+1) % 100 == 0:
            print(f"ODE FF seasons: {i+1}/{len(ff)}, {time.monotonic()-started:.1f}s", flush=True)
    fitted = pd.concat([ff, pd.DataFrame(fits)], axis=1)
    fitted.to_csv(args.out / "ode_kbo_fastball_seasons.csv", index=False)
    sample_fits = []
    for i, row in enumerate(sample.itertuples(index=False)):
        sample_fits.append(fit_row(row))
        if (i+1) % 100 == 0:
            print(f"ODE individual audit: {i+1}/{len(sample)}", flush=True)
    sample_result = pd.concat([sample.reset_index(drop=True), pd.DataFrame(sample_fits)], axis=1)
    sample_result.to_parquet(cache / "individual_results.parquet", index=False)
    sample_columns = KEYS+["pitch_id", "stadium", "sample_pitch_type", "sample_purpose", "flight_time_s", "spin_rate",
                           "observed_hb_m", "observed_ivb_m", "vb_force_axis_deg"]+list(pd.DataFrame(sample_fits).columns)
    sample_result[sample_columns].to_csv(args.out / "ode_kbo_individual_audit.csv", index=False)
    aggregation_rows = []
    for key, part in sample_result.loc[sample_result.sample_purpose.eq("same_pitches_aggregation")].groupby(KEYS):
        averaged = part.select_dtypes(include="number").mean()
        mean_fit = fit_row(averaged)
        good = part.loc[part.status.eq("fitted") & part.axis_deg.notna()]
        phi = np.radians(good.axis_deg)
        mean_axis = np.degrees(np.arctan2(np.sin(phi).mean(), np.cos(phi).mean())) % 360 if len(good) else np.nan
        aggregation_rows.append({**dict(zip(KEYS, key)), "sample_pitches": len(part), "eligible_individual_pitches": int(part.fit_eligible.sum()),
                                 "mean_individual_axis_deg": mean_axis, "ode_of_mean_axis_deg": mean_fit.get("axis_deg"),
                                 "mean_fit_eligible": mean_fit["fit_eligible"],
                                 "mean_fit_converged": mean_fit["status"] == "fitted", "all_individuals_converged": len(good) == len(part),
                                 "all_individuals_eligible": bool(part.fit_eligible.all())})
    aggregation = pd.DataFrame(aggregation_rows)
    aggregation["difference_deg"] = (aggregation.ode_of_mean_axis_deg-aggregation.mean_individual_axis_deg+180)%360-180
    aggregation.to_csv(args.out / "ode_aggregation_audit.csv", index=False)
    # Check 40 predeclared, evenly sampled seasons under air/lift-law scenarios.
    choose = np.unique(np.linspace(0, len(ff)-1, min(40, len(ff)), dtype=int))
    sensitivities = []
    environments = {"low_density": Environment(1.10), "high_density": Environment(1.30),
                    "alternative_lift": Environment(lift_law="piecewise"),
                    "crosswind_positive_x": Environment(wind_m_s=(2., 0., 0.)),
                    "crosswind_negative_x": Environment(wind_m_s=(-2., 0., 0.))}
    for scenario, environment in environments.items():
        for i in choose:
            row = ff.iloc[i]
            fit = fit_row(row, environment)
            sensitivities.append({**row[KEYS].to_dict(), "scenario": scenario,
                                  "baseline_axis_deg": fitted.iloc[i].axis_deg, **fit})
    sensitivity = pd.DataFrame(sensitivities)
    sensitivity["axis_difference_deg"] = (sensitivity.axis_deg-sensitivity.baseline_axis_deg+180)%360-180
    sensitivity.to_csv(args.out / "ode_sensitivity.csv", index=False)
    combined = geom.merge(fitted, on=KEYS, suffixes=("", "_ff"), validate="one_to_one")
    combined["movement_inferred"] = combined.axis_deg
    combined["ff_speed_m_s"] = combined.rel_speed/3.6
    for name, model in models.items():
        x = study_features(combined, name)
        training = study_features(reference.loc[reference.split.eq("train")], name)
        outside = ((x < training.min(axis=0)) | (x > training.max(axis=0))).any(axis=1)
        finite = np.isfinite(x).all(axis=1)
        prediction = np.full(len(combined), np.nan)
        prediction[finite] = model.predict(x[finite])
        combined[f"raw_{name}_deg"] = prediction
        eligible = combined.fit_eligible.fillna(False) & ~outside & np.isfinite(prediction) & (np.abs(prediction) <= 90)
        combined[f"{name}_deg"] = np.where(eligible, prediction, np.nan)
        combined[f"outside_{name}_training"] = outside
    combined["spin_speed_change_vs_geometry_deg"] = combined.geometry_direction_spin_speed_deg-combined.geometry_deg
    combined["status"] = "research_MLB_transfer_KBO_unvalidated"
    combined.to_csv(args.out / "ode_kbo_eaa_comparison.csv", index=False)
    def audit_group(data):
        good = data.status.eq("fitted")
        return {"rows": len(data), "converged": int(good.sum()),
                "closure_pass": int(data.get("closure_pass", pd.Series(False, index=data.index)).fillna(False).sum()),
                "plane_pass": int(data.get("plane_pass", pd.Series(False, index=data.index)).fillna(False).sum()),
                "spin_fraction_boundary": int(data.get("spin_fraction_at_boundary", pd.Series(False, index=data.index)).fillna(False).sum()),
                "eligible": int(data.fit_eligible.fillna(False).sum()),
                "median_abs_plane_y_error_cm": float(data.loc[good, "plate_y_error_cm"].abs().median())}
    angle_from_movement = np.degrees(np.arctan2(-fitted.observed_hb_m, -fitted.observed_ivb_m))%360
    ode_direction_gap = (fitted.axis_deg-angle_from_movement+180)%360-180
    valid_aggregation = aggregation.mean_fit_converged & aggregation.all_individuals_converged
    report = {"scientific_status": "research_only; effective Magnus axis; KBO arm-angle accuracy not measured",
              "inputs": audits, "matched_pitch_hashes": hashes, "environment": asdict(Environment()),
              "force_equation": "dv/dt=-k*Cd*|v_air|*v_air+k*CL(R*|omega_perp|/|v_air|)*|v_air|^2*unit(omega cross v_air)+(0,0,-g)",
              "movement_definition": "Spinning path minus same-time, same-initial-state, same-Cd no-spin shadow; vendor equivalence unverified",
              "flight_time": "VB polynomial time from TM actual release y=60.5ft-extension to front of plate; derived, not independently observed",
              "closure_scales": {"hb_cm": 1, "ivb_cm": 1, "terminal_speed_m_s": .3},
              "eligibility": {"hb_ivb_abs_error_cm_max": 2, "speed_abs_error_kmh_max": 1,
                              "plate_y_abs_error_cm_max": 10, "fraction_boundary_excluded": True, "minimum_ff": MIN_FF},
              "ff_season_ode": audit_group(fitted),
              "ode_vs_direct_movement_axis": {"median_abs_gap_deg": float(ode_direction_gap.abs().median()),
                                               "abs_gap_p90_deg": float(ode_direction_gap.abs().quantile(.9))},
              "individual_ode": audit_group(sample_result.loc[sample_result.sample_purpose.eq("balanced_type_audit")]),
              "individual_by_pitch_type": {str(k): audit_group(g) for k, g in sample_result.loc[sample_result.sample_purpose.eq("balanced_type_audit")].groupby("sample_pitch_type")},
              "same_pitches_aggregation": {"cases": len(aggregation), "cases_with_all_fits_eligible": int(valid_aggregation.sum()),
                                          "cases_with_all_physics_checks": int((aggregation.mean_fit_eligible & aggregation.all_individuals_eligible).sum()),
                                          "median_abs_gap_deg": float(aggregation.loc[valid_aggregation, "difference_deg"].abs().median()),
                                          "status": "algorithm aggregation comparison includes physically rejected fits; not measurement validation"},
              "sensitivity": {k: {"rows": len(g), "median_abs_axis_change_deg": float(g.axis_difference_deg.abs().median()),
                                    "max_abs_axis_change_deg": float(g.axis_difference_deg.abs().max()),
                                    "eligible": int(g.fit_eligible.sum())} for k, g in sensitivity.groupby("scenario")},
              "arm_feature_validation": arm_report,
              "kbo_research_estimates": {name: int(combined[f"{name}_deg"].notna().sum()) for name in MODEL_NAMES},
              "limitations": ["No optical KBO spin-axis labels or measured KBO arm-angle labels",
                              "Gyro sign, seam-shifted wake, changing spin axis and ball-specific lift are not identified by these inputs",
                              "2019-2021 Four-Seam uses VB FF plus TM Fastball taxonomy proxy",
                              "Season mean ODE is nonlinear and is not the mean of individual-pitch inversions",
                              "MLB official movement-inferred estimator differs from this KBO ODE implementation",
                              "Sensitivity holds vendor HB/IVB fixed and assumes the same-time shadow; does not quantify uncertainty in the vendor's force decomposition",
                              "No Gwangju TrackMan validation, and no 2025-2026 measured spin-rate inputs",
                              "Same-time shadow is not verified as TrackMan's exact movement definition"],
              "source_hashes": {"spin_reference": digest(args.spin_reference), "height_table": digest(ROOT / "data/tracking/player_heights.csv"),
                                "implementation": digest(ROOT / "src/visualbaseball/spin_axis_ode.py"), "study": digest(Path(__file__))},
              "runtime": {"python": sys.version.split()[0], **{p: version(p) for p in ["numpy", "scipy", "pandas", "scikit-learn"]}}}
    (args.out / "ode_study_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+"\n")
    print(json.dumps({k: report[k] for k in ["ff_season_ode", "individual_ode", "kbo_research_estimates"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
