"""Separate the release-coordinate bridge from the frozen angle model.

Research only: the 2024 paired sample cannot validate a 2026 reported angle.
"""
from pathlib import Path
import csv
import hashlib
import json

import numpy as np
import pyarrow.parquet as pq

from visualbaseball.estimated_arm_angle import _predict

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/arm_angle/results'


def main():
    path = ROOT / '.cache/arm_angle/vb_bridge/matched_pitcher_games.parquet'
    model_path = ROOT / 'data/models/estimated_arm_angle_v1.json'
    model = json.loads(model_path.read_text())
    rows = pq.read_table(path, filters=[('season', '=', 2024),
                                      ('pitcher_id', '=', '54362')]).to_pylist()
    if not rows or any(r['pitcher_hand'] != 'Right' for r in rows):
        raise ValueError('Expected matched right-handed pitcher games')
    heights = {float(r['height_cm']) for r in rows}
    if len(heights) != 1:
        raise ValueError('Resolve inconsistent heights before comparison')
    height = heights.pop() / 100
    weights = np.array([r['n_pitches'] for r in rows], dtype=float)
    if not np.all(weights > 0):
        raise ValueError('All matched games must have positive pitch counts')
    means = {k: float(np.average([r[k] for r in rows], weights=weights)) for k in
             ['release_x_55', 'release_z_55', 'dx_dy55', 'dz_dy55', 'rel_side', 'rel_height']}
    feature = [height, -means['release_x_55'] / 100, means['release_z_55'] / 100,
               -means['dx_dy55'], means['dz_dy55']]
    correction = _predict(model['bridge'], feature)
    side, z = feature[1] + correction[0], feature[2] + correction[1]

    def angle(x, release_z, h=height):
        return float(_predict(model['angle'], [h, release_z / h, x / h, 0.]))

    baseline = angle(side, z)
    tm = angle(means['rel_side'], means['rel_height'])
    seasons = [r for r in csv.DictReader((OUT / 'eaa_vb_pitcher_seasons_2022_2026.csv').open())
               if r['pitcher_id'] == '54362']
    parks = [r for r in csv.DictReader((OUT / 'eaa_vb_pitcher_stadium_seasons.csv').open())
             if r['pitcher_id'] == '54362' and r['season'] == '2026']
    result = {
        'pitcher_id': '54362', 'player': '전준표', 'height_cm': height * 100,
        'reference': {'season': 2026, 'low_deg': 47., 'high_deg': 53.,
                      'source': 'User reports 2026, probably SSG TrackMan; original source not verified',
                      'angle_definition_verified': False, 'measurement_method_verified': False,
                      'pitch_type_and_game_scope_verified': False, 'eligible_for_calibration': False},
        'comparison_scope': 'Same 2024 matched pitcher-game sample, weighted by valid pitch counts; '
                            'same frozen angle model in all three paths. Not 2026 arm-angle truth.',
        'matched_2024': {
            'n_games': len(rows), 'n_pitches': int(sum(weights)),
            'stadium_counts': {s: sum(r['n_pitches'] for r in rows if r['stadium'] == s)
                               for s in sorted({r['stadium'] for r in rows})},
            'source_means': means, 'predicted_rel_side_m': float(side),
            'predicted_rel_height_m': float(z),
            'VB_raw55_model_eAA_deg': angle(feature[1], feature[2]),
            'VB_bridge_model_eAA_deg': baseline, 'TM_direct_model_eAA_deg': tm,
            'bridge_minus_TM_model_deg': baseline - tm,
        },
        'seasons': [{'season': int(r['season']), 'eaa_deg': float(r['eaa_deg']),
                     'n_pitches': int(r['n_pitches']), 'range_status': r['range_status'],
                     'same_reference_season': r['season'] == '2026',
                     'reference_minus_estimate_low_deg': 47. - float(r['eaa_deg']) if r['season'] == '2026' else None,
                     'reference_minus_estimate_high_deg': 53. - float(r['eaa_deg']) if r['season'] == '2026' else None}
                    for r in seasons],
        'stadiums_2026': [{'stadium': r['stadium'], 'n_pitches': int(r['n_pitches']),
                           'published_eaa_deg': float(r['eaa_deg']) if r['eaa_deg'] else None,
                           'status': r['estimate_status']}
                          for r in parks],
        'model_sensitivity': [],
        'input_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in [path, model_path, OUT / 'eaa_vb_pitcher_seasons_2022_2026.csv',
                                   OUT / 'eaa_vb_pitcher_stadium_seasons.csv']},
        'limitations': ['2024 matched sample does not validate 2026 bridge or park bias',
                        'TM and MLB vertical datum contract not independently established',
                        'Angle model has no observed KBO shoulder or torso input',
                        'Model sensitivity is not true shoulder sensitivity or an input correction'],
    }
    for variable, deltas in [('rel_height_cm', [-10, -5, 5, 10]),
                             ('arm_side_release_cm', [-5, 5]), ('height_cm', [-2, 2])]:
        for delta in deltas:
            test_side, test_z, test_h = float(side), float(z), height
            if variable == 'rel_height_cm': test_z += delta / 100
            elif variable == 'arm_side_release_cm': test_side += delta / 100
            else: test_h += delta / 100
            value = angle(test_side, test_z, test_h)
            result['model_sensitivity'].append({'variable': variable, 'delta': delta,
                                               'model_eaa_deg': value, 'change_deg': value - baseline})
    (OUT / 'video_jeon_diagnostics.json').write_text(
        json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'matched_2024_n': int(sum(weights)), 'VB_bridge_deg': baseline,
                      'TM_direct_deg': tm, 'difference_deg': baseline - tm}))


if __name__ == '__main__':
    main()
