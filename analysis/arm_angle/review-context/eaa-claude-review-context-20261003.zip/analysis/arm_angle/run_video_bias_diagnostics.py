"""Test shared eAA bias hypotheses, without fitting to reported KBO angles."""
from pathlib import Path
import hashlib
import json
import math
import os

ROOT = Path(__file__).resolve().parents[2]
os.environ.setdefault('MPLCONFIGDIR', str(ROOT / '.cache/arm_angle/video/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME', str(ROOT / '.cache/arm_angle/video/xdg-cache'))

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from visualbaseball.estimated_arm_angle import _predict

OUT = ROOT / 'analysis/arm_angle/results'


def main():
    model_path = ROOT / 'data/models/estimated_arm_angle_v1.json'
    canonical_path = ROOT / '.cache/arm_angle/video/jeon2026_selected_canonical.json'
    reference_path = OUT / 'eaa_mlb_split_validation.csv'
    kbo_path = OUT / 'candidate_kbo_season_inputs.csv'
    model = json.loads(model_path.read_text())
    raw = json.loads(canonical_path.read_text());features = [];valid = []
    for row in raw:
        try: x,z,vx,vy,vz = [float(row[c]) for c in ['release_x_55','release_z_55','vx_55','vy_55','vz_55']]
        except (ValueError, TypeError): continue
        if (row['trajectory_valid'] and np.isfinite([x,z,vx,vy,vz]).all()
                and -200 <= x <= 200 and 5 <= z <= 270 and vy < 0):
            features.append([1.86,-x/100,z/100,-vx/vy,vz/vy]);valid.append(row)
    x = np.asarray(features)

    def predict(mean):
        correction = _predict(model['bridge'], mean);h,side,z = mean[:3]
        return float(_predict(model['angle'],[h,(z+correction[1])/h,(side+correction[0])/h,0.]))

    baseline = predict(x.mean(axis=0))
    per_pitch = np.array([predict(f) for f in x])
    by_type = []
    for value in sorted({str(r['pitch_type']) for r in valid}):
        indices = [i for i,r in enumerate(valid) if str(r['pitch_type']) == value]
        by_type.append({'pitch_type':value,'n':len(indices),'diagnostic_model_angle_deg':predict(x[indices].mean(axis=0)),
                        'per_type_accuracy_validated':False,'production_published':False})
    mean = x.mean(axis=0);correction = _predict(model['bridge'], mean)
    h,side,z = mean[:3];side += correction[0];z += correction[1]
    scenarios = [{'hypothetical_height_offset_cm':cm,
                  'diagnostic_model_angle_deg':float(_predict(model['angle'],[h,(z+cm/100)/h,side/h,0.])),
                  'offset_verified':False,'offset_applied':False} for cm in [0,5,10,15,20,25.4]]
    reference = pd.read_csv(reference_path)
    nearby = reference.loc[reference.pitcher_hand.eq('Right') &
                           (reference.height_cm-186).abs().le(5) &
                           (reference.rel_height/(reference.height_cm/100)-z/h).abs().le(.025) &
                           (reference.rel_side/(reference.height_cm/100)-side/h).abs().le(.04)].copy()
    nearby.to_csv(OUT/'video_geometry_nearby_mlb.csv',index=False)
    nearby_test = nearby.loc[nearby.split.eq('test')]
    fin = nearby.loc[nearby.p_name_display_first_last.eq('Finnegan, Kyle') & nearby.season.eq(2024)].iloc[0]
    median_z = float(nearby.shoulder_height_m.median());median_side = float(nearby.shoulder_side_m.median())
    shoulder_scenarios = []
    for name,sz,sx in [('nearby MLB medians',median_z,median_side),
                       ('Finnegan height + median lateral',float(fin.shoulder_height_m),median_side),
                       ('median height + Finnegan lateral',median_z,float(fin.shoulder_side_m)),
                       ('Finnegan 2024 shoulder coordinates',float(fin.shoulder_height_m),float(fin.shoulder_side_m))]:
        shoulder_scenarios.append({'scenario':name,'shoulder_height_m':sz,'arm_side_shoulder_m':sx,
                                   'geometry_deg_at_Jeon_release':math.degrees(math.atan2(z-sz,abs(side-sx))),
                                   'Jeon_shoulder_measured':False})
    kbo = pd.read_csv(kbo_path)
    cohorts = {}
    for name,data in [('MLB_2024_R_qualified',reference.loc[reference.season.eq(2024)&reference.pitcher_hand.eq('Right')&reference.n_pitches.ge(100)]),
                      ('KBO_2024_R_TM_matched',kbo.loc[kbo.season.eq(2024)&kbo.pitcher_hand.eq('Right')&kbo.n_pitches.ge(100)])]:
        cohorts[name] = {'pitcher_seasons':len(data),'height_mean_cm':float(data.height_cm.mean()),
                         'release_height_over_height_mean':float((data.rel_height/(data.height_cm/100)).mean()),
                         'arm_side_release_over_height_mean':float((data.rel_side/(data.height_cm/100)).mean()),
                         'same_population_selection':False}
    fig,ax = plt.subplots(figsize=(7.3,5.6),layout='constrained')
    ax.plot([20,65],[20,65],color='.65',linestyle='--',label='Actual = prediction')
    marks = {'train':'o','calibration':'s','test':'^','cal':'s'}
    for split,data in nearby.groupby('split'):
        ax.scatter(data.arm_angle,data.prediction_deg,marker=marks.get(split,'o'),s=45,alpha=.8,label=f'{split} ({len(data)})')
    ax.scatter([fin.arm_angle],[fin.prediction_deg],s=160,facecolors='none',edgecolors='#bb2222',linewidths=1.5)
    ax.annotate('Kyle Finnegan, 2024', (fin.arm_angle,fin.prediction_deg),xytext=(42,31),
                arrowprops={'arrowstyle':'->','color':'#bb2222'},fontsize=9)
    ax.set(xlim=(20,65),ylim=(20,65),xlabel='Observed Savant arm angle (degrees)',
           ylabel='Frozen eAA-v1 prediction (degrees)',title='Similar release position and height can hide different arm slots')
    ax.set_aspect('equal');ax.grid(alpha=.2);ax.legend(loc='upper left',fontsize=8)
    fig.savefig(OUT/'video_geometry_compression.png',dpi=180);plt.close(fig)
    report = {'scope':'Exploratory mechanism diagnostics; no causal claim or KBO calibration',
              'Jeon_2026':{'n_valid_pitches':len(x),'season_mean_input_model_deg':baseline,
                           'mean_of_pitch_model_diagnostic_deg':float(per_pitch.mean()),
                           'aggregation_difference_deg':float(per_pitch.mean()-baseline),
                           'individual_pitch_model_accuracy_validated':False,
                           'reference_convention_hypothesis':{
                               'SSG_reported_range': [47.,53.],
                               'if_measured_from_vertical_then_Savant_horizontal_range': [37.,43.],
                               'current_model_inside_that_range': 37. <= baseline <= 43.,
                               'SSG_definition_verified': False,
                               'applied_to_reference': False},
                           'by_pitch_type':by_type,'vertical_datum_scenarios':scenarios},
              'nearby_MLB_geometry':{'filter':'Right; height within 5 cm of 186; z/height within .025 and arm-side/height within .04 of Jeon2026',
                                      'pitcher_seasons':len(nearby),'unique_pitchers':int(nearby.pitcher.nunique()),
                                      'actual_min_deg':float(nearby.arm_angle.min()),'actual_max_deg':float(nearby.arm_angle.max()),
                                      'model_min_deg':float(nearby.prediction_deg.min()),'model_max_deg':float(nearby.prediction_deg.max()),
                                      'all_model_splits_included':True,'not_independent_test_performance':True,
                                      'test_subset':{'pitcher_seasons':len(nearby_test),
                                                     'unique_pitchers':int(nearby_test.pitcher.nunique()),
                                                     'actual_min_deg':float(nearby_test.arm_angle.min()),
                                                     'actual_max_deg':float(nearby_test.arm_angle.max()),
                                                     'model_min_deg':float(nearby_test.prediction_deg.min()),
                                                     'model_max_deg':float(nearby_test.prediction_deg.max())},
                                      'Finnegan_2024':{k:float(fin[k]) for k in ['arm_angle','prediction_deg','height_cm','rel_height','rel_side','shoulder_height_m','shoulder_side_m']},
                                      'Finnegan_split':str(fin['split'])},
              'shoulder_scenarios':shoulder_scenarios,'release_height_cohorts':cohorts,
              'limitations':['No verified KBO Savant angle labels; Ahn season/definition and Jeon SSG source/definition remain uncertain',
                             'Repeated pitcher seasons and all model splits: nearby examples are illustrative, not an independent evaluation',
                             'Different cohort selection/mechanics can affect population release-height comparison',
                             'Hypothetical vertical shifts are sensitivity tests, not established datum corrections',
                             'MLB shoulder coordinates in scenarios are not measured Jeon shoulder positions',
                             'Per-pitch/group predictions are diagnostics, not newly validated pitch-specific eAA'],
              'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in [model_path,canonical_path,reference_path,kbo_path]}}
    (OUT/'video_bias_diagnostics.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:report[k] for k in ['Jeon_2026','nearby_MLB_geometry','shoulder_scenarios']},ensure_ascii=False))


if __name__ == '__main__': main()
