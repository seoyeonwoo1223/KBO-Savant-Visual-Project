# 영상 기반 eAA 검증: 표본 선정과 자동 추출 결과

이 문서는 자동 추출까지의 기록이다. 이후 사용자의 추가 요청에 따른 [영상 잠정 각도 계산과 편향 점검](video-angle-study.md)을 별도로 보존했다.

2026-10-03(한국 시간), 공개 공유된 사용자 Drive 자료 **7명·32개 원본**을 내려받아 전부 자동 처리했다. 앞서 기록한 Google 로그인/HTTP 401 문제는 해결됐다. 이번 범위는 사용자가 지정한 **1. 표본 선정, 2. 자동 관절점·릴리즈 구간 후보 추출**이다. 실제 릴리즈 확인, 각도 측정, 모델 보정은 수행하지 않았다.

## 선수별 결과

| 선수 | 원본 파일 | 전신 자료 | 품질 기준을 통과한 투수 관절점 프레임 | 미검토 릴리즈 구간 후보 |
|---|---:|---:|---:|---:|
| 이강준 | 4 | 3 | 126 | 7 |
| 윤현 | 2 | 1 | 86 | 2 |
| 김광현 | 5 | 3 | 192 | 4 |
| 안우진 | 7 | 0 | 0 | 0 |
| 임찬규 | 1 | 0 | 0 | 0 |
| 원태인 | 1 | 0 | 0 | 0 |
| **전준표** | **12** | **11** | **521** | **13** |
| 합계 | 32 | 18 | 925 | 26 |

총 2,886프레임을 분석했고, 사람 자세가 검출된 것은 2,185프레임이다. 관절점 품질 기준을 통과한 1,028프레임 중 확대 화면의 사람을 투수로 오인할 수 있는 자료를 제외하면 투수 후보 관절점은 925프레임이다. 자동 공 검출 114개와 임시 공 트랙 19개도 보존했다. 모두 미검토 결과이며 실제 야구공·릴리즈 확인이나 검출 정확도 평가를 의미하지 않는다.

**26개 구간은 26구가 아니다.** 같은 투구 GIF에서 와인드업·릴리즈 주변·팔로스루가 여러 후보로 나올 수 있다. 최초 목표인 10명·30–50개의 독립 투구 확보는 달성했다고 표시하지 않는다. 전체 자료를 일괄 수집하지 않고, 제공 폴더에서 처음 6명을 처리한 뒤 전준표 12개를 추가했다.

[선수별 CSV](results/video_actual_player_summary.csv), [원본 목록·해시](results/video_selected_sources.json), [실제 자동 추출 보고서](results/video_actual_pilot_report.json), [검증 기록](results/video_pilot_verification.json)에 상세 근거를 저장했다.

## 자료별 판단

- **전준표:** 추가 12개 중 11개에 전신 투구폼이 보인다. 관절점 521프레임과 미검토 구간 13개를 추출했다. 2026년 47–53°는 SSG TrackMan으로 추정되는 사용자 전언이며 측정 정의는 미확인이다. [전준표 자료와 원인 점검](video-jeon-study.md)을 별도로 기록했다.

- **이강준:** 파일명상 2025년 슬라이더 전신과 2026년 후방·측면 투구폼에서 관절점이 나온다. 측면 영상은 몸통 움직임 점검에 유용하지만 그 영상의 2차원 각도를 Savant 정면 각도로 바로 사용할 수 없다.
- **윤현:** 파일명상 2024년 투구폼에서 관절점을 얻었다. 2025년 너클커브 릴리즈 확대 화면은 공 후보 자료로 분리했다. 기존 시즌 eAA와 연결할 때 연도를 혼합하면 안 된다.
- **김광현:** 처음 선택한 2025년 와이드 영상에서는 좌투 팔꿈치·손목의 신뢰도가 부족해 투수 관절점 프레임이 0개였다. 추가 2024·2025년 메커니즘 MP4에서는 192프레임을 얻었다. 이 두 원본에는 기존에 그려진 선·표시가 포함돼 있으므로 깨끗한 영상과 동일하게 취급하거나 그 선을 측정 기준값으로 쓰지 않는다. 투구 손을 바꾸거나 품질 임곗값을 낮춰 결과를 강제로 만들지 않았다.
- **안우진:** 확인한 투구 GIF 7개는 파일명상 2018·2021년 자료이며 손·공 확대 화면 위주다. 일부 초반에 상체가 보이더라도 릴리즈 순간 어깨와 몸통이 연속해서 보이지 않아 본체 후보를 제외했다. 이 자료로 최근 시즌의 어깨 위치나 약 56°를 검증했다고 할 수 없다. 세리머니 GIF는 제외했다.
- **임찬규·원태인:** 확보한 각 1개는 손·공 확대 화면으로, 이번 어깨·몸통 측정 표본으로는 부족하다.

파일명 날짜는 후보 메타데이터다. 촬영 날짜·선수 신원·영상과 개별 투구의 대응은 독립 확인되지 않았다. MP4와 GIF의 같은 장면을 별개의 투구 라벨로 세지 않는다. 카메라 보정도 미실행이다.

## 자동 처리 방식과 이번 수정

MediaPipe Pose Landmarker Full의 영상 좌표 33개 관절점을 저장한다. 투구 손의 어깨·팔꿈치·손목과 양쪽 어깨·엉덩이에 visibility/presence 기준을 적용한다. 지정한 투수 ROI 밖의 추정 관절점도 제외한다. 모델의 3차원 유사 좌표를 실제 어깨 위치나 실측 각도로 사용하지 않는다.

슬로모션 GIF에서 프레임 간격이 170·270ms인 사례를 확인했다. 평균 FPS 대신 `ffprobe`의 개별 프레임 presentation timestamp를 보존하며, 이번 파일들은 **어깨 대비 손목의 프레임 간 변위**를 몸통 길이로 정규화해 후보를 만든다. 소스의 프레임 간격에 맞춰 추적 공백 한도를 설정하고, 장면 전환·낮은 신뢰도·긴 공백을 제외한다. 속도 방식도 코드에 남아 있으나 이번 파일의 재생 시간을 실제 투구 속도로 취급하지 않는다.

확대 화면에서는 타자·포수가 자세 모델에 잡힐 수 있어 본체 기반 릴리즈 제안을 끈다. 공 검출은 본체 후보와 별개로 최대 재생 5fps에서 EfficientDet Lite0의 `sports ball` 클래스를 찾는다. 가까운 검출을 연결한 트랙은 검토용이며 릴리즈 증거로 확정하지 않는다.

각 본체 후보에는 재생 시간 기준 전후 150ms의 관절점 표시 프레임과 contact sheet를 저장했다. 자동 후보 중 와인드업·팔로스루가 포함되는 것을 시각적으로 확인했다. 이 단계의 그림 확인은 구도·실행 품질 점검이며 사람의 릴리즈 라벨링이나 팔각도 측정이 아니다.

## 출처와 보존

[사용자 Drive 출처 6개](results/video_drive_sources.json), [제한된 폴더 목록](results/video_drive_inventory.json)을 보존했다. 첫 목록 조사는 최대 25페이지·하위 3단계로 제한했고 전준표 폴더 2페이지를 추가 조사했다. 기존 아카이브에는 남은 페이지가 있어 전체 목록은 불완전으로 표시한다. 공개 공유 링크를 사용했고 개인 계정 로그인이나 쿠키를 사용하지 않았다.

원본과 자동 추출 이미지는 Git에 포함하지 않는 작업 캐시에 있다.

```text
.cache/arm_angle/video/drive/originals/<Drive ID>-<원본 이름>
.cache/arm_angle/video/drive/originals/<원본 이름>.source.json
.cache/arm_angle/video/actual-extracted/<Drive ID>/
```

원본 이름·Drive ID·SHA-256·바이트 수를 기록하고 원본을 수정하지 않았다. 다시 실행할 때 이전 추출 산출물은 `previous-runs/run-N/`에 보존한다. 각 추출 폴더의 `extraction_report.json`, `pose_keypoints.jsonl`, `motion_features.json`, `source_frame_timing.json`, `release_window_candidates.json`, `ball_detector_observations.json`, `ball_track_candidates.json`과 `event-NN-contact-sheet.jpg`가 검토 자료다.

## 안우진 참고값과 보정 원칙

[안우진 약 56° 참고값](results/video_ahn_reported_reference.json)은 구단 관계자 전언이다. 시즌·경기·측정 정의·오차가 미확인이라 보정 라벨로 쓰지 않는다. 기존 eAA-v1과의 조건부 차이는 2022년 +13.35°, 2023년 +11.24°, 2026년 +14.63°이며 해당 시즌의 실제 오차로 해석하지 않는다.

이강준이 얼추 맞는다는 판단도 정성적 참고다. 유형별 보정을 검토하려면 같은 정의·시즌으로 확인한 여러 투수의 측정값을 먼저 확보하고 투수 단위 분리 평가가 필요하다. 이번 결과에서 새 각도·유형별 보정값·KBO 정확도 범위를 만들지 않았고 현재 Pitch Plot과 고정 eAA-v1은 유지했다.

## 실행과 검증

별도 영상 환경에 MediaPipe 0.10.33, OpenCV 4.11.0.86, NumPy 2.2.6, gdown 5.2.0 등을 설치했다. 기본 분석 환경은 교체하지 않았다. 공식 모델의 해시·형식을 확인했고, 필요한 `libGLESv2`는 서명된 Debian 인덱스와 패키지 해시로 검증해 작업 캐시에 추출했다. `video_support_libraries.py`가 이를 검증하고 로드한다.

후보 로직 7개·프레임 시간 10개를 포함한 Python 테스트 **221개**와 Node 웹 레이아웃 검사가 통과했다. ROI 밖 관절점 차단, 재생 속도 변경 시 변위 후보의 일관성, 가변 GIF 타이밍과 30fps 반올림을 점검했다. 실제 32개 소스 추론과 원본 해시 일치도 확인했다. 이는 실제 릴리즈·공 검출 정확도나 팔각도 정확도 검증과 구분한다.

현재 런타임은 spec revision 4의 unrestricted 요청을 보고했고 Drive의 실제 공개 접근을 확인했다. 전체 네트워크 enforcement state는 unknown이므로 모든 목적지의 접근을 검증했다고 주장하지 않는다. 이전 로그인/401 및 유튜브 접근 실패는 검증 JSON의 이력에 남겼으며 이번 Drive 작업의 활성 차단 사유는 없다.

```bash
cd /workspace/KBO-Savant-Visual-Project
export PYTHONPATH=src OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
export XDG_CACHE_HOME=/workspace/KBO-Savant-Visual-Project/.cache/arm_angle/video/xdg-cache
export MPLCONFIGDIR=/workspace/KBO-Savant-Visual-Project/.cache/arm_angle/video/matplotlib

# 새 환경에서만 영상 전용 의존성과 지원 라이브러리를 준비한다.
python3 -m venv .cache/arm_angle/video/.venv
.cache/arm_angle/video/.venv/bin/python -m pip install -r analysis/arm_angle/requirements-video.txt
.cache/arm_angle/video/.venv/bin/python analysis/arm_angle/video_support_libraries.py
.cache/arm_angle/video/.venv/bin/python analysis/arm_angle/run_video_pilot.py assets

# 현재 선택한 원본을 확보한 환경에서 같은 추출을 재실행한다.
.cache/arm_angle/video/.venv/bin/python analysis/arm_angle/run_actual_video_pilot.py --workers 2
```

선택 원본 목록은 현재 워크스페이스의 절대 경로를 기록한다. 새 환경에서는 `run_drive_video_sources.py fetch --file-id <Drive ID>`로 선택 원본을 확보한 뒤 목록의 경로를 새 위치로 맞춰야 한다. `catalog`나 `plan`을 다시 실행해 실제 결과 메타데이터를 준비 상태로 덮어쓰지 않는다.
