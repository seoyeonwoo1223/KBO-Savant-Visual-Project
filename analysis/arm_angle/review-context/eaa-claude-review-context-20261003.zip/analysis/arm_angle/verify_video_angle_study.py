"""Read back reviewed projections and independently replay diagnostic arithmetic.

This verifies provenance/calculations, not physical camera or KBO angle accuracy.
Run with the isolated video Python; tests run in the existing base environment.
"""
from pathlib import Path
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import subprocess

import cv2

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'analysis/arm_angle/results'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(name):
    with (OUT / name).open() as f:
        return list(csv.DictReader(f))


def close(a, b):
    if not math.isclose(float(a), float(b), abs_tol=1e-8, rel_tol=1e-10):
        raise AssertionError((a, b))


def independent_model(model, inputs):
    """Scalar saved-coefficient evaluation, without the production predictor."""
    values = list(inputs)
    if 'polynomial_powers' in model:
        values = [math.prod(v ** power for v, power in zip(inputs, powers))
                  for powers in model['polynomial_powers']]
    standardized = [(v-mean)/scale for v, mean, scale in zip(
        values, model['standardization_mean'], model['standardization_scale'])]
    coefficients, intercept = model['ridge_coefficients'], model['intercept']
    if isinstance(intercept, list):
        return [math.fsum(c*v for c, v in zip(row, standardized))+bias
                for row, bias in zip(coefficients, intercept)]
    return math.fsum(c*v for c, v in zip(coefficients, standardized))+intercept


def main():
    estimates = json.loads((OUT / 'video_arm_estimates.json').read_text())
    diagnostics = json.loads((OUT / 'video_bias_diagnostics.json').read_text())
    labels = json.loads((OUT / 'video_arm_manual_annotations.json').read_text())
    pilot = json.loads((OUT / 'video_actual_pilot_report.json').read_text())
    sources = {r['drive_id']: r for r in pilot['sources']}
    csv_rows = {(r['drive_id'], int(r['frame_index'])): r
                for r in read_csv('video_arm_estimates.csv')}
    assert not estimates['reference_angles_used_to_place_points']
    assert estimates['calibrated_Savant_angles_generated'] == 0
    assert len(estimates['sources']) == len(labels['rows']) == len(csv_rows)
    assert estimates['reviewed_source_frames_total'] == len(labels['rows'])+len(labels['excluded_reviewed_frames'])
    frame_checks = []
    for row in estimates['sources']:
        source = sources[row['drive_id']]
        original = Path(source['original_path'])
        pose_path = Path(source['output_directory']) / 'pose_keypoints.jsonl'
        assert sha(original) == row['source_sha256']
        assert sha(pose_path) == row['pose_keypoints_sha256']
        assert sha(Path(row['annotated_frame'])) == row['annotated_frame_sha256']
        poses = {p['frame_index']: p for p in map(json.loads, pose_path.read_text().splitlines())}
        s = poses[row['frame_index']]['landmarks'][row['shoulder_index']][:2]
        assert s == row['shoulder_xy']
        b = row['ball_xy']
        angle = math.degrees(math.atan2(s[1]-b[1], abs(b[0]-s[0])))
        close(angle, row['image_angle_deg'])
        close(angle, csv_rows[row['drive_id'], row['frame_index']]['image_angle_deg'])
        for axis in ['low', 'high']:
            key = f'coordinate_scenario_{axis}_deg'
            close(row[key], csv_rows[row['drive_id'], row['frame_index']][key])
        boxes = [[v-e, v, v+e] for v, e in zip(
            [*s, *b], [*row['shoulder_error_xy'], *row['ball_error_xy']])]
        for sx, sy, bx, by in itertools.product(*boxes):
            if sx == bx and sy == by:
                continue
            value = math.degrees(math.atan2(sy-by, abs(bx-sx)))
            assert row['coordinate_scenario_low_deg']-1e-9 <= value <= row['coordinate_scenario_high_deg']+1e-9
        assert row['calibrated_Savant_angle_deg'] is None
        assert not row['camera_geometry_calibrated'] and not row['eligible_for_model_calibration']
        cap = cv2.VideoCapture(str(original))
        cap.set(cv2.CAP_PROP_POS_FRAMES, row['frame_index'])
        ok, frame = cap.read()
        assert ok and hashlib.sha256(frame.tobytes()).hexdigest() == row['decoded_frame_sha256']
        cap.set(cv2.CAP_PROP_POS_FRAMES, row['release_bracket'][1])
        ok, next_frame = cap.read(); cap.release()
        assert ok and hashlib.sha256(next_frame.tobytes()).hexdigest() != row['decoded_frame_sha256']
        frame_checks.append({'player': row['player'], 'drive_id': row['drive_id'],
                             'frame_index': row['frame_index'], 'source_and_frame_hashes_match': True,
                             'direct_atan2_matches': True, 'coordinate_grid_contained': True})
    for report in [estimates, diagnostics]:
        for path, digest in report['input_sha256'].items():
            assert sha(ROOT / path) == digest

    model = json.loads((ROOT / 'data/models/estimated_arm_angle_v1.json').read_text())
    canonical = json.loads((ROOT / '.cache/arm_angle/video/jeon2026_selected_canonical.json').read_text())
    assert {str(r['pitcher_id']) for r in canonical} == {'54362'}
    assert {r['season'] for r in canonical} == {2026}
    assert len({r['pitch_id'] for r in canonical}) == len(canonical)
    canonical_command = [str(ROOT / '.venv/bin/python'), '-c',
        "from pathlib import Path; import json; from visualbaseball.curated import load_rows; "
        "root=Path.cwd(); cached=json.loads((root/'.cache/arm_angle/video/jeon2026_selected_canonical.json').read_text()); "
        "rows=load_rows(root,'pitches',2026,columns=list(cached[0]),player_id='54362',player_role='pitcher'); "
        "assert rows==cached; print(json.dumps({'selected_canonical_readback_matches':True,'rows':len(rows)}))"]
    canonical_readback = subprocess.run(canonical_command, cwd=ROOT, capture_output=True, text=True, check=True)
    features = []
    for r in canonical:
        x, z, vx, vy, vz = [float(r[c]) for c in ['release_x_55', 'release_z_55', 'vx_55', 'vy_55', 'vz_55']]
        if r['trajectory_valid'] and all(map(math.isfinite, [x,z,vx,vy,vz])) and -200 <= x <= 200 and 5 <= z <= 270 and vy < 0:
            features.append([1.86, -x/100, z/100, -vx/vy, vz/vy])
    mean = [math.fsum(col)/len(features) for col in zip(*features)]
    def predict(f):
        dx, dz = independent_model(model['bridge'], f)
        h, side, z = f[:3]
        return independent_model(model['angle'], [h, (z+dz)/h, (side+dx)/h, 0.])
    baseline = predict(mean)
    close(baseline, diagnostics['Jeon_2026']['season_mean_input_model_deg'])
    close(math.fsum(map(predict, features))/len(features), diagnostics['Jeon_2026']['mean_of_pitch_model_diagnostic_deg'])
    assert len(features) == diagnostics['Jeon_2026']['n_valid_pitches']
    h, side, z = mean[:3]
    dx, dz = independent_model(model['bridge'], mean)
    side += dx; z += dz
    for scenario in diagnostics['shoulder_scenarios']:
        angle = math.degrees(math.atan2(z-scenario['shoulder_height_m'], abs(side-scenario['arm_side_shoulder_m'])))
        close(angle, scenario['geometry_deg_at_Jeon_release'])
        assert not scenario['Jeon_shoulder_measured']

    reference = read_csv('eaa_mlb_split_validation.csv')
    nearby = [r for r in reference if r['pitcher_hand'] == 'Right'
              and abs(float(r['height_cm'])-186) <= 5
              and abs(float(r['rel_height'])/(float(r['height_cm'])/100)-z/h) <= .025
              and abs(float(r['rel_side'])/(float(r['height_cm'])/100)-side/h) <= .04]
    saved_nearby = read_csv('video_geometry_nearby_mlb.csv')
    assert {(r['pitcher'], r['season']) for r in nearby} == {(r['pitcher'], r['season']) for r in saved_nearby}
    assert len(nearby) == diagnostics['nearby_MLB_geometry']['pitcher_seasons']
    fin = next(r for r in nearby if r['p_name_display_first_last'] == 'Finnegan, Kyle' and r['season'] == '2024')
    assert fin['split'] == 'test'
    fin_h = float(fin['height_cm'])/100
    close(independent_model(model['angle'], [fin_h, float(fin['rel_height'])/fin_h,
                                            float(fin['rel_side'])/fin_h, 0.]), fin['prediction_deg'])
    for r in nearby:
        close(-float(r['release_ball_x'])*.3048, r['rel_side'])
        shoulder = -(float(r['release_ball_x'])-float(r['relative_release_ball_x'])+float(r['relative_shoulder_x']))*.3048
        close(shoulder, r['shoulder_side_m'])

    command = [str(ROOT / '.venv/bin/python'), '-m', 'pytest', 'tests/test_video_arm_projection.py',
               'tests/test_video_frame_timing.py', 'tests/test_video_pose_candidates.py', '-q']
    tests = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, check=False)
    if tests.returncode:
        raise RuntimeError(tests.stdout+tests.stderr)
    protected = ['web', 'data/curated', 'seasons', 'data/tracking', 'data/models',
                 'src/visualbaseball/estimated_arm_angle.py']
    subprocess.run(['git', 'diff', '--quiet', 'HEAD', '--', *protected], cwd=ROOT, check=True)
    subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
    artifacts = ['video_arm_estimates.json','video_arm_estimates.csv','video_arm_manual_annotations.json',
                 'video_bias_diagnostics.json','video_geometry_nearby_mlb.csv','video_geometry_compression.png']
    paths = [OUT / a for a in artifacts] + [
        ROOT / 'src/visualbaseball/video_arm_projection.py',
        ROOT / 'analysis/arm_angle/run_video_arm_estimates.py',
        ROOT / 'analysis/arm_angle/run_video_bias_diagnostics.py',
        Path(__file__).resolve(), ROOT / 'analysis/arm_angle/video-angle-study.md']
    report = {'verified_at': datetime.now(timezone.utc).isoformat(),
              'status': 'provenance_and_scoped_calculations_verified_KBO_angle_accuracy_unvalidated',
              'checks': {'frames': frame_checks, 'CSV_JSON_agree': True, 'input_SHA256_match': True,
                         'canonical_readback': json.loads(canonical_readback.stdout),
                         'independent_saved_model_and_geometry_replay': True,
                         'nearby_MLB_selection_and_common_coordinate_origin_verified': True,
                         'reported_KBO_angles_used_for_fit': False, 'calibrated_Savant_angles_generated': 0,
                         'protected_tracked_paths_equal_HEAD': True, 'git_diff_check_passed': True},
              'test_run': {'command': command, 'returncode': tests.returncode,
                           'stdout': tests.stdout, 'stderr': tests.stderr,
                           'scope': 'New image projection and existing timing/candidate integration tests; no full-suite claim'},
              'snapshot_sha256': {str(p.relative_to(ROOT)): sha(p) for p in paths},
              'remaining_uncertainty': ['Exact release instant', 'Camera yaw/elevation/depth/roll calibration',
                                        'Pose shoulder anatomical accuracy', 'Original recording date and pitch identity',
                                        'SSG angle definition and verified KBO reference angles']}
    (OUT / 'video_angle_verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'verified_frames':len(frame_checks),'test_run':report['test_run'],
                      'KBO_angle_accuracy_validated':False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
