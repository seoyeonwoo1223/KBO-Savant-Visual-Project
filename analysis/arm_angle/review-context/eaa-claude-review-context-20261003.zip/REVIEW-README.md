# eAA Claude 검토 자료

먼저 analysis/arm_angle/claude-cross-check-prompt.md를 읽으세요.

이 ZIP은 로컬 연구 스냅샷입니다. 새 폴더에 압축을 풀어 검토하며 기존 checkout에 덮어쓰지 마세요. 생산 v1과 이후 미커밋 연구가 함께 포함됩니다. 코드/문서/일부 결과를 포함하며 저장소 전체 또는 독립 실행 환경이 아닙니다. canonical 전체, 원본 영상 전체, 원본 Statcast 응답, 학습 캐시, 의존성, 인증 정보는 포함하지 않았습니다. 제공된 코드의 절대 캐시 경로는 다른 환경에서 유효하지 않을 수 있습니다.

review_frames의 unmarked PNG는 전준표158/159·이강준50/51·김광현89/90·윤현106/107을 원본에서 디코딩한 무표시 화면입니다. 같은 폴더의 annotated JPG는 이전 계산에서 표시한 관절점/공 좌표입니다. 둘 모두 실제 릴리즈 순간이나 보정된 Savant 각도 라벨이 아닙니다. 색칠된 점의 위치 자체를 교차 점검하세요.

review_selected_poses.json은 선택 프레임 관절점과 pose 원본 파일 해시입니다. review_inputs/jeon2026_selected_canonical.json은 기존 API로 좁혀 읽고 재조회 일치를 확인한 전준표2026의1,163구입니다. 새 분석의 source of truth를 전체 결과 CSV로 대체하는 것이 아닙니다.

review-manifest.json의SHA-256으로 각 첨부 바이트를 검증할 수 있습니다. 검사 통과 기록은 물리적인 암슬롯 정확도 검증과 구분하세요.
