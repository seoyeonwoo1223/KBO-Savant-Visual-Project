"""Collect bounded Statcast details for existing arm-angle reference pitchers.

Savant silently caps details CSV at 25,000 rows. Split any capped interval and
never treat it as a complete source. Raw responses stay in an ignored cache;
retained columns and request hashes make the experiment reproducible offline.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import time

import pandas as pd
import requests

ROOT = Path(__file__).resolve().parents[1]
ENDPOINT = "https://baseballsavant.mlb.com/statcast_search/csv"
DATES = {2020: ("2020-07-23", "2020-09-27"), 2021: ("2021-04-01", "2021-10-03"),
         2022: ("2022-04-07", "2022-10-05"), 2023: ("2023-03-30", "2023-10-01"),
         2024: ("2024-03-20", "2024-09-30")}
COLUMNS = ["pitcher", "game_date", "game_type", "game_year", "game_pk", "at_bat_number", "pitch_number",
           "pitch_type", "p_throws", "release_pos_x", "release_pos_y", "release_pos_z", "release_extension",
           "vx0", "vy0", "vz0", "ax", "ay", "az", "release_speed", "release_spin_rate", "arm_angle"]
IDENTITY = ["game_pk", "at_bat_number", "pitch_number"]


def collect_interval(year, start, end, ids, cache, attempts=3):
    params = [("all", "true"), ("type", "details"), ("player_type", "pitcher"), ("hfGT", "R|"),
              ("game_date_gt", start.isoformat()), ("game_date_lt", end.isoformat())]
    params += [("pitchers_lookup[]", p) for p in ids]
    request_url = requests.Request("GET", ENDPOINT, params=params).prepare().url
    tag = hashlib.sha256(request_url.encode()).hexdigest()[:16]
    path = cache / f"{year}-{start}-{end}-{tag}.csv.gz"
    if path.exists():
        content = gzip.decompress(path.read_bytes())
    else:
        for attempt in range(attempts):
            try:
                response = requests.get(request_url, timeout=90)
                response.raise_for_status()
                content = response.content
                break
            except requests.RequestException:
                if attempt+1 == attempts:
                    raise
                time.sleep(2*(attempt+1))
        # Validate the schema before persisting a response: do not cache an HTML
        # login, access-denial or database timeout as a successful CSV extract.
        header = pd.read_csv(io.BytesIO(content), nrows=0)
        if not set(COLUMNS).issubset(header.columns):
            raise ValueError("Statcast candidate schema changed")
        path.write_bytes(gzip.compress(content, compresslevel=3, mtime=0))
    frame = pd.read_csv(io.BytesIO(content), usecols=COLUMNS, dtype={"pitcher": str})
    frame = frame[COLUMNS]
    meta = {"season": year, "date_start": str(start), "date_end": str(end), "url": request_url,
            "source_sha256": hashlib.sha256(content).hexdigest(), "rows": len(frame),
            "capped": len(frame) >= 25000, "collected_at": datetime.now(timezone.utc).isoformat()}
    if len(frame) >= 25000:
        if start == end:
            raise ValueError("A single day reaches the CSV cap; split pitcher IDs before proceeding")
        mid = start+(end-start)//2
        a, am = collect_interval(year, start, mid, ids, cache)
        b, bm = collect_interval(year, mid+timedelta(days=1), end, ids, cache)
        return pd.concat([a, b], ignore_index=True), [meta]+am+bm
    if len(frame):
        if not set(frame.pitcher).issubset(ids):
            raise ValueError("Savant ignored the pitcher-ID filter")
        if not frame.game_type.eq("R").all() or not frame.game_year.eq(year).all():
            raise ValueError("Unexpected season or game type")
        if not frame.game_date.between(str(start), str(end)).all():
            raise ValueError("Savant ignored date bounds")
        if frame.duplicated(IDENTITY).any():
            raise ValueError("Duplicate pitch identity within extract")
    return frame, [meta]


def collect_season(year, ids, output, workers=3):
    cache = output / "source_cache"
    cache.mkdir(parents=True, exist_ok=True)
    first, last = map(date.fromisoformat, DATES[year])
    windows, d = [], first
    while d <= last:
        end = min(d+timedelta(days=6), last)
        windows.append((d, end))
        d = end+timedelta(days=1)
    frames, sources = [], []
    def run_window(window):
        return collect_interval(year, *window, ids, cache)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for n, (frame, metadata) in enumerate(pool.map(run_window, windows), 1):
            frames.append(frame)
            sources += metadata
            print(f"MLB candidates {year}: {n}/{len(windows)} windows, {sum(len(f) for f in frames):,} pitches", flush=True)
    result = pd.concat(frames, ignore_index=True)
    if result.duplicated(IDENTITY).any():
        raise ValueError("Overlapping intervals or duplicate pitch identity")
    result = result.sort_values(IDENTITY).reset_index(drop=True)
    path = output / f"statcast_candidates_{year}.parquet"
    result.to_parquet(path, index=False)
    manifest = {"season": year, "rows": len(result), "pitchers": int(result.pitcher.nunique()),
                "observed_arm_angle_rows": int(result.arm_angle.notna().sum()), "requested_ids": ids,
                "source_requests": sources, "parquet_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "cap_policy": "Discard capped intervals, recursively split inclusive dates; no duplicate pitch IDs"}
    (output / f"statcast_candidates_{year}.json").write_text(json.dumps(manifest, indent=2)+"\n")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=ROOT / ".cache/arm_angle/candidates")
    parser.add_argument("--seasons", nargs="+", type=int, default=[2020, 2021, 2022, 2023, 2024])
    parser.add_argument("--workers", type=int, default=3)
    args = parser.parse_args()
    reference = pd.read_csv(ROOT / "analysis/arm_angle/results/eaa_mlb_split_validation.csv", dtype={"pitcher": str})
    args.out.mkdir(parents=True, exist_ok=True)
    for year in args.seasons:
        ids = sorted(reference.loc[reference.season.eq(year), "pitcher"].unique())
        collect_season(year, ids, args.out, args.workers)


if __name__ == "__main__":
    main()
