"""Cache official Savant FF spin directions for same-season arm-angle validation."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import re

import pandas as pd
import requests


def collect_year(year, cache):
    url = (f"https://baseballsavant.mlb.com/leaderboard/spin-direction-pitches?year={year}"
           "&team=&p_throws=&pitch_type=FF&min=100")
    path = cache / f"spin-direction-pitches-{year}.html"
    if path.exists():
        content = path.read_bytes()
    else:
        response = requests.get(url, timeout=40)
        response.raise_for_status()
        content = response.content
        path.write_bytes(content)
    found = re.search(r"(?:var|const|let)\s+leaderboardData\s*=\s*(\[.*?\]);", content.decode(), re.S)
    if not found:
        raise ValueError("Savant spin-reference schema changed")
    data = pd.DataFrame(json.loads(found[1]))
    data = data.loc[data.season.eq(year) & data.api_pitch_type.eq("FF") & data.is_sport_mlb.eq(1)].copy()
    if data.empty or data.player_id.duplicated().any() or not data.n_pitches.ge(100).all():
        raise ValueError("Nonempty unique MLB pitcher-season FF reference with >=100 pitches required")
    data["source_url"] = url
    data["source_sha256"] = hashlib.sha256(content).hexdigest()
    data["collected_at"] = datetime.now(timezone.utc).isoformat()
    columns = ["player_id", "season", "pitch_hand", "n_pitches", "release_speed", "spin_rate",
               "alan_active_spin_pct", "active_spin", "hawkeye_measured", "movement_inferred",
               "diff_measured_inferred", "source_url", "source_sha256", "collected_at"]
    print(f"Savant FF spin reference: {year}, {len(data)} rows", flush=True)
    return data[columns]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path(".cache/arm_angle/ode"))
    args = parser.parse_args()
    cache = args.out / "source_cache"
    cache.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(max_workers=3) as pool:
        frames = list(pool.map(lambda y: collect_year(y, cache), range(2020, 2025)))
    pd.concat(frames, ignore_index=True).to_csv(args.out / "mlb_fastball_spin_reference.csv", index=False)


if __name__ == "__main__":
    main()
