import pytest

from visualbaseball.video_frame_timing import FrameTimeline


def timeline(starts, durations):
    return FrameTimeline.from_probe([
        {'best_effort_timestamp_time': str(t), 'duration_time': str(d)}
        for t, d in zip(starts, durations)
    ])


def test_variable_gif_delays_are_not_replaced_with_average_fps():
    clock = timeline([0, .02, .12, .16], [.02, .1, .04, .08])
    assert clock.timestamps_ms == (0, 20, 120, 160)
    assert clock.duration_ms == 240
    assert clock.variable_timing
    assert clock.sampled_indices(30) == [0, 2, 3]
    assert clock.nearest_index(110) == 2
    # Index/average_fps would put frame 2 at 120 ms here, but frame 1 at
    # 60 ms instead of its actual 20 ms; the event window must use the clock.
    assert clock.nearest_index(25) == 1


def test_presentation_offset_and_window_boundaries_are_preserved():
    clock = timeline([2., 2.04, 2.08], [.04, .04, .04])
    assert clock.source_start_timestamp_ms == 2000
    assert clock.timestamps_ms == (0, 40, 80)
    assert not clock.variable_timing
    assert clock.nearest_index(-150) == 0
    assert clock.nearest_index(150) == 2
    assert clock.nearest_index(60) == 1
    assert clock.sampled_indices(25) == [0, 1, 2]


def test_ffprobe_timestamp_rounding_does_not_drop_thirty_fps_frames():
    clock = timeline([round(i / 30, 6) for i in range(30)], [round(1 / 30, 6)] * 30)
    assert clock.sampled_indices(30) == list(range(30))


@pytest.mark.parametrize('frames', [
    [],
    [{'duration_time': '.04'}],
    [{'best_effort_timestamp_time': 'NaN', 'duration_time': '.04'}],
    [{'best_effort_timestamp_time': '0', 'duration_time': '0'}],
    [{'best_effort_timestamp_time': '0', 'duration_time': '.04'}] * 2,
    [{'best_effort_timestamp_time': '0'}],
])
def test_unknown_or_broken_clocks_are_rejected(frames):
    with pytest.raises(ValueError):
        FrameTimeline.from_probe(frames)


def test_missing_last_duration_is_explicitly_marked_inferred():
    clock = FrameTimeline.from_probe([
        {'best_effort_timestamp_time': '0'},
        {'best_effort_timestamp_time': '.04'},
        {'best_effort_timestamp_time': '.08'},
    ])
    assert clock.durations_ms == (40, 40, 40)
    assert clock.final_duration_inferred
    assert 'original recording speed unverified' in clock.as_dict()['clock_domain']
