import copy

import numpy as np
import pytest

from visualbaseball.video_pose_candidates import associate_ball_observations, motion_features, release_proposals


def sequence(n=150,bursts=(10,70,140)):
    records=[];advance=0
    for frame in range(n):
        if frame in bursts:advance+=40
        p=np.zeros((33,4));p[:,2:]=.95
        p[11,:2]=[100,100];p[12,:2]=[120,100]
        p[23,:2]=[100,200];p[24,:2]=[120,200]
        p[14,:2]=[150,100];p[16,:2]=[200+advance,100]
        records.append({'frame_index':frame,'timestamp_ms':frame*1000/30,'segment_id':0,
                        'width':1000,'height':600,'landmarks':p.tolist()})
    return records


def test_nms_keeps_separate_motion_windows_without_forcing_a_release_count():
    records=sequence();candidates,_=release_proposals(records,'Right',max_events=5)
    assert [r['frame_index'] for r in candidates]==[10,70,140]
    assert all(not r['ball_release_confirmed'] and not r['arm_angle_available'] for r in candidates)
    assert release_proposals(sequence(bursts=()),'Right')[0]==[]


def test_camera_translation_and_uniform_zoom_do_not_create_motion():
    records=sequence(30,bursts=())
    for i,r in enumerate(records):
        p=np.array(r['landmarks']);p[:,:2]=p[:,:2]*(1+i*.01)+[i*2,i]
        r['landmarks']=p.tolist()
    candidates,features=release_proposals(records,'Right')
    assert candidates==[]
    assert max(r['wrist_speed_torso_per_s'] or 0 for r in features)<1e-10


def test_hand_mirroring_preserves_candidate_frames_and_scores():
    right=sequence();left=copy.deepcopy(right)
    for r in left:
        p=np.array(r['landmarks']);p[[11,12,13,14,15,16,23,24]]=p[[12,11,14,13,16,15,24,23]]
        p[:,0]=1000-p[:,0];r['landmarks']=p.tolist()
    a,b=[release_proposals(d,h)[0] for d,h in [(right,'Right'),(left,'Left')]]
    assert [r['frame_index'] for r in a]==[r['frame_index'] for r in b]
    np.testing.assert_allclose([r['score'] for r in a],[r['score'] for r in b],atol=1e-10)


def test_low_visibility_cuts_and_long_gaps_cannot_create_release_windows():
    records=sequence(12,bursts=(10,));records[10]['landmarks'][16][2]=.1
    assert release_proposals(records,'Right')[0]==[]
    records=sequence(12,bursts=(10,));records[10]['segment_id']=1;records[11]['segment_id']=1
    assert release_proposals(records,'Right')[0]==[]
    records=sequence(12,bursts=(10,))
    for r in records[10:]:r['timestamp_ms']+=1000
    assert release_proposals(records,'Right')[0]==[]
    with pytest.raises(ValueError,match='increasing'):
        motion_features([records[0],records[0]],'Right')


def test_ball_proximity_tracks_do_not_cross_events_or_link_one_frame_twice():
    def obs(event,frame,x):return {'event_id':event,'frame_index':frame,'timestamp_ms':frame*30.,'center_x_px':x,'center_y_px':100.,'score':.8}
    observations=[obs(1,0,100),obs(1,1,110),obs(1,1,115),obs(2,2,120),obs(2,3,130),obs(2,20,140)]
    tracks=associate_ball_observations(observations,max_step_px=30)
    assert len(tracks)==2
    for t in tracks:
        assert len({p['event_id'] for p in t['observations']})==1
        assert len({p['frame_index'] for p in t['observations']})==len(t['observations'])
        assert not t['release_confirmed'] and not t['ball_identity_verified']


def test_joints_inferred_outside_the_pitcher_crop_do_not_create_a_release():
    records=sequence(12,bursts=(10,))
    for r in records:r['roi_bounds_px']=[80,50,230,210]
    # Wrist stays inside the original image but moves outside the analyzed ROI.
    assert records[10]['landmarks'][16][0]==240
    candidates,features=release_proposals(records,'Right')
    assert not features[10]['pose_valid']
    assert candidates==[]


def test_displacement_mode_preserves_motion_candidates_in_slowed_playback():
    regular=sequence(12,bursts=(10,));slow=copy.deepcopy(regular)
    for r in slow:r['timestamp_ms']*=9
    a=release_proposals(regular,'Right',motion_mode='displacement',max_gap_s=.5)[0]
    b=release_proposals(slow,'Right',motion_mode='displacement',max_gap_s=.5)[0]
    assert [r['frame_index'] for r in a]==[r['frame_index'] for r in b]==[10]
    np.testing.assert_allclose([r['score'] for r in a],[r['score'] for r in b])
    assert release_proposals(slow,'Right')[0]==[]
    slow[10]['timestamp_ms']+=5000;slow[11]['timestamp_ms']+=5000
    assert release_proposals(slow,'Right',motion_mode='displacement',max_gap_s=.5)[0]==[]
