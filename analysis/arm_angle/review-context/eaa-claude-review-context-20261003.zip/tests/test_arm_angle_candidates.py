import numpy as np
import pandas as pd
import pytest

from visualbaseball.arm_angle_candidates import aggregate_seasons, candidate_features, pitch_family, prepare_pitches


def frame():
    return pd.DataFrame({"season": 2024, "pitcher": "1", "pitcher_hand": "Right", "height_cm": 185.,
        "rel_side": [.5,.6,.7,.8], "rel_height": [1.8,1.7,1.6,1.5], "extension": [1.8]*4,
        "reference_y_m": 15.24, "release_y_m": 16.64, "vx_m_s": [1.,2.,3.,4.], "vy_m_s": -40.,
        "vz_m_s": [-2.,-3.,-4.,-5.], "ax_m_s2": -3., "ay_m_s2": 8., "az_m_s2": -5.,
        "pitch_type": ["FF","SI","SL","CH"], "arm_angle": [40.,42.,44.,46.]})


def test_hand_mirror_preserves_canonical_features_including_covariance():
    right = frame();left = right.copy();left['pitcher_hand']='Left'
    left[['rel_side','vx_m_s','ax_m_s2']] *= -1
    a,b = [aggregate_seasons(prepare_pitches(x)) for x in [right,left]]
    for col in ['extension_over_height','vertical_launch_deg','arm_side_launch_deg','side_sd_over_height',
                'height_sd_over_height','side_height_cov_over_height2']:
        assert a.loc[0,col] == pytest.approx(b.loc[0,col],abs=1e-12)


def test_covariance_and_mix_are_for_the_same_all_pitch_population():
    raw=frame();result=aggregate_seasons(prepare_pitches(raw)).iloc[0];h=1.85
    assert result.side_height_cov_over_height2 == pytest.approx(np.cov(raw.rel_side,raw.rel_height,ddof=1)[0,1]/h**2)
    assert result.side_sd_over_height == pytest.approx(raw.rel_side.std(ddof=1)/h)
    assert result.fastball_share == .5 and result.breaking_share == .25 and result.offspeed_share == .25
    assert result.matched_pitch_arm_angle_deg == 43 and result.n_arm_angle == 4


def test_launch_angles_average_per_pitch_not_angle_of_mean_velocity():
    raw=frame();raw['ay_m_s2']=0.;raw['az_m_s2']=0.;raw['ax_m_s2']=0.
    raw['vz_m_s']=[-1.,-1.,-1.,-30.]
    prepared=prepare_pitches(raw);mean=aggregate_seasons(prepared).iloc[0]
    expected=np.degrees(np.arctan2(raw.vz_m_s,np.hypot(raw.vx_m_s,raw.vy_m_s))).mean()
    assert mean.vertical_launch_deg == pytest.approx(expected)
    wrong=np.degrees(np.arctan2(raw.vz_m_s.mean(),np.hypot(raw.vx_m_s.mean(),raw.vy_m_s.mean())))
    assert abs(mean.vertical_launch_deg-wrong)>1


def test_velocity_is_reconstructed_at_release_before_launch_angle():
    raw=frame();raw['ay_m_s2']=0.;raw['ax_m_s2']=4.;raw['az_m_s2']=-8.
    prepared=prepare_pitches(raw)
    # The 50ft state occurs AFTER release. Backward extrapolation must use
    # negative time; using the supplied velocity without it changes the angle.
    t=(raw.release_y_m-raw.reference_y_m)/raw.vy_m_s
    assert (t<0).all()
    vx=raw.vx_m_s+raw.ax_m_s2*t;vz=raw.vz_m_s+raw.az_m_s2*t
    expected=np.degrees(np.arctan2(vz,np.hypot(vx,raw.vy_m_s)))
    np.testing.assert_allclose(prepared.vertical_launch_deg,expected,atol=1e-12)
    at_reference=np.degrees(np.arctan2(raw.vz_m_s,np.hypot(raw.vx_m_s,raw.vy_m_s)))
    assert abs(prepared.vertical_launch_deg.iloc[0]-at_reference.iloc[0])>.1


def test_missing_extension_and_wrong_plane_do_not_become_valid_features():
    raw=frame();raw.loc[0,'extension']=np.nan;raw.loc[1,'vy_m_s']=0;raw.loc[2,'release_y_m']=100
    prepared=prepare_pitches(raw)
    assert prepared.candidate_valid.tolist()==[False,False,False,True]
    assert aggregate_seasons(prepared).side_sd_over_height.isna().all()


def test_unknown_pitch_type_keeps_denominator_and_height_conflicts_fail():
    raw=frame();raw.loc[0,'pitch_type']='unknown'
    result=aggregate_seasons(prepare_pitches(raw)).iloc[0]
    assert result.n_pitches==4 and result.other_pitch_share==.25
    assert pitch_family('4-Seam Fastball')=='fastball' and pitch_family('Forkball')=='offspeed'
    raw.loc[0,'height_cm']=190.
    with pytest.raises(ValueError,match='constant'):
        aggregate_seasons(prepare_pitches(raw))
