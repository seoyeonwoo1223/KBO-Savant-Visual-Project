import math
import numpy as np
import pytest

from visualbaseball.video_arm_projection import image_arm_angle, image_angle_box


@pytest.mark.parametrize('ball,expected', [((10, 0), 0), ((10, -10), 45),
                                         ((-10, -10), 45), ((10, 10), -45), ((0, -10), 90)])
def test_horizontal_definition_and_mirrored_throwing_side(ball, expected):
    assert image_arm_angle((0, 0), ball) == pytest.approx(expected)


def test_translation_and_uniform_resize_preserve_angle():
    source = image_arm_angle((40, 80), (110, 30))
    assert image_arm_angle((440, 280), (510, 230)) == pytest.approx(source)
    assert image_arm_angle((80, 160), (220, 60)) == pytest.approx(source)


def test_coordinate_box_contains_independent_dense_angle_samples():
    result = image_angle_box((100, 200), (240, 70), (12, 14), (8, 9), roll_scenario_deg=2)
    for sx in np.linspace(88, 112, 5):
        for sy in np.linspace(186, 214, 5):
            for bx in np.linspace(232, 248, 5):
                for by in np.linspace(61, 79, 5):
                    value = math.degrees(math.atan2(sy - by, abs(bx - sx)))
                    assert result['coordinate_scenario_low_deg'] <= value - 2
                    assert value + 2 <= result['coordinate_scenario_high_deg']
    assert result['calibrated_Savant_angle_deg'] is None


def test_x_crossing_can_reach_vertical_and_overlapping_boxes_are_flagged():
    result = image_angle_box((100, 100), (103, 40), (5, 5), (5, 5))
    assert result['coordinate_scenario_high_deg'] == 90
    overlap = image_angle_box((100, 100), (103, 98), (5, 5), (5, 5))
    assert overlap['possible_coincident_points']
    assert overlap['coordinate_scenario_low_deg'] == -90
    assert overlap['coordinate_scenario_high_deg'] == 90


def test_invalid_pixels_and_uncertainty_are_rejected():
    with pytest.raises(ValueError): image_arm_angle((0, 0), (0, 0))
    with pytest.raises(ValueError): image_arm_angle((0, 0), (float('nan'), 3))
    with pytest.raises(ValueError): image_angle_box((0, 0), (3, -4), (-1, 2), (1, 1))
