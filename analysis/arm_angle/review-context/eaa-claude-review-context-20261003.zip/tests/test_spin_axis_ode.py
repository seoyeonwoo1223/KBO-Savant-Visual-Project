"""Physics and identifiability checks, independent of any KBO labels."""
import numpy as np
import pytest

from visualbaseball.spin_axis_ode import (
    Environment, PLATE_FRONT_Y_M, aerodynamic_acceleration, axis_degrees,
    axis_from_degrees, conditional_full_axes, fit_inverse, forward_observations,
    transverse_axis, time_to_plane,
)


def test_backspin_lifts_and_right_handed_tilt_has_catcher_negative_break():
    v = np.array([0., -40., 0.])
    back = aerodynamic_acceleration(v, np.array([-200., 0., 0.]), .35)
    tilted = aerodynamic_acceleration(v, axis_from_degrees(150., v)*200, .35)
    assert back[2] > -9.80665 and back[1] > 0
    assert tilted[0] < 0 and tilted[2] > -9.80665
    assert axis_degrees(transverse_axis(v, tilted)) == pytest.approx(150.)


def test_local_gyro_branches_have_same_magnus_but_different_full_axes():
    v = np.array([1., -40., -3.]); original = v.copy()
    effective = axis_from_degrees(150., v)
    plus, minus = conditional_full_axes(effective, .6, v)
    np.testing.assert_allclose(np.linalg.norm([plus, minus], axis=1), 1.)
    np.testing.assert_allclose(v, original)  # scientific routines must not mutate inputs
    np.testing.assert_allclose(aerodynamic_acceleration(v, plus*200, .35),
                               aerodynamic_acceleration(v, minus*200, .35), atol=1e-12)
    assert np.linalg.norm(plus-minus) > 1


@pytest.mark.parametrize("angle,fraction", [(180., .95), (145., .8), (225., .85), (10., .5)])
def test_synthetic_inverse_recovers_transverse_axis_drag_and_fraction(angle, fraction):
    r = np.array([-.6, 16.7, 1.8]); v = np.array([2., -40., -2.])
    time = .435; spin = 2300.
    axis = axis_from_degrees(angle, v)
    obs = forward_observations(r, v, time, axis*spin*2*np.pi/60*fraction, .35)
    fitted = fit_inverse(r, v, time, spin, obs['horizontal_break_m'], obs['induced_vertical_break_m'],
                         obs['terminal_speed_m_s'])
    assert fitted['status'] == 'fitted'
    gap = ((fitted['axis_deg']-axis_degrees(axis)+180) % 360)-180
    assert abs(gap) < .01
    assert fitted['drag_coefficient'] == pytest.approx(.35, abs=1e-4)
    assert fitted['effective_active_fraction'] == pytest.approx(fraction, abs=1e-4)


def test_forward_has_left_right_mirror_symmetry():
    r = np.array([-.6, 16.7, 1.8]); v = np.array([2., -40., -2.])
    w = axis_from_degrees(150., v)*200
    a = forward_observations(r, v, .43, w, .35)
    # Angular velocity is an axial vector: reflection x changes its y/z signs.
    b = forward_observations(r*np.array([-1, 1, 1]), v*np.array([-1, 1, 1]), .43,
                             w*np.array([1, -1, -1]), .35)
    assert a['horizontal_break_m'] == pytest.approx(-b['horizontal_break_m'], abs=1e-10)
    assert a['induced_vertical_break_m'] == pytest.approx(b['induced_vertical_break_m'], abs=1e-10)
    assert a['terminal_speed_m_s'] == pytest.approx(b['terminal_speed_m_s'], abs=1e-10)


def test_weak_force_and_invalid_spin_do_not_manufacture_an_axis():
    r, v = [0., 16., 1.8], [0., -40., -2.]
    assert fit_inverse(r, v, .42, 2300, .001, .001, 36)['axis_deg'] is None
    with pytest.raises(ValueError, match='Invalid measured'):
        fit_inverse(r, v, .42, float('nan'), .3, .4, 36)
    assert transverse_axis(v, aerodynamic_acceleration(v, [0., 0., 0.], .35)) is None


def test_release_to_plate_time_is_invariant_to_the_source_timestamp_plane():
    y, v, a = 17., -40., 8.
    shift = .04
    y_new, v_new = y+v*shift+.5*a*shift**2, v+a*shift
    duration_a = time_to_plane(y, v, a, PLATE_FRONT_Y_M)-time_to_plane(y, v, a, 16.8)
    duration_b = time_to_plane(y_new, v_new, a, PLATE_FRONT_Y_M)-time_to_plane(y_new, v_new, a, 16.8)
    assert duration_a == pytest.approx(duration_b, abs=1e-12)
    assert duration_a > time_to_plane(y_new, v_new, a, PLATE_FRONT_Y_M)
    assert time_to_plane(16., -40., 0., 0.) == pytest.approx(.4)
    assert np.isnan(time_to_plane(16., 0., 0., 0.))
    assert np.isnan(time_to_plane(16., -1., 100., 0.))
