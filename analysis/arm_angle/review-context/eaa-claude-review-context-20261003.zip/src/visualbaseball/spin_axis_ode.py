"""Research-only inverse baseball-flight ODE, in SI / catcher coordinates.

The fitted axis explains transverse aerodynamic force under the declared lift
law. It is not a measured spin axis, and does not identify a throwing shoulder.
Movement and flight time can themselves be derived from a trajectory fit;
reproducing those observations is model closure, not independent validation.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

G = 9.80665
BALL_MASS_KG = .145
BALL_RADIUS_M = .0366
FT_M = .3048
RUBBER_Y_M = 60.5 * FT_M
PLATE_FRONT_Y_M = 17 / 12 * FT_M


def time_to_plane(y0_m, vy0_m_s, ay_m_s2, target_y_m):
    """Near-flight quadratic root for a ball travelling toward decreasing y.

    Broadcasting permits vectorized audits. Impossible/nonfinite trajectories
    return NaN rather than a invented time; inputs use SI at one named plane.
    """
    y0, vy, ay, target = np.broadcast_arrays(*[np.asarray(x, float) for x in
                                              (y0_m, vy0_m_s, ay_m_s2, target_y_m)])
    delta = vy*vy-2*ay*(y0-target)
    with np.errstate(invalid="ignore", divide="ignore"):
        # Rationalized near root avoids cancellation when deceleration is tiny.
        curved = 2*(y0-target)/(-vy+np.sqrt(delta))
        linear = (target-y0)/vy
        answer = np.where(np.abs(ay) < 1e-10, linear, curved)
    valid = np.isfinite(y0+vy+ay+target) & (vy < 0) & (delta >= 0) & np.isfinite(answer)
    return np.where(valid, answer, np.nan)


@dataclass(frozen=True)
class Environment:
    density_kg_m3: float = 1.225
    lift_law: str = "saturating"
    wind_m_s: tuple[float, float, float] = (0., 0., 0.)

    def __post_init__(self):
        if not .5 <= self.density_kg_m3 <= 2 or self.lift_law not in {"saturating", "piecewise"}:
            raise ValueError("Invalid air density or lift law")
        if np.asarray(self.wind_m_s).shape != (3,) or not np.isfinite(self.wind_m_s).all():
            raise ValueError("Finite three-dimensional wind required")


def lift_coefficient(spin_parameter, law="saturating"):
    """Two explicit empirical scenarios, not a ball-specific calibration."""
    s = np.maximum(np.asarray(spin_parameter), 0.)
    if law == "saturating":
        return .336 * (-np.expm1(-6.041 * s))
    if law == "piecewise":
        return np.where(s < .1, 1.5 * s, .09 + .6 * s)
    raise ValueError("Unknown lift law")


def aerodynamic_acceleration(velocity, omega, drag_coefficient, environment=Environment()):
    v = np.asarray(velocity, dtype=float) - np.asarray(environment.wind_m_s)
    w = np.asarray(omega, dtype=float)
    speed = np.linalg.norm(v)
    if speed < 1e-12:
        return np.array([0., 0., -G])
    crossed = np.cross(w, v)
    cross_size = np.linalg.norm(crossed)
    active_omega = cross_size / speed
    spin_parameter = BALL_RADIUS_M * active_omega / speed
    k = environment.density_kg_m3 * np.pi * BALL_RADIUS_M ** 2 / (2 * BALL_MASS_KG)
    drag = -k * drag_coefficient * speed * v
    lift = (k * float(lift_coefficient(spin_parameter, environment.lift_law)) * speed ** 2
            * crossed / cross_size) if cross_size > 1e-12 else np.zeros(3)
    return drag + lift + np.array([0., 0., -G])


def transverse_axis(velocity, acceleration):
    """Local effective axis from the drag-orthogonal force, assuming no wind/SSW."""
    v, a = np.asarray(velocity, float), np.asarray(acceleration, float)
    if v.shape != (3,) or a.shape != (3,) or not np.isfinite(np.r_[v, a]).all():
        raise ValueError("Finite three-dimensional velocity and acceleration required")
    speed = np.linalg.norm(v)
    if speed < 1e-12:
        raise ValueError("Nonzero velocity required")
    direction = v / speed
    aero = a + np.array([0., 0., G])
    transverse = aero - np.dot(aero, direction) * direction
    size = np.linalg.norm(transverse)
    if size < 1e-12:
        return None
    axis = np.cross(direction, transverse / size)
    return axis / np.linalg.norm(axis)


def axis_degrees(axis):
    """Savant-compatible x/z spin direction: pure backspin=180, topspin=0."""
    axis = np.asarray(axis, float)
    if not np.isfinite(axis).all() or np.linalg.norm(axis[[0, 2]]) < 1e-12:
        return float("nan")
    return float(np.degrees(np.arctan2(-axis[2], axis[0])) % 360)


def axis_from_degrees(angle_deg, velocity):
    phi = np.radians(angle_deg)
    axis = np.array([np.cos(phi), 0., -np.sin(phi)])
    velocity = np.asarray(velocity, float)
    if velocity.shape != (3,) or not np.isfinite(velocity).all() or np.linalg.norm(velocity) < 1e-12 or not np.isfinite(angle_deg):
        raise ValueError("Finite angle and nonzero three-dimensional velocity required")
    direction = velocity / np.linalg.norm(velocity)
    axis -= np.dot(axis, direction) * direction
    return axis / np.linalg.norm(axis)


def conditional_full_axes(effective_axis, active_fraction, velocity):
    """The two local gyro branches consistent with an assumed total spin rate.

    This is a local, pure-Magnus ambiguity. Constant-axis flight hypotheses can
    diverge as velocity changes; fitted constant-acceleration records do not
    independently establish which branch or force law is correct.
    """
    if not 0 <= active_fraction <= 1:
        raise ValueError("Active fraction outside [0, 1]")
    v = np.array(velocity, dtype=float, copy=True)
    if v.shape != (3,) or not np.isfinite(v).all() or np.linalg.norm(v) < 1e-12:
        raise ValueError("Finite nonzero three-dimensional velocity required")
    v /= np.linalg.norm(v)
    w = np.asarray(effective_axis, float)
    if not np.isfinite(w).all() or abs(np.dot(w, v)) > 1e-8 or abs(np.linalg.norm(w)-1) > 1e-8:
        raise ValueError("Unit effective axis perpendicular to velocity required")
    gyro = np.sqrt(1-active_fraction ** 2) * v
    return active_fraction*w + gyro, active_fraction*w - gyro


def forward_observations(position_m, velocity_m_s, flight_time_s, omega_rad_s,
                         drag_coefficient, environment=Environment(), *, rtol=2e-7):
    """Integrate spinning and no-spin paths at the same supplied elapsed time.

    Returns HB/IVB relative to the same-time no-spin shadow, terminal speed and
    y. Same-time movement is an explicit approximation to vendor movement;
    manufacturer-specific crossing-plane definitions must not be assumed equal.
    """
    r, v, omega = [np.asarray(x, float) for x in (position_m, velocity_m_s, omega_rad_s)]
    if (any(x.shape != (3,) for x in (r, v, omega)) or not np.isfinite(np.r_[r, v, omega]).all()
            or not .05 < flight_time_s < 1 or not .05 < drag_coefficient < 1):
        raise ValueError("Finite SI initial state, plausible time and drag required")
    initial = np.r_[r, v, r, v]

    def rhs(_, state):
        return np.r_[state[3:6], aerodynamic_acceleration(state[3:6], omega, drag_coefficient, environment),
                     state[9:12], aerodynamic_acceleration(state[9:12], np.zeros(3), drag_coefficient, environment)]

    solution = solve_ivp(rhs, (0., float(flight_time_s)), initial, rtol=rtol, atol=1e-9)
    if not solution.success or not np.isfinite(solution.y[:, -1]).all():
        raise RuntimeError("Flight integration failed")
    state = solution.y[:, -1]
    return {"horizontal_break_m": float(state[0]-state[6]),
            "induced_vertical_break_m": float(state[2]-state[8]),
            "terminal_speed_m_s": float(np.linalg.norm(state[3:6])),
            "terminal_y_m": float(state[1]), "terminal_x_m": float(state[0]),
            "terminal_z_m": float(state[2])}


def fit_inverse(position_m, velocity_m_s, flight_time_s, spin_rate_rpm,
                horizontal_break_m, induced_vertical_break_m, terminal_speed_m_s,
                environment=Environment()):
    """Fit Cd, effective spin fraction and transverse direction (gyro fixed=0).

    Direction is retained only when closure tolerances and the unfitted plate
    plane diagnostic pass in the caller; it shares the VB source trajectory.
    A constrained fraction at 1 is flagged,
    never silently interpreted as an optical spin-efficiency measurement.
    """
    values = np.r_[position_m, velocity_m_s, flight_time_s, spin_rate_rpm,
                   horizontal_break_m, induced_vertical_break_m, terminal_speed_m_s]
    if (not np.isfinite(values).all() or not 100 <= spin_rate_rpm <= 5000
            or not 15 <= np.linalg.norm(velocity_m_s) <= 55 or not 10 <= terminal_speed_m_s <= 55):
        raise ValueError("Invalid measured inputs")
    if np.hypot(horizontal_break_m, induced_vertical_break_m) < .02:
        return {"status": "weak_transverse_force", "axis_deg": None}
    phi = float(np.degrees(np.arctan2(-horizontal_break_m, -induced_vertical_break_m)) % 360)
    total = float(spin_rate_rpm * 2*np.pi / 60)
    target = np.array([horizontal_break_m, induced_vertical_break_m, terminal_speed_m_s])
    scale = np.array([.01, .01, .3])  # declared closure scales; not measured noise

    def evaluate(parameters):
        cd, fraction, angle = parameters
        axis = axis_from_degrees(angle, velocity_m_s)
        return forward_observations(position_m, velocity_m_s, flight_time_s,
                                    axis*total*fraction, cd, environment)

    def residual(parameters):
        predicted = evaluate(parameters)
        p = np.array([predicted["horizontal_break_m"], predicted["induced_vertical_break_m"],
                      predicted["terminal_speed_m_s"]])
        return (p-target)/scale

    fitted = least_squares(residual, [.35, .8, phi], bounds=([.10, .001, phi-120], [.70, 1., phi+120]),
                           x_scale=[.3, .5, 30], max_nfev=40, ftol=1e-7, xtol=1e-7, gtol=1e-7)
    predicted = evaluate(fitted.x)
    error = residual(fitted.x)*scale
    axis = axis_from_degrees(fitted.x[2], velocity_m_s)
    return {"status": "fitted" if fitted.success else "optimizer_not_converged",
            "axis_deg": axis_degrees(axis), "axis_x": float(axis[0]), "axis_y": float(axis[1]),
            "axis_z": float(axis[2]), "drag_coefficient": float(fitted.x[0]),
            "effective_active_fraction": float(fitted.x[1]),
            "spin_fraction_at_boundary": bool(fitted.x[1] >= .999),
            "hb_closure_error_cm": float(error[0]*100), "ivb_closure_error_cm": float(error[1]*100),
            "speed_closure_error_kmh": float(error[2]*3.6),
            "plate_y_error_cm": float((predicted["terminal_y_m"]-PLATE_FRONT_Y_M)*100),
            "n_evaluations": int(fitted.nfev)}
