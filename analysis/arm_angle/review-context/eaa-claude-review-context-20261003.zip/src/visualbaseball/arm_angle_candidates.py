"""Research-only seasonal extension, direction, spread and pitch-mix features.

All inputs use SI at declared planes. Flight direction is computed per pitch
before aggregation, and dispersion uses hand-normalized coordinates. These
features do not measure a shoulder or establish KBO arm-angle accuracy.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .spin_axis_ode import time_to_plane

KEYS = ["season", "pitcher", "pitcher_hand"]
FAMILIES = {
    "extension": ["extension_over_height"],
    "launch": ["vertical_launch_deg", "arm_side_launch_deg"],
    "dispersion": ["side_sd_over_height", "height_sd_over_height", "side_height_cov_over_height2"],
    "mix": ["fastball_share", "breaking_share", "offspeed_share", "cutter_share"],
}
ALL_FEATURES = sum(FAMILIES.values(), [])


def pitch_family(value):
    name = str(value or "").strip()
    if name in {"FF", "SI", "FA", "4-Seam Fastball", "2-Seam Fastball"}:
        return "fastball"
    if name in {"CU", "KC", "SL", "ST", "SV", "CS", "SC", "Curveball", "Slider", "Sweeper", "Slurve", "Knuckle Curve", "Knuckle Curveball"}:
        return "breaking"
    if name in {"CH", "FS", "FO", "Changeup", "Forkball", "Splitter"}:
        return "offspeed"
    if name in {"FC", "Cutter"}:
        return "cutter"
    return "other"


def prepare_pitches(frame):
    needed = KEYS+["height_cm", "rel_side", "rel_height", "extension", "reference_y_m", "release_y_m",
                   "vx_m_s", "vy_m_s", "vz_m_s", "ax_m_s2", "ay_m_s2", "az_m_s2", "pitch_type"]
    missing = set(needed)-set(frame.columns)
    if missing:
        raise ValueError(f"Missing candidate inputs: {sorted(missing)}")
    data = frame.copy()
    h = data.height_cm.to_numpy(float)/100
    hand = data.pitcher_hand.map({"Right": 1., "Left": -1.}).to_numpy(float)
    t = time_to_plane(data.reference_y_m, data.vy_m_s, data.ay_m_s2, data.release_y_m)
    velocity = data[["vx_m_s", "vy_m_s", "vz_m_s"]].to_numpy(float)
    acceleration = data[["ax_m_s2", "ay_m_s2", "az_m_s2"]].to_numpy(float)
    velocity = velocity+acceleration*t[:, None]
    speed = np.linalg.norm(velocity, axis=1)
    data["vertical_launch_deg"] = np.degrees(np.arctan2(velocity[:, 2], np.hypot(velocity[:, 0], velocity[:, 1])))
    data["arm_side_launch_deg"] = np.degrees(np.arctan2(-hand*velocity[:, 0], -velocity[:, 1]))
    data["arm_side_release_m"] = hand*data.rel_side.to_numpy(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        data["extension_over_height"] = data.extension/h
    data["pitch_family"] = data.pitch_type.map(pitch_family)
    for family in ["fastball", "breaking", "offspeed", "cutter"]:
        data[family+"_share"] = data.pitch_family.eq(family).astype(float)
    numeric = ["height_cm", "rel_side", "rel_height", "extension", "reference_y_m", "release_y_m",
               "vx_m_s", "vy_m_s", "vz_m_s", "ax_m_s2", "ay_m_s2", "az_m_s2"]+FAMILIES["launch"]
    finite = np.isfinite(data[numeric]).all(axis=1)
    data["candidate_valid"] = (finite & data.height_cm.between(140, 220) & data.rel_side.between(-2, 2)
        & data.rel_height.between(.05, 2.7) & data.extension.between(.5, 3) & data.vy_m_s.lt(0)
        & (velocity[:, 1] < 0) & (speed >= 15) & (speed <= 55) & (np.abs(t) <= .15)
        & data.pitcher_hand.isin(["Right", "Left"]))
    return data


def aggregate_seasons(prepared):
    data = prepared.loc[prepared.candidate_valid].copy()
    if data.empty:
        raise ValueError("No valid candidate inputs")
    if data.groupby(KEYS).height_cm.nunique().max() != 1:
        raise ValueError("Height must be constant within each pitcher-season")
    data["side_height_product"] = data.arm_side_release_m*data.rel_height
    columns = ["rel_side", "rel_height", "extension"]+FAMILIES["extension"]+FAMILIES["launch"]+FAMILIES["mix"]
    result = data.groupby(KEYS, dropna=False)[columns].mean()
    result["height_cm"] = data.groupby(KEYS, dropna=False).height_cm.first()
    result["n_pitches"] = data.groupby(KEYS, dropna=False).size()
    h = result.height_cm/100
    result["side_sd_over_height"] = data.groupby(KEYS).arm_side_release_m.std(ddof=1)/h
    result["height_sd_over_height"] = data.groupby(KEYS).rel_height.std(ddof=1)/h
    group = data.groupby(KEYS)
    # Correct sample covariance denominator; do not average within-pitch-type
    # dispersions and silently lose the between-type component.
    covariance = (group.side_height_product.mean()-group.arm_side_release_m.mean()*group.rel_height.mean())*result.n_pitches/(result.n_pitches-1)
    result["side_height_cov_over_height2"] = covariance/h**2
    result["other_pitch_share"] = group.pitch_family.apply(lambda x: x.eq("other").mean())
    if "arm_angle" in data:
        labels = data.arm_angle.where(data.arm_angle.between(-90, 90))
        result["matched_pitch_arm_angle_deg"] = labels.groupby([data[k] for k in KEYS]).mean()
        result["n_arm_angle"] = labels.groupby([data[k] for k in KEYS]).count()
    return result.reset_index()


def candidate_features(data, family="geometry"):
    h = data.height_cm.to_numpy(float)/100
    hand = data.pitcher_hand.map({"Right": 1., "Left": -1.}).to_numpy(float)
    x = np.column_stack([h, data.rel_height.to_numpy(float)/h, hand*data.rel_side.to_numpy(float)/h, (hand < 0).astype(float)])
    if family == "geometry":
        return x
    columns = ALL_FEATURES if family == "all" else FAMILIES[family]
    return np.column_stack([x, data[columns].to_numpy(float)])
