"""Unreviewed image-pose motion proposals, never measured arm-angle labels.

Coordinates are pixels, not reconstructed world coordinates. A velocity peak
and an extended arm can suggest a release window but cannot confirm ball release.
"""
from __future__ import annotations

import math

import numpy as np

ARM_INDICES = {'Right': (12, 14, 16), 'Left': (11, 13, 15)}
TORSO_INDICES = (11, 12, 23, 24)
LANDMARK_NAMES = (
    'nose','left_eye_inner','left_eye','left_eye_outer','right_eye_inner','right_eye','right_eye_outer',
    'left_ear','right_ear','mouth_left','mouth_right','left_shoulder','right_shoulder','left_elbow','right_elbow',
    'left_wrist','right_wrist','left_pinky','right_pinky','left_index','right_index','left_thumb','right_thumb',
    'left_hip','right_hip','left_knee','right_knee','left_ankle','right_ankle','left_heel','right_heel','left_foot_index','right_foot_index')


def motion_features(records, hand, *, min_confidence=.5, max_gap_s=.12):
    """Use shoulder-relative wrist displacement normalized by visible torso size.

    Reject low-confidence/missing joints, long tracking gaps and scene changes.
    Image translation and uniform resizing cannot create a motion peak alone.
    Input landmarks: 33 rows of [x_px, y_px, visibility, presence].
    """
    if hand not in ARM_INDICES:
        raise ValueError('Verified throwing hand must be Right or Left')
    previous=None;output=[];last_time=-math.inf
    for record in records:
        time=float(record['timestamp_ms'])/1000
        if not math.isfinite(time) or time<=last_time:
            raise ValueError('Strictly increasing finite frame timestamps required')
        last_time=time
        points=np.asarray(record.get('landmarks',[]),float)
        base={'frame_index':int(record['frame_index']),'timestamp_ms':float(record['timestamp_ms']),
              'segment_id':int(record.get('segment_id',0)),'pose_valid':False,
              'wrist_speed_torso_per_s':None,'wrist_step_torso':None,'elbow_deg':None}
        selected=sorted(set(TORSO_INDICES+ARM_INDICES[hand]))
        valid=(points.shape==(33,4) and np.isfinite(points[selected]).all()
               and (points[selected,2:]>=min_confidence).all())
        if valid and 'width' in record and 'height' in record:
            xy=points[selected,:2]
            valid=((xy[:,0]>=0)&(xy[:,0]<=record['width'])&(xy[:,1]>=0)&(xy[:,1]<=record['height'])).all()
        if valid and 'roi_bounds_px' in record:
            x1,y1,x2,y2=record['roi_bounds_px'];xy=points[selected,:2]
            valid=((xy[:,0]>=x1)&(xy[:,0]<=x2)&(xy[:,1]>=y1)&(xy[:,1]<=y2)).all()
        if not valid:
            output.append(base);previous=None;continue
        shoulder,elbow,wrist=points[list(ARM_INDICES[hand]),:2]
        shoulders=points[[11,12],:2].mean(axis=0);hips=points[[23,24],:2].mean(axis=0)
        scale=float(np.linalg.norm(shoulders-hips))
        a,b=shoulder-elbow,wrist-elbow;denom=np.linalg.norm(a)*np.linalg.norm(b)
        if scale<12 or denom<1e-8:
            output.append(base);previous=None;continue
        normalized=(wrist-shoulder)/scale
        elbow_deg=float(np.degrees(np.arccos(np.clip(np.dot(a,b)/denom,-1,1))))
        base.update(pose_valid=True,elbow_deg=elbow_deg,torso_px=scale,
                    arm_reach_torso=float(np.linalg.norm(normalized)),
                    min_visibility=float(points[selected,2].min()),min_presence=float(points[selected,3].min()),
                    shoulder_x_px=float(shoulder[0]),shoulder_y_px=float(shoulder[1]),
                    elbow_x_px=float(elbow[0]),elbow_y_px=float(elbow[1]),
                    wrist_x_px=float(wrist[0]),wrist_y_px=float(wrist[1]))
        if previous is not None:
            gap=time-previous[0]
            if gap<=max_gap_s and base['segment_id']==previous[2]:
                step=float(np.linalg.norm(normalized-previous[1]))
                base['wrist_step_torso']=step
                base['wrist_speed_torso_per_s']=step/gap
        previous=(time,normalized,base['segment_id']);output.append(base)
    return output


def release_proposals(records, hand, *, max_events=3, min_speed=3., min_elbow_deg=135., cooldown_s=1.5,
                      motion_mode='speed', min_step_torso=.04, max_gap_s=.12):
    """Rank kinematic windows without forcing a requested count of releases.

    Scores are heuristics, not probabilities. Ball position and arm angle are
    deliberately absent until the image observations are independently reviewed.
    """
    if max_events<1 or cooldown_s<=0 or max_gap_s<=0 or min_step_torso<=0:
        raise ValueError('Positive event limit and cooldown required')
    if motion_mode not in {'speed','displacement'}:raise ValueError('Unknown motion mode')
    features=motion_features(records,hand,max_gap_s=max_gap_s);pool=[]
    for row in features:
        signal=row['wrist_speed_torso_per_s'] if motion_mode=='speed' else row['wrist_step_torso']
        threshold=min_speed if motion_mode=='speed' else min_step_torso
        if signal is None or not row['pose_valid'] or signal<threshold or row['elbow_deg']<min_elbow_deg or row['arm_reach_torso']<.6:
            continue
        score=signal*row['min_visibility']*row['min_presence']*(row['elbow_deg']/180)
        pool.append(dict(row,score=score,status='unreviewed_release_window',
            proposal_method=f'shoulder_relative_wrist_{motion_mode}_and_arm_extension',
            ball_release_confirmed=False,ball_position_available=False,
            arm_angle_available=False,pitcher_identity_verified=False))
    selected=[]
    for row in sorted(pool,key=lambda x:x['score'],reverse=True):
        if all(abs(row['timestamp_ms']-old['timestamp_ms'])>=cooldown_s*1000 for old in selected):
            selected.append(row)
        if len(selected)==max_events:break
    return sorted(selected,key=lambda x:x['timestamp_ms']),features


def associate_ball_observations(observations, *, max_gap_ms=160., max_step_px=200.):
    """Greedy proximity tracks of unreviewed detector observations per window.

    A track is not proof of a baseball or of its release frame. Never link
    detections from different events or from the same source frame.
    """
    tracks=[]
    for point in sorted(observations,key=lambda p:(p['event_id'],p['timestamp_ms'],-p['score'])):
        xy=np.array([point['center_x_px'],point['center_y_px']],float)
        if not np.isfinite(xy).all():raise ValueError('Finite image observations required')
        choices=[]
        for i,track in enumerate(tracks):
            last=track[-1];gap=point['timestamp_ms']-last['timestamp_ms']
            if point['event_id']!=last['event_id'] or gap<=0 or gap>max_gap_ms:continue
            distance=np.linalg.norm(xy-[last['center_x_px'],last['center_y_px']])
            if distance<=max_step_px:choices.append((distance,i))
        if choices:tracks[min(choices)[1]].append(point)
        else:tracks.append([point])
    return [{'track_id':i+1,'event_id':t[0]['event_id'],'observations':t,
             'status':'unreviewed_detector_proximity_track','ball_identity_verified':False,
             'release_confirmed':False} for i,t in enumerate(tracks) if len(t)>=2]
