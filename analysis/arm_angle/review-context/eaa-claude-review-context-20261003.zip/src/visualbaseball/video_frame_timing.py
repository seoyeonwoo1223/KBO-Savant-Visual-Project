"""Preserve the container playback clock, including unequal GIF frame delays.

Playback timestamps are not a measurement of the original pitch's real-time
clock: an edited GIF or slow-motion MP4 may change playback speed.
"""
from __future__ import annotations

from bisect import bisect_left
from dataclasses import dataclass
import json
import math
from pathlib import Path
import subprocess


@dataclass(frozen=True)
class FrameTimeline:
    timestamps_ms: tuple[float, ...]
    durations_ms: tuple[float, ...]
    source_start_timestamp_ms: float
    final_duration_inferred: bool

    @classmethod
    def from_probe(cls, frames):
        if not frames:
            raise ValueError('No timestamped video frames returned by ffprobe')
        try:
            starts = tuple(float(f['best_effort_timestamp_time']) * 1000 for f in frames)
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError('Every frame needs an explicit presentation timestamp') from error
        if not all(math.isfinite(t) for t in starts) or any(b <= a for a, b in zip(starts, starts[1:])):
            raise ValueError('Strictly increasing finite frame timestamps required')
        origin = starts[0]
        durations = []
        inferred = False
        for i, frame in enumerate(frames):
            duration = frame.get('duration_time', frame.get('pkt_duration_time'))
            if duration is None:
                if i + 1 < len(starts):
                    value = starts[i + 1] - starts[i]
                elif len(starts) > 1:
                    value = starts[-1] - starts[-2]
                    inferred = True
                else:
                    raise ValueError('A single frame needs an explicit duration')
            else:
                try:
                    value = float(duration) * 1000
                except (TypeError, ValueError) as error:
                    raise ValueError('Invalid frame duration') from error
            if not math.isfinite(value) or value <= 0:
                raise ValueError('Positive finite frame durations required')
            durations.append(value)
        return cls(tuple(t - origin for t in starts), tuple(durations), origin, inferred)

    @property
    def duration_ms(self):
        return self.timestamps_ms[-1] + self.durations_ms[-1]

    @property
    def average_fps(self):
        return len(self.timestamps_ms) * 1000 / self.duration_ms

    @property
    def variable_timing(self):
        gaps = tuple(b - a for a, b in zip(self.timestamps_ms, self.timestamps_ms[1:]))
        delays = gaps + self.durations_ms
        return max(delays) - min(delays) > 1.0

    def sampled_indices(self, max_fps):
        if not math.isfinite(max_fps) or max_fps <= 0:
            raise ValueError('Positive finite sampling rate required')
        interval = 1000 / max_fps
        indices = []
        next_time = -math.inf
        for index, timestamp in enumerate(self.timestamps_ms):
            # ffprobe prints seconds to six decimal places, so presentation
            # times can differ by one microsecond around a 30-fps boundary.
            if timestamp + 1e-3 >= next_time:
                indices.append(index)
                next_time = timestamp + interval
        return indices

    def nearest_index(self, timestamp_ms):
        if not math.isfinite(timestamp_ms):
            raise ValueError('Finite requested timestamp required')
        index = bisect_left(self.timestamps_ms, timestamp_ms)
        if index == 0:
            return 0
        if index == len(self.timestamps_ms):
            return index - 1
        before, after = self.timestamps_ms[index - 1:index + 1]
        return index - 1 if timestamp_ms - before <= after - timestamp_ms else index

    def as_dict(self):
        return {
            'method': 'ffprobe frame presentation timestamps',
            'clock_domain': 'container_playback; original recording speed unverified',
            'timestamps_ms': self.timestamps_ms,
            'durations_ms': self.durations_ms,
            'source_start_timestamp_ms': self.source_start_timestamp_ms,
            'average_fps': self.average_fps,
            'variable_timing': self.variable_timing,
            'final_duration_inferred': self.final_duration_inferred,
        }


def probe_timeline(path: Path, *, max_seconds=180.):
    if not math.isfinite(max_seconds) or max_seconds <= 0:
        raise ValueError('Positive finite probe duration required')
    result = subprocess.run([
        'ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-read_intervals', f'%+{max_seconds + 1:.6f}', '-show_frames',
        '-show_entries', 'frame=best_effort_timestamp_time,pkt_duration_time,duration_time',
        '-of', 'json', str(path),
    ], check=True, capture_output=True, text=True, timeout=60)
    return FrameTimeline.from_probe(json.loads(result.stdout).get('frames', []))
