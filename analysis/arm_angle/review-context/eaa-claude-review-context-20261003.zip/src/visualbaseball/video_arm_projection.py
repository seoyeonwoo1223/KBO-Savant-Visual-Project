"""Image shoulder–ball angles, separate from calibrated Savant arm angles."""
from __future__ import annotations

import math


def image_arm_angle(shoulder_xy, ball_xy):
    sx, sy = map(float, shoulder_xy)
    bx, by = map(float, ball_xy)
    if not all(math.isfinite(v) for v in (sx, sy, bx, by)):
        raise ValueError('Finite original-image coordinates required')
    dx, up = bx - sx, sy - by
    if math.hypot(dx, up) == 0:
        raise ValueError('Coincident shoulder and ball do not define an angle')
    return math.degrees(math.atan2(up, abs(dx)))


def image_angle_box(shoulder_xy, ball_xy, shoulder_error_xy, ball_error_xy, *, roll_scenario_deg=0.):
    """Conservative coordinate-box range, not a confidence/prediction interval.

    The range excludes unknown camera yaw/elevation, depth, missed release time,
    pose anatomy bias and recording-date/identity uncertainty. A roll scenario
    expands it by a stated assumed maximum; roll is not measured here.
    """
    point = image_arm_angle(shoulder_xy, ball_xy)
    errors = tuple(map(float, (*shoulder_error_xy, *ball_error_xy, roll_scenario_deg)))
    if not all(math.isfinite(v) and v >= 0 for v in errors):
        raise ValueError('Nonnegative finite coordinate/roll scenario bounds required')
    sx, sy = map(float, shoulder_xy); bx, by = map(float, ball_xy)
    ex, ey, fx, fy, roll = errors
    dxlow, dxhigh = bx - sx - ex - fx, bx - sx + ex + fx
    uplow, uphigh = sy - by - ey - fy, sy - by + ey + fy
    includes_zero = dxlow <= 0 <= dxhigh and uplow <= 0 <= uphigh
    if includes_zero:
        low, high = -90., 90.
    else:
        xmin = 0. if dxlow <= 0 <= dxhigh else min(abs(dxlow), abs(dxhigh))
        xmax = max(abs(dxlow), abs(dxhigh))
        values = [math.degrees(math.atan2(y, x))
                  for x in (xmin, xmax) for y in (uplow, uphigh)
                  if math.hypot(x, y) > 0]
        low, high = max(-90., min(values) - roll), min(90., max(values) + roll)
    return {'image_angle_deg': point, 'coordinate_scenario_low_deg': low,
            'coordinate_scenario_high_deg': high, 'possible_coincident_points': includes_zero,
            'range_kind': 'coordinate_boxes_and_assumed_roll_only_NOT_total_uncertainty',
            'camera_geometry_calibrated': False, 'calibrated_Savant_angle_deg': None}
